package com.example.k036_practicelab_01_02_2025;

import java.io.Serializable;

public class Person implements Serializable {
    private String name;
    private String contact;
    private String email;
    private int imageResId;

    public Person(String name, String contact, String email, int imageResId) {
        this.name = name;
        this.contact = contact;
        this.email = email;
        this.imageResId = imageResId;
    }

    public String getName() { return name; }
    public String getContact() { return contact; }
    public String getEmail() { return email; }
    public int getImageResId() { return imageResId; }
}
