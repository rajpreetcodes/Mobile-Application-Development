package com.example.k036_practicelab_01_02_2025;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    ArrayList<Person> personList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        personList = new ArrayList<>();

        // Sample data
        personList.add(new Person("Quiet Kid", "1234567890", "AK-47inmy@bag.com", R.drawable.default_image));
        personList.add(new Person("John Pork", "9876543210", "johnporkis@calling.com", R.drawable.john_pork));
        personList.add(new Person("Freak Bob", "6942069420", "heyitsme@freakbob.com", R.drawable.freakbob));

        PersonAdapter adapter = new PersonAdapter(this, personList);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra("person", personList.get(position));
                startActivity(intent);
            }
        });
    }
}
