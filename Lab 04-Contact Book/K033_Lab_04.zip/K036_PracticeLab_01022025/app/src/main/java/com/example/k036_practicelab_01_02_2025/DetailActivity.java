package com.example.k036_practicelab_01_02_2025;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        ImageView detailImage = findViewById(R.id.detailImage);
        TextView detailName = findViewById(R.id.detailName);
        TextView detailContact = findViewById(R.id.detailContact);
        TextView detailEmail = findViewById(R.id.detailEmail);

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("person")) {
            Person person = (Person) intent.getSerializableExtra("person");
            detailName.setText(person.getName());
            detailContact.setText(person.getContact());
            detailEmail.setText(person.getEmail());
            detailImage.setImageResource(person.getImageResId());
        }
    }
}
