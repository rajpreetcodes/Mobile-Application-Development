package com.example.ts_project_is_mad;

import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.assertion.ViewAssertions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.content.Context;

@RunWith(AndroidJUnit4.class)
public class LoginActivityTest {

    private DatabaseHelper dbHelper;
    private ActivityScenario<LoginActivity> activityScenario;
    
    @Before
    public void setUp() {
        // Set up the database with a test user
        Context context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        dbHelper = new DatabaseHelper(context);
        
        // Create a test user
        String testEmail = "testuser@example.com";
        String testPassword = "testpassword";
        
        // Check if the user already exists
        if (!dbHelper.checkEmailExists(testEmail)) {
            dbHelper.addUser("Test User", testEmail, testPassword, "user");
        }
        
        // Launch the login activity
        activityScenario = ActivityScenario.launch(LoginActivity.class);
    }
    
    @After
    public void tearDown() {
        // Close the database
        if (dbHelper != null) {
            dbHelper.close();
        }
        
        // Close the activity
        if (activityScenario != null) {
            activityScenario.close();
        }
    }
    
    @Test
    public void testLoginFieldsExist() {
        // Check that email and password fields exist
        Espresso.onView(ViewMatchers.withId(R.id.emailInput))
                .check(ViewAssertions.matches(ViewMatchers.isDisplayed()));
        
        Espresso.onView(ViewMatchers.withId(R.id.passwordInput))
                .check(ViewAssertions.matches(ViewMatchers.isDisplayed()));
        
        // Check that login button exists
        Espresso.onView(ViewMatchers.withId(R.id.loginButton))
                .check(ViewAssertions.matches(ViewMatchers.isDisplayed()));
    }
    
    @Test
    public void testEmptyFieldsValidation() {
        // Click login button without entering anything
        Espresso.onView(ViewMatchers.withId(R.id.loginButton))
                .perform(ViewActions.click());
        
        // Check for validation errors
        Espresso.onView(ViewMatchers.withId(R.id.emailInputLayout))
                .check(ViewAssertions.matches(ViewMatchers.hasDescendant(
                        ViewMatchers.withText("Email is required"))));
    }
    
    @Test
    public void testCorrectLogin() {
        // Enter valid credentials
        Espresso.onView(ViewMatchers.withId(R.id.emailInput))
                .perform(ViewActions.typeText("testuser@example.com"), 
                         ViewActions.closeSoftKeyboard());
        
        Espresso.onView(ViewMatchers.withId(R.id.passwordInput))
                .perform(ViewActions.typeText("testpassword"), 
                         ViewActions.closeSoftKeyboard());
        
        // Click login button
        Espresso.onView(ViewMatchers.withId(R.id.loginButton))
                .perform(ViewActions.click());
        
        // Wait for the next activity to load
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // Note: We can't easily verify navigation to the next activity
        // without adding IdlingResources, but the test will fail if
        // there are UI exceptions or the app crashes
    }
} 