package com.example.ts_project_is_mad;

import android.content.Context;
import android.content.Intent;

import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.assertion.ViewAssertions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class TurfOwnerActivityTest {

    private DatabaseHelper dbHelper;
    private ActivityScenario<TurfOwnerActivity> activityScenario;
    private long testUserId;
    
    @Before
    public void setUp() {
        // Set up the database with a test owner
        Context context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        dbHelper = new DatabaseHelper(context);
        
        // Create a test owner user
        String testEmail = "testowner@example.com";
        String testPassword = "testpassword";
        
        // Check if the user already exists
        if (!dbHelper.checkEmailExists(testEmail)) {
            testUserId = dbHelper.addUser("Test Owner", testEmail, testPassword, "owner");
        } else {
            testUserId = dbHelper.getUserId(testEmail);
        }
        
        // Create intent with user ID
        Intent intent = new Intent(context, TurfOwnerActivity.class);
        intent.putExtra("userId", testUserId);
        
        // Launch the activity with intent
        activityScenario = ActivityScenario.launch(intent);
    }
    
    @After
    public void tearDown() {
        // Close the database
        if (dbHelper != null) {
            dbHelper.close();
        }
        
        // Close the activity
        if (activityScenario != null) {
            activityScenario.close();
        }
    }
    
    @Test
    public void testFabIsVisible() {
        // Check that the floating action button exists and is displayed
        Espresso.onView(ViewMatchers.withId(R.id.addTurfFab))
                .check(ViewAssertions.matches(ViewMatchers.isDisplayed()));
    }
    
    @Test
    public void testFabClicksOpensAddTurf() {
        // Click on the FAB
        Espresso.onView(ViewMatchers.withId(R.id.addTurfFab))
                .perform(ViewActions.click());
        
        // Wait briefly for the activity to launch
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // Instead of checking for addTurfTitle which doesn't exist, 
        // check for another element that is visible on the AddTurfActivity
        Espresso.onView(ViewMatchers.withId(R.id.nameInputLayout))
                .check(ViewAssertions.matches(ViewMatchers.isDisplayed()));
                
        // And verify that the add turf button exists
        Espresso.onView(ViewMatchers.withId(R.id.addTurfButton))
                .check(ViewAssertions.matches(ViewMatchers.isDisplayed()));
    }
} 