package com.example.ts_project_is_mad;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
    ExampleInstrumentedTest.class,
    DatabaseTest.class,
    LoginActivityTest.class,
    TurfOwnerActivityTest.class
})
public class TestSuite {
    // This class acts as a holder for the test suite annotations
    // No implementation is needed
} 