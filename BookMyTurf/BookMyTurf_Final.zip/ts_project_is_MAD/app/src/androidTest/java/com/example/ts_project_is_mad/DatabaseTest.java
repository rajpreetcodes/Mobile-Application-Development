package com.example.ts_project_is_mad;

import android.content.Context;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

/**
 * Test for DatabaseHelper functionality
 */
@RunWith(AndroidJUnit4.class)
public class DatabaseTest {
    
    private DatabaseHelper dbHelper;
    private Context appContext;
    
    @Before
    public void setUp() {
        // Get the context and initialize the database helper
        appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        dbHelper = new DatabaseHelper(appContext);
        
        // Clear any existing data
        dbHelper.recreateDatabase();
    }
    
    @After
    public void tearDown() {
        // Close the database connection
        dbHelper.close();
    }
    
    @Test
    public void testUserRegistration() {
        // Test adding a user
        String testName = "Test User";
        String testEmail = "test@example.com";
        String testPassword = "password123";
        String testUserType = "user";
        
        long userId = dbHelper.addUser(testName, testEmail, testPassword, testUserType);
        assertTrue("User should be added successfully", userId > 0);
        
        // Test user login
        boolean loginResult = dbHelper.checkUser(testEmail, testPassword);
        assertTrue("User login should succeed", loginResult);
        
        // Test invalid login
        boolean invalidLoginResult = dbHelper.checkUser(testEmail, "wrongpassword");
        assertFalse("Invalid login should fail", invalidLoginResult);
        
        // Test email exists
        boolean emailExists = dbHelper.checkEmailExists(testEmail);
        assertTrue("Email should exist", emailExists);
        
        // Test get user type
        String userType = dbHelper.getUserType(testEmail);
        assertEquals("User type should match", testUserType, userType);
        
        // Test get user ID
        long retrievedUserId = dbHelper.getUserId(testEmail);
        assertEquals("User ID should match", userId, retrievedUserId);
    }
    
    @Test
    public void testTurfOperations() {
        // First add a test user as owner
        long ownerId = dbHelper.addUser("Turf Owner", "owner@example.com", "password123", "owner");
        assertTrue("Owner should be added successfully", ownerId > 0);
        
        // Test adding a turf
        String testName = "Test Turf";
        String testDesc = "A test turf for testing";
        String testLocation = "Test Location";
        double testPrice = 1000.0;
        
        long turfId = dbHelper.addTurf(testName, testDesc, testLocation, testPrice, (int)ownerId);
        assertTrue("Turf should be added successfully", turfId > 0);
        
        // Test retrieving turf by ID
        Turf retrievedTurf = dbHelper.getTurfById(turfId);
        assertNotNull("Turf should be retrieved", retrievedTurf);
        assertEquals("Turf name should match", testName, retrievedTurf.getName());
        
        // Test getting turfs by owner ID
        List<Turf> ownerTurfs = dbHelper.getTurfsByOwnerId(ownerId);
        assertEquals("Owner should have 1 turf", 1, ownerTurfs.size());
        
        // Test getting all turfs
        List<Turf> allTurfs = dbHelper.getAllTurfsAsList();
        assertTrue("All turfs list should contain the test turf", allTurfs.size() > 0);
        
        // Test updating turf
        String updatedName = "Updated Turf";
        retrievedTurf.setName(updatedName);
        int updateResult = dbHelper.updateTurf(retrievedTurf);
        assertTrue("Turf update should succeed", updateResult > 0);
        
        // Verify the update
        Turf updatedTurf = dbHelper.getTurfById(turfId);
        assertEquals("Turf name should be updated", updatedName, updatedTurf.getName());
        
        // Test deleting turf
        int deleteResult = dbHelper.deleteTurf((int)turfId);
        assertTrue("Turf deletion should succeed", deleteResult > 0);
        
        // Verify the deletion
        List<Turf> turfsAfterDeletion = dbHelper.getAllTurfsAsList();
        assertEquals("No turfs should exist after deletion", 0, turfsAfterDeletion.size());
    }
    
    @Test
    public void testBookingOperations() {
        // Add a user and a turf for booking tests
        long userId = dbHelper.addUser("Booking User", "user@example.com", "password123", "user");
        long ownerId = dbHelper.addUser("Turf Owner", "owner@example.com", "password123", "owner");
        long turfId = dbHelper.addTurf("Booking Test Turf", "Turf for booking tests", "Test Location", 1000.0, (int)ownerId);
        
        // Test adding a booking
        String testDate = "2023-05-01";
        String testTimeSlot = "10:00 - 11:00";
        int testHours = 1;
        int testPlayerCount = 10;
        double testTotalPrice = 1000.0;
        
        // Check if time slot is available
        boolean isAvailable = dbHelper.isTimeSlotAvailable(turfId, testDate, testTimeSlot);
        assertTrue("Time slot should be available", isAvailable);
        
        // Add booking
        long bookingId = dbHelper.addBooking(userId, turfId, testDate, testTimeSlot, testHours, testPlayerCount, testTotalPrice);
        assertTrue("Booking should be added successfully", bookingId > 0);
        
        // Check that time slot is no longer available
        boolean isStillAvailable = dbHelper.isTimeSlotAvailable(turfId, testDate, testTimeSlot);
        assertFalse("Time slot should no longer be available", isStillAvailable);
        
        // Get booked time slots
        List<String> bookedSlots = dbHelper.getBookedTimeSlots(turfId, testDate);
        assertEquals("Should have 1 booked time slot", 1, bookedSlots.size());
        assertEquals("Booked slot should match the test time slot", testTimeSlot, bookedSlots.get(0));
        
        // Get user's bookings
        List<Booking> userBookings = dbHelper.getUserBookings(userId);
        assertEquals("User should have 1 booking", 1, userBookings.size());
    }
} 