# BookMyTurf Test Suite

This directory contains automated tests for the BookMyTurf Android application. The tests cover various aspects of the application including database operations, UI functionality, and general app context verification.

## Test Classes

1. **ExampleInstrumentedTest**
   - Basic test to verify the application context
   - Checks database helper creation

2. **DatabaseTest**
   - Tests database operations:
     - User registration and login
     - Turf creation, retrieval, updating, and deletion
     - Booking operations

3. **LoginActivityTest**
   - Tests login UI:
     - Verifies UI elements exist
     - Tests validation for empty fields
     - Tests login with valid credentials

4. **TurfOwnerActivityTest**
   - Tests turf owner functionality:
     - Verifies the FAB (Floating Action Button) is visible
     - Tests FAB click behavior

## Running Tests

### From Android Studio
1. Right-click on any test class or the `TestSuite` class
2. Select "Run" to execute individual tests or the entire suite

### From Command Line
```bash
# Run all tests
./gradlew connectedAndroidTest

# Run a specific test
./gradlew connectedAndroidTest -Pandroid.testInstrumentationRunnerArguments.class=com.example.ts_project_is_mad.DatabaseTest
```

## Test Prerequisites

- A device or emulator with API level matching the project's minimum SDK
- Internet access for any tests that rely on Firebase services
- Sufficient storage space for app installation

## Test Results

Test results can be found in:
```
app/build/reports/androidTests/connected/
```

The reports include HTML files you can open in a browser for a visual representation of test results. 