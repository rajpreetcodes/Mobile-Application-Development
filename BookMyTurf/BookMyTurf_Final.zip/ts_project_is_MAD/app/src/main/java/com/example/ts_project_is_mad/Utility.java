package com.example.ts_project_is_mad;

import android.text.TextUtils;
import android.util.Patterns;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Currency;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Utility class providing helper methods for validation and formatting
 */
public class Utility {
    
    // Regular expression for email validation
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "[a-zA-Z0-9+._%\\-]{1,256}" +
            "@" +
            "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
            "(" +
            "\\." +
            "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
            ")+"
    );
    
    /**
     * Validates if the given email address is valid
     * @param email The email address to validate
     * @return true if the email is valid, false otherwise
     */
    public static boolean isValidEmail(String email) {
        return !isNullOrEmpty(email) && EMAIL_PATTERN.matcher(email).matches();
    }

    /**
     * Validates if the given password meets the requirements
     * Minimum 6 characters
     * @param password The password to validate
     * @return true if the password is valid, false otherwise
     */
    public static boolean isValidPassword(String password) {
        return !isNullOrEmpty(password) && password.length() >= 6;
    }

    /**
     * Formats a price value as Indian Rupee with appropriate formatting
     * @param price The price value to format
     * @return Formatted price string with currency symbol
     */
    public static String formatPrice(double price) {
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
        format.setCurrency(Currency.getInstance("INR"));
        format.setMinimumFractionDigits(0);
        if (price == (int) price) {
            format.setMaximumFractionDigits(0);
        } else {
            format.setMaximumFractionDigits(2);
        }
        return format.format(price);
    }

    /**
     * Formats time from 24-hour format to 12-hour format with AM/PM
     * @param time24 Time in 24-hour format (HH:mm)
     * @return Time in 12-hour format with AM/PM
     */
    public static String formatTime(String time24) {
        try {
            SimpleDateFormat inFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
            SimpleDateFormat outFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
            Date date = inFormat.parse(time24);
            return outFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return time24; // Return the input if parsing fails
        }
    }

    /**
     * Checks if a string is null, empty or contains only whitespace
     * @param str The string to check
     * @return true if the string is null, empty or contains only whitespace, false otherwise
     */
    public static boolean isNullOrEmpty(String str) {
        if (str == null) {
            return true;
        }
        
        return str.trim().isEmpty();
    }
    
    /**
     * Android-specific version of isNullOrEmpty that uses TextUtils
     * @param str The string to check
     * @return true if the string is null, empty or contains only whitespace, false otherwise
     */
    public static boolean isNullOrEmptyAndroid(String str) {
        return str == null || TextUtils.isEmpty(str.trim());
    }
} 