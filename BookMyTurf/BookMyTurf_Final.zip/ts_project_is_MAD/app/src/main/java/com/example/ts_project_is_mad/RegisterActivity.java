package com.example.ts_project_is_mad;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class RegisterActivity extends AppCompatActivity {
    private TextInputLayout nameInputLayout;
    private TextInputLayout emailInputLayout;
    private TextInputLayout passwordInputLayout;
    private TextInputLayout confirmPasswordInputLayout;
    private TextInputEditText nameInput;
    private TextInputEditText emailInput;
    private TextInputEditText passwordInput;
    private TextInputEditText confirmPasswordInput;
    private RadioGroup userTypeRadioGroup;
    private RadioButton userRadioButton;
    private RadioButton ownerRadioButton;
    private Button registerButton;
    private TextView loginLink;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_register);

            // Initialize database helper
            dbHelper = new DatabaseHelper(this);

            // Initialize views
            initializeViews();

            // Set default selection
            userRadioButton.setChecked(true);

            // Set up email validation on focus change
            emailInput.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        validateEmail();
                    }
                }
            });

            // Set up password validation on focus change
            confirmPasswordInput.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        validatePasswordMatch();
                    }
                }
            });

            // Set up register button click listener
            registerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (validateInputs()) {
                        registerUser();
                    }
                }
            });

            // Set up login link click listener
            loginLink.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish(); // Go back to login screen
                }
            });
        } catch (Exception e) {
            Toast.makeText(this, "Error initializing Registration screen: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void initializeViews() {
        nameInputLayout = findViewById(R.id.nameInputLayout);
        emailInputLayout = findViewById(R.id.emailInputLayout);
        passwordInputLayout = findViewById(R.id.passwordInputLayout);
        confirmPasswordInputLayout = findViewById(R.id.confirmPasswordInputLayout);
        nameInput = findViewById(R.id.nameInput);
        emailInput = findViewById(R.id.emailInput);
        passwordInput = findViewById(R.id.passwordInput);
        confirmPasswordInput = findViewById(R.id.confirmPasswordInput);
        userTypeRadioGroup = findViewById(R.id.userTypeRadioGroup);
        userRadioButton = findViewById(R.id.userRadioButton);
        ownerRadioButton = findViewById(R.id.ownerRadioButton);
        registerButton = findViewById(R.id.registerButton);
        loginLink = findViewById(R.id.loginLink);
    }

    private void registerUser() {
        String name = nameInput.getText().toString().trim();
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();
        String userType = ownerRadioButton.isChecked() ? "owner" : "user";

        try {
            // Check if email already exists
            if (emailExists(email)) {
                emailInputLayout.setError("Email already registered");
                Toast.makeText(this, "This email is already registered. Please use a different email or login.",
                        Toast.LENGTH_LONG).show();
                return;
            }

            // Add user to database
            long userId = dbHelper.addUser(name, email, password, userType);

            if (userId > 0) {
                Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show();

                // Navigate to appropriate activity based on user type
                Intent intent;
                if ("owner".equals(userType)) {
                    intent = new Intent(RegisterActivity.this, TurfOwnerActivity.class);
                    intent.putExtra("owner_id", userId);
                } else {
                    intent = new Intent(RegisterActivity.this, TurfListActivity.class);
                    intent.putExtra("user_id", userId);
                }

                startActivity(intent);
                finish(); // Close registration activity
            } else {
                Toast.makeText(this, "Registration failed. Please try again.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            // Handle specific SQLite constraint exception
            if (e.getMessage() != null && e.getMessage().contains("UNIQUE constraint failed")) {
                emailInputLayout.setError("Email already registered");
                Toast.makeText(this, "This email is already registered. Please use a different email or login.",
                        Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Check if email already exists in the database
    private boolean emailExists(String email) {
        try {
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Cursor cursor = db.query(
                    "users",
                    new String[]{"id"},
                    "email = ?",
                    new String[]{email},
                    null, null, null
            );
            boolean exists = cursor != null && cursor.getCount() > 0;
            if (cursor != null) {
                cursor.close();
            }
            return exists;
        } catch (Exception e) {
            Toast.makeText(this, "Error checking email: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean validateName() {
        String name = nameInput.getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            nameInputLayout.setError("Name is required");
            return false;
        } else {
            nameInputLayout.setError(null);
            return true;
        }
    }

    private boolean validateEmail() {
        String email = emailInput.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            emailInputLayout.setError("Email is required");
            Toast.makeText(this, "Please enter your email address", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailInputLayout.setError("Please enter a valid email address");
            Toast.makeText(this, "Please enter a valid email address (e.g., user@example.com)", Toast.LENGTH_LONG).show();
            return false;
        } else {
            // Check if email already exists
            if (emailExists(email)) {
                emailInputLayout.setError("Email already registered");
                Toast.makeText(this, "This email is already registered. Please use a different email or login.",
                        Toast.LENGTH_LONG).show();
                return false;
            }
            emailInputLayout.setError(null);
            return true;
        }
    }

    private boolean validatePassword() {
        String password = passwordInput.getText().toString().trim();

        if (TextUtils.isEmpty(password)) {
            passwordInputLayout.setError("Password is required");
            return false;
        } else if (password.length() < 6) {
            passwordInputLayout.setError("Password must be at least 6 characters");
            return false;
        } else {
            passwordInputLayout.setError(null);
            return true;
        }
    }

    private boolean validatePasswordMatch() {
        String password = passwordInput.getText().toString().trim();
        String confirmPassword = confirmPasswordInput.getText().toString().trim();

        if (TextUtils.isEmpty(confirmPassword)) {
            confirmPasswordInputLayout.setError("Please confirm your password");
            return false;
        } else if (!password.equals(confirmPassword)) {
            confirmPasswordInputLayout.setError("Passwords do not match");
            return false;
        } else {
            confirmPasswordInputLayout.setError(null);
            return true;
        }
    }

    private boolean validateInputs() {
        boolean isNameValid = validateName();
        boolean isEmailValid = validateEmail();
        boolean isPasswordValid = validatePassword();
        boolean isPasswordMatchValid = validatePasswordMatch();

        return isNameValid && isEmailValid && isPasswordValid && isPasswordMatchValid;
    }
}