package com.example.ts_project_is_mad;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.UUID;

public class AddTurfActivity extends AppCompatActivity {
    private static final String TAG = "AddTurfActivity";
    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final int REQUEST_GALLERY_PERMISSION = 101;

    private TextInputLayout nameInputLayout;
    private TextInputLayout descriptionInputLayout;
    private TextInputLayout locationInputLayout;
    private TextInputLayout priceInputLayout;
    private TextInputLayout contactInfoInputLayout;
    private TextInputLayout openingTimeInputLayout;
    private TextInputLayout closingTimeInputLayout;
    private TextInputLayout upiIdInputLayout;
    private TextInputEditText nameInput;
    private TextInputEditText descriptionInput;
    private TextInputEditText locationInput;
    private TextInputEditText priceInput;
    private TextInputEditText contactInfoInput;
    private TextInputEditText openingTimeInput;
    private TextInputEditText closingTimeInput;
    private TextInputEditText upiIdInput;
    private Button addTurfButton;
    private Button takePictureButton;
    private Button selectImageButton;
    private ImageView turfImageView;
    private DatabaseHelper dbHelper;
    private long ownerId = -1; // Default to invalid ID

    // Firebase Storage references - declared as Object for flexibility
    // private Object storage; // FirebaseStorage 
    // private Object storageRef; // StorageReference
    private Uri imageUri = null;

    // Activity result launchers
    private ActivityResultLauncher<Intent> cameraLauncher;
    private ActivityResultLauncher<Intent> galleryLauncher;

    // New constant for map activity result
    private static final int REQUEST_SELECT_LOCATION = 102;
    private double selectedLatitude = 0;
    private double selectedLongitude = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_turf);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Get owner ID from intent
        if (getIntent().hasExtra("owner_id")) {
            ownerId = getIntent().getLongExtra("owner_id", -1);
            Log.d(TAG, "Owner ID from intent: " + ownerId);
        } else {
            // If no owner ID in intent, try to get from extras
            Bundle extras = getIntent().getExtras();
            if (extras != null && extras.containsKey("owner_id")) {
                ownerId = extras.getLong("owner_id", -1);
                Log.d(TAG, "Owner ID from extras: " + ownerId);
            }
        }

        // If still no valid owner ID, show error and finish
        if (ownerId == -1) {
            Toast.makeText(this, "Error: Owner ID not found", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "No owner ID found in intent or extras");
            finish();
            return;
        }

        // Set up toolbar
        setupToolbar();

        // Initialize views
        initializeViews();

        // Set up activity result launchers
        setupActivityResultLaunchers();

        // Set up image buttons
        takePictureButton.setOnClickListener(v -> checkCameraPermissionAndOpenCamera());
        selectImageButton.setOnClickListener(v -> checkGalleryPermissionAndOpenGallery());

        // Set up add turf button
        addTurfButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInputs()) {
                    // Save turf directly (without Firebase upload)
                    saveTurf(
                        nameInput.getText().toString().trim(),
                        descriptionInput.getText().toString().trim(),
                        locationInput.getText().toString().trim(),
                        Double.parseDouble(priceInput.getText().toString().trim()),
                        contactInfoInput.getText().toString().trim(),
                        openingTimeInput.getText().toString().trim(),
                        closingTimeInput.getText().toString().trim(),
                        imageUri != null ? imageUri.toString() : "",
                        upiIdInput.getText().toString().trim()
                    );
                }
            }
        });
    }

    private void setupActivityResultLaunchers() {
        cameraLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        try {
                            // Get image from camera
                            Bundle extras = result.getData().getExtras();
                            if (extras != null && extras.containsKey("data")) {
                                // Display the thumbnail image
                                Glide.with(this)
                                        .load(extras.get("data"))
                                        .centerCrop()
                                        .into(turfImageView);

                                // Make the image view visible
                                turfImageView.setVisibility(View.VISIBLE);
                                
                                // We can use the bitmap directly from the camera
                                android.graphics.Bitmap bitmap = (android.graphics.Bitmap) extras.get("data");
                                
                                // Convert bitmap to URI by saving it to a temporary file
                                String fileName = "temp_" + System.currentTimeMillis() + ".jpg";
                                java.io.File file = new java.io.File(getCacheDir(), fileName);
                                try {
                                    java.io.FileOutputStream fos = new java.io.FileOutputStream(file);
                                    bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, fos);
                                    fos.flush();
                                    fos.close();
                                    
                                    // Now convert the file to a URI
                                    imageUri = Uri.fromFile(file);
                                    Log.d(TAG, "Camera image saved to: " + imageUri.toString());
                                } catch (Exception e) {
                                    Log.e(TAG, "Error saving camera image: " + e.getMessage(), e);
                                    Toast.makeText(AddTurfActivity.this, "Error saving image. Please try gallery instead.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error processing camera result: " + e.getMessage(), e);
                            Toast.makeText(AddTurfActivity.this, "Error processing camera image: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );

        galleryLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        // Get image from gallery
                        imageUri = result.getData().getData();
                        if (imageUri != null) {
                            // Display the selected image
                            Glide.with(this)
                                    .load(imageUri)
                                    .centerCrop()
                                    .into(turfImageView);

                            // Make the image view visible
                            turfImageView.setVisibility(View.VISIBLE);
                        }
                    }
                }
        );
    }

    private void checkCameraPermissionAndOpenCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            // Show an explanation if needed
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
                Toast.makeText(this, "Camera permission is needed to take pictures of your turf", 
                        Toast.LENGTH_LONG).show();
            }
            
            // Request the permission
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    REQUEST_CAMERA_PERMISSION);
            
            Log.d(TAG, "Requesting camera permission");
        } else {
            Log.d(TAG, "Camera permission already granted");
            openCamera();
        }
    }

    private void checkGalleryPermissionAndOpenGallery() {
        String permission = Manifest.permission.READ_EXTERNAL_STORAGE;
        
        // For Android 13+, use the new READ_MEDIA_IMAGES permission
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            permission = Manifest.permission.READ_MEDIA_IMAGES;
        }
        
        if (ContextCompat.checkSelfPermission(this, permission)
                != PackageManager.PERMISSION_GRANTED) {
            // Show an explanation if needed
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                Toast.makeText(this, "Gallery permission is needed to select images for your turf", 
                        Toast.LENGTH_LONG).show();
            }
            
            // Request the permission
            ActivityCompat.requestPermissions(this,
                    new String[]{permission},
                    REQUEST_GALLERY_PERMISSION);
            
            Log.d(TAG, "Requesting gallery permission: " + permission);
        } else {
            Log.d(TAG, "Gallery permission already granted");
            openGallery();
        }
    }

    private void openCamera() {
        try {
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (cameraIntent.resolveActivity(getPackageManager()) != null) {
                Log.d(TAG, "Starting camera intent");
                cameraLauncher.launch(cameraIntent);
            } else {
                Log.e(TAG, "No camera app found");
                Toast.makeText(this, "No camera app found on your device", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error opening camera: " + e.getMessage(), e);
            Toast.makeText(this, "Error opening camera: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void openGallery() {
        try {
            Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            Log.d(TAG, "Starting gallery intent");
            galleryLauncher.launch(galleryIntent);
        } catch (Exception e) {
            Log.e(TAG, "Error opening gallery: " + e.getMessage(), e);
            Toast.makeText(this, "Error opening gallery: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        Log.d(TAG, "Permission result received: requestCode=" + requestCode);
        
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "Camera permission granted");
                openCamera();
            } else {
                Log.d(TAG, "Camera permission denied");
                Toast.makeText(this, "Camera permission denied. You can't take pictures without permission.", 
                        Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUEST_GALLERY_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "Gallery permission granted");
                openGallery();
            } else {
                Log.d(TAG, "Gallery permission denied");
                Toast.makeText(this, "Gallery access denied. You can't select images without permission.", 
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    private void setupToolbar() {
        try {
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setTitle("Add New Turf");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error setting up toolbar: " + e.getMessage(), e);
        }
    }

    private void initializeViews() {
        try {
            // Find input layouts
            nameInputLayout = findViewById(R.id.nameInputLayout);
            descriptionInputLayout = findViewById(R.id.descriptionInputLayout);
            locationInputLayout = findViewById(R.id.locationInputLayout);
            priceInputLayout = findViewById(R.id.priceInputLayout);
            contactInfoInputLayout = findViewById(R.id.contactInfoInputLayout);
            openingTimeInputLayout = findViewById(R.id.openingTimeInputLayout);
            closingTimeInputLayout = findViewById(R.id.closingTimeInputLayout);
            upiIdInputLayout = findViewById(R.id.upiIdInputLayout);

            // Find input fields
            nameInput = findViewById(R.id.nameInput);
            descriptionInput = findViewById(R.id.descriptionInput);
            locationInput = findViewById(R.id.locationInput);
            priceInput = findViewById(R.id.priceInput);
            contactInfoInput = findViewById(R.id.contactInfoInput);
            openingTimeInput = findViewById(R.id.openingTimeInput);
            closingTimeInput = findViewById(R.id.closingTimeInput);
            upiIdInput = findViewById(R.id.upiIdInput);

            // Find buttons
            addTurfButton = findViewById(R.id.addTurfButton);
            takePictureButton = findViewById(R.id.takePictureButton);
            selectImageButton = findViewById(R.id.selectImageButton);
            Button selectLocationButton = findViewById(R.id.selectLocationButton);

            // Find image view
            turfImageView = findViewById(R.id.turfImageView);
            
            // Set click listener for select location button
            if (selectLocationButton != null) {
                selectLocationButton.setOnClickListener(v -> openMapForLocationSelection());
            }

            // Check if any views are null
            if (nameInputLayout == null || descriptionInputLayout == null ||
                    locationInputLayout == null || priceInputLayout == null ||
                    contactInfoInputLayout == null || openingTimeInputLayout == null ||
                    closingTimeInputLayout == null || upiIdInputLayout == null ||
                    nameInput == null || descriptionInput == null ||
                    locationInput == null || priceInput == null ||
                    contactInfoInput == null || openingTimeInput == null ||
                    closingTimeInput == null || upiIdInput == null ||
                    addTurfButton == null || takePictureButton == null ||
                    selectImageButton == null || turfImageView == null) {

                Toast.makeText(this, "Error: Some views could not be initialized",
                        Toast.LENGTH_SHORT).show();
                Log.e(TAG, "One or more views could not be initialized");
                finish();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error initializing views: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing views", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private boolean validateInputs() {
        boolean isValid = true;

        // Validate name
        String name = nameInput.getText().toString().trim();
        if (TextUtils.isEmpty(name)) {
            nameInputLayout.setError("Name is required");
            isValid = false;
        } else {
            nameInputLayout.setError(null);
        }

        // Validate description
        String description = descriptionInput.getText().toString().trim();
        if (TextUtils.isEmpty(description)) {
            descriptionInputLayout.setError("Description is required");
            isValid = false;
        } else {
            descriptionInputLayout.setError(null);
        }

        // Validate location
        String location = locationInput.getText().toString().trim();
        if (TextUtils.isEmpty(location)) {
            locationInputLayout.setError("Location is required");
            isValid = false;
        } else {
            locationInputLayout.setError(null);
        }

        // Validate price
        String priceStr = priceInput.getText().toString().trim();
        if (TextUtils.isEmpty(priceStr)) {
            priceInputLayout.setError("Price is required");
            isValid = false;
        } else {
            try {
                double price = Double.parseDouble(priceStr);
                if (price <= 0) {
                    priceInputLayout.setError("Price must be greater than 0");
                    isValid = false;
                } else {
                    priceInputLayout.setError(null);
                }
            } catch (NumberFormatException e) {
                priceInputLayout.setError("Invalid price format");
                isValid = false;
            }
        }

        // Validate contact info
        String contactInfo = contactInfoInput.getText().toString().trim();
        if (TextUtils.isEmpty(contactInfo)) {
            contactInfoInputLayout.setError("Contact information is required");
            isValid = false;
        } else {
            contactInfoInputLayout.setError(null);
        }

        // Validate opening time
        String openingTime = openingTimeInput.getText().toString().trim();
        if (TextUtils.isEmpty(openingTime)) {
            openingTimeInputLayout.setError("Opening time is required");
            isValid = false;
        } else if (!isValidTimeFormat(openingTime)) {
            openingTimeInputLayout.setError("Invalid time format (use HH:MM)");
            isValid = false;
        } else {
            openingTimeInputLayout.setError(null);
        }

        // Validate closing time
        String closingTime = closingTimeInput.getText().toString().trim();
        if (TextUtils.isEmpty(closingTime)) {
            closingTimeInputLayout.setError("Closing time is required");
            isValid = false;
        } else if (!isValidTimeFormat(closingTime)) {
            closingTimeInputLayout.setError("Invalid time format (use HH:MM)");
            isValid = false;
        } else {
            closingTimeInputLayout.setError(null);
        }

        return isValid;
    }

    private boolean isValidTimeFormat(String time) {
        return time.matches("^([01]?[0-9]|2[0-3]):[0-5][0-9]$");
    }

    private void saveTurf(String name, String description, String location, double price,
                          String contactInfo, String openingTime, String closingTime, String imageUrl, String upiId) {
        try {
            // Create a new turf
            Turf turf = new Turf();
            turf.setName(name);
            turf.setDescription(description);
            turf.setLocation(location);
            turf.setPrice(price);
            turf.setContactInfo(contactInfo);
            turf.setOpeningTime(openingTime);
            turf.setClosingTime(closingTime);
            turf.setOwnerId((int) ownerId);
            turf.setImageUrl(imageUrl);
            turf.setUpiId(upiId);
            
            // Set coordinates if they were selected
            if (selectedLatitude != 0 && selectedLongitude != 0) {
                turf.setLatitude(selectedLatitude);
                turf.setLongitude(selectedLongitude);
                Log.d(TAG, "Setting location for turf - Lat: " + selectedLatitude + ", Long: " + selectedLongitude);
            } else {
                Log.d(TAG, "No location coordinates selected for turf");
            }

            // Save to database
            long turfId = dbHelper.addTurf(turf);

            if (turfId > 0) {
                Log.d(TAG, "Turf added successfully with ID: " + turfId);
                Toast.makeText(this, "Turf added successfully!", Toast.LENGTH_SHORT).show();
                // Return to the previous activity
                finish();
            } else {
                Log.e(TAG, "Failed to add turf with ID: " + turfId);
                Toast.makeText(this, "Failed to add turf. Please try again.", Toast.LENGTH_SHORT).show();
                
                // Re-enable the button so the user can try again
                addTurfButton.setEnabled(true);
                addTurfButton.setText("Add Turf");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error saving turf: " + e.getMessage(), e);
            e.printStackTrace();
            Toast.makeText(this, "Error saving turf: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            
            // Re-enable the button so the user can try again
            addTurfButton.setEnabled(true);
            addTurfButton.setText("Add Turf");
        }
    }

    // Handle the result from the map activity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == REQUEST_SELECT_LOCATION && resultCode == RESULT_OK && data != null) {
            selectedLatitude = data.getDoubleExtra("latitude", 0);
            selectedLongitude = data.getDoubleExtra("longitude", 0);
            String address = data.getStringExtra("address");
            
            if (address != null && !address.isEmpty()) {
                locationInput.setText(address);
            } else {
                locationInput.setText(String.format("Lat: %f, Long: %f", selectedLatitude, selectedLongitude));
            }
            
            // Log the location data for debugging
            Log.d(TAG, "Selected location - Lat: " + selectedLatitude + ", Long: " + selectedLongitude);
            Log.d(TAG, "Address: " + address);

            // Display a confirmation to the user
            Toast.makeText(this, "Location selected successfully!", Toast.LENGTH_SHORT).show();
        }
    }
    
    // Method to open map for location selection
    private void openMapForLocationSelection() {
        try {
            // First check if LocationPickerActivity is available
            Intent intent = new Intent(AddTurfActivity.this, LocationPickerActivity.class);
            
            // Check if Google Maps is available
            boolean isMapsAvailable = isGoogleMapsAvailable();
            
            if (!isMapsAvailable) {
                Log.w(TAG, "Google Maps is not available on this device");
                Toast.makeText(this, "Google Maps is not available. Please enter location manually.", Toast.LENGTH_LONG).show();
                showManualLocationEntryDialog();
                return;
            }
            
            if (intent.resolveActivity(getPackageManager()) != null) {
                // Start the activity with a try-catch to handle any potential errors
                try {
                    Log.d(TAG, "Starting LocationPickerActivity for result");
                    startActivityForResult(intent, REQUEST_SELECT_LOCATION);
                } catch (Exception e) {
                    Log.e(TAG, "Error starting map activity: " + e.getMessage(), e);
                    showManualLocationEntryDialog();
                }
            } else {
                Log.e(TAG, "LocationPickerActivity not found in manifest");
                showManualLocationEntryDialog();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error opening location picker: " + e.getMessage(), e);
            showManualLocationEntryDialog();
        }
    }

    // Check if Google Maps is available
    private boolean isGoogleMapsAvailable() {
        try {
            // Check if the Maps SDK is available
            Class<?> mapFragment = Class.forName("com.google.android.gms.maps.SupportMapFragment");
            // If we can load the Map Fragment class, check if the API is properly configured
            android.content.pm.ApplicationInfo appInfo = getPackageManager().getApplicationInfo(
                    getPackageName(), android.content.pm.PackageManager.GET_META_DATA);
            if (appInfo.metaData != null) {
                return appInfo.metaData.containsKey("com.google.android.geo.API_KEY");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error checking Google Maps availability: " + e.getMessage());
        }
        return false;
    }

    // Add a dialog for manual location entry as a fallback
    private void showManualLocationEntryDialog() {
        try {
            // Create dialog with input fields for location
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
            builder.setTitle("Enter Location Manually");
            
            // Create layout for dialog
            android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
            layout.setOrientation(android.widget.LinearLayout.VERTICAL);
            layout.setPadding(20, 20, 20, 20);
            
            // Add input field for location
            final android.widget.EditText locationField = new android.widget.EditText(this);
            locationField.setHint("Enter location (e.g., Mumbai, Maharashtra)");
            layout.addView(locationField);
            
            // Add optional latitude/longitude fields
            android.widget.TextView coordsLabel = new android.widget.TextView(this);
            coordsLabel.setText("Optional: Enter coordinates");
            coordsLabel.setPadding(0, 20, 0, 0);
            layout.addView(coordsLabel);
            
            android.widget.LinearLayout coordsLayout = new android.widget.LinearLayout(this);
            coordsLayout.setOrientation(android.widget.LinearLayout.HORIZONTAL);
            
            android.widget.EditText latField = new android.widget.EditText(this);
            latField.setHint("Latitude");
            latField.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
            latField.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            
            android.widget.EditText longField = new android.widget.EditText(this);
            longField.setHint("Longitude");
            longField.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
            longField.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            
            coordsLayout.addView(latField);
            coordsLayout.addView(longField);
            layout.addView(coordsLayout);
            
            builder.setView(layout);
            
            // Add buttons
            builder.setPositiveButton("Save", (dialog, which) -> {
                String location = locationField.getText().toString().trim();
                
                // Handle entered coordinates if provided
                String latText = latField.getText().toString().trim();
                String longText = longField.getText().toString().trim();
                
                if (!latText.isEmpty() && !longText.isEmpty()) {
                    try {
                        selectedLatitude = Double.parseDouble(latText);
                        selectedLongitude = Double.parseDouble(longText);
                        Log.d(TAG, "Manual coordinates saved - Lat: " + selectedLatitude + ", Long: " + selectedLongitude);
                    } catch (NumberFormatException e) {
                        Log.e(TAG, "Invalid coordinate format: " + e.getMessage());
                        Toast.makeText(this, "Invalid coordinate format", Toast.LENGTH_SHORT).show();
                    }
                }
                
                if (!location.isEmpty()) {
                    locationInput.setText(location);
                    Toast.makeText(this, "Location saved", Toast.LENGTH_SHORT).show();
                }
            });
            
            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
            
            builder.show();
        } catch (Exception e) {
            Log.e(TAG, "Error showing manual location dialog: " + e.getMessage(), e);
            Toast.makeText(this, "Please enter location manually in the field", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}