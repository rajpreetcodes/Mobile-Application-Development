package com.example.ts_project_is_mad;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.text.NumberFormat;
import java.util.Locale;

public class BookingDetailsActivity extends AppCompatActivity {
    private static final String TAG = "BookingDetailsActivity";
    
    private TextView turfNameText;
    private TextView dateText;
    private TextView timeText;
    private TextView priceText;
    private TextView playersText;
    private TextView bookingIdText;
    private TextView statusText;
    private MaterialButton whatsappButton;
    
    private DatabaseHelper dbHelper;
    private Booking booking;
    private Turf turf;
    private User user;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_details);
        
        // Initialize database helper
        dbHelper = new DatabaseHelper(this);
        
        // Set up toolbar
        setupToolbar();
        
        // Initialize views
        initializeViews();
        
        // Load booking details
        loadBookingDetails();
    }
    
    private void setupToolbar() {
        try {
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setTitle("Booking Details");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error setting up toolbar: " + e.getMessage(), e);
        }
    }
    
    private void initializeViews() {
        try {
            // Initialize TextViews
            turfNameText = findViewById(R.id.turfNameText);
            dateText = findViewById(R.id.dateText);
            timeText = findViewById(R.id.timeText);
            priceText = findViewById(R.id.priceText);
            playersText = findViewById(R.id.playersText);
            bookingIdText = findViewById(R.id.bookingIdText);
            statusText = findViewById(R.id.statusText);
            whatsappButton = findViewById(R.id.whatsappButton);
            
            // Set WhatsApp button click listener
            whatsappButton.setOnClickListener(v -> sendWhatsAppConfirmation());
        } catch (Exception e) {
            Log.e(TAG, "Error initializing views: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing views", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void loadBookingDetails() {
        try {
            // Get booking ID from intent
            long bookingId = getIntent().getLongExtra("booking_id", -1);
            if (bookingId == -1) {
                Toast.makeText(this, "Error: No booking selected", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
            
            // Get booking from database
            booking = dbHelper.getBookingById(bookingId);
            if (booking == null) {
                Toast.makeText(this, "Error: Booking not found", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
            
            // Get turf info
            turf = dbHelper.getTurfById(booking.getTurfId());
            
            // Get user info
            String userName = dbHelper.getUserNameById(booking.getUserId());
            if (userName != null) {
                booking.setUserName(userName);
            }
            
            // Display booking details
            displayBookingDetails();
            
        } catch (Exception e) {
            Log.e(TAG, "Error loading booking details: " + e.getMessage(), e);
            Toast.makeText(this, "Error loading booking details", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
    
    private void displayBookingDetails() {
        try {
            // Format currency
            NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
            
            // Set turf name
            if (turf != null) {
                turfNameText.setText(turf.getName());
            } else {
                turfNameText.setText(booking.getTurfName());
            }
            
            // Set booking ID
            bookingIdText.setText("Booking #" + booking.getId());
            
            // Set date
            dateText.setText(booking.getBookingDate());
            
            // Set time range
            timeText.setText(booking.getTimeRange());
            
            // Set players count
            playersText.setText(String.valueOf(booking.getPlayerCount()));
            
            // Set price
            priceText.setText(currencyFormat.format(booking.getTotalPrice()));
            
            // Set status
            statusText.setText(booking.getStatus().toUpperCase());
            
            // Set status text color based on status
            if ("confirmed".equalsIgnoreCase(booking.getStatus())) {
                statusText.setTextColor(getResources().getColor(R.color.green_700));
            } else if ("canceled".equalsIgnoreCase(booking.getStatus())) {
                statusText.setTextColor(getResources().getColor(R.color.red_700));
            } else if ("completed".equalsIgnoreCase(booking.getStatus())) {
                statusText.setTextColor(getResources().getColor(R.color.blue_700));
            }
            
            // Show WhatsApp button only for active bookings
            if ("confirmed".equalsIgnoreCase(booking.getStatus())) {
                whatsappButton.setVisibility(View.VISIBLE);
            } else {
                whatsappButton.setVisibility(View.GONE);
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error displaying booking details: " + e.getMessage(), e);
            Toast.makeText(this, "Error displaying booking details", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void sendWhatsAppConfirmation() {
        try {
            // Get user's phone number
            String phone = dbHelper.getUserPhoneById(booking.getUserId());
            
            // Send WhatsApp confirmation
            WhatsAppUtil.sendBookingConfirmation(this, phone, booking);
        } catch (Exception e) {
            Log.e(TAG, "Error sending WhatsApp confirmation: " + e.getMessage(), e);
            Toast.makeText(this, "Error sending WhatsApp message", Toast.LENGTH_SHORT).show();
        }
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
} 