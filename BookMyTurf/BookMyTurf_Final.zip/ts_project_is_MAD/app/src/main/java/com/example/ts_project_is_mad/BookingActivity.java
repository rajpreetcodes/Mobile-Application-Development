package com.example.ts_project_is_mad;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Currency;
import java.util.List;
import java.util.Locale;

public class BookingActivity extends AppCompatActivity {
    private static final String TAG = "BookingActivity";

    private TextView turfNameText;
    private TextView turfLocationText;
    private TextView turfPriceText;
    private TextInputLayout dateInputLayout;
    private TextInputEditText dateInput;
    private Spinner timeSlotSpinner;
    private TextInputLayout hoursInputLayout;
    private TextInputEditText hoursInput;
    private TextInputLayout playerCountInputLayout;
    private TextInputEditText playerCountInput;
    private TextView pricePerHourText;
    private TextView numberOfHoursText;
    private TextView totalPriceText;
    private TextView pricePerPersonText;
    private Button confirmBookingButton;
    private Button payNowButton;
    private CardView paymentCardView;

    private DatabaseHelper dbHelper;
    private Turf turf;
    private long turfId;
    private long userId = 1; // Default user ID for testing
    private double pricePerHour;
    private int hours = 1;
    private int playerCount = 10;
    private String selectedTimeSlot;
    private String selectedDate;
    private Calendar calendar;
    private NumberFormat currencyFormat;
    private List<String> availableTimeSlots;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Get turf ID from intent
        turfId = getIntent().getLongExtra("turf_id", -1);
        if (turfId == -1) {
            Toast.makeText(this, "Error: No turf selected", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize calendar and currency format
        calendar = Calendar.getInstance();
        currencyFormat = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
        currencyFormat.setCurrency(Currency.getInstance("INR"));

        // Initialize views
        initializeViews();

        // Load turf details
        loadTurfDetails();

        // Setup date picker
        setupDatePicker();

        // Setup time slot spinner
        setupTimeSlotSpinner();

        // Setup input listeners
        setupInputListeners();

        // Setup confirm button
        setupConfirmButton();
    }

    private void setupToolbar() {
        try {
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setTitle("Book Turf");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error setting up toolbar: " + e.getMessage(), e);
        }
    }

    private void initializeViews() {
        try {
            // Set up toolbar
            setupToolbar();

            // Initialize views
            turfNameText = findViewById(R.id.turfNameText);
            turfLocationText = findViewById(R.id.turfLocationText);
            turfPriceText = findViewById(R.id.turfPriceText);
            dateInputLayout = findViewById(R.id.dateInputLayout);
            dateInput = findViewById(R.id.dateInput);
            timeSlotSpinner = findViewById(R.id.timeSlotSpinner);
            hoursInputLayout = findViewById(R.id.hoursInputLayout);
            hoursInput = findViewById(R.id.hoursInput);
            playerCountInputLayout = findViewById(R.id.playerCountInputLayout);
            playerCountInput = findViewById(R.id.playerCountInput);
            pricePerHourText = findViewById(R.id.pricePerHourText);
            numberOfHoursText = findViewById(R.id.numberOfHoursText);
            totalPriceText = findViewById(R.id.totalPriceText);
            pricePerPersonText = findViewById(R.id.pricePerPersonText);
            confirmBookingButton = findViewById(R.id.confirmBookingButton);

            // Add payment section
            paymentCardView = findViewById(R.id.paymentCardView);
            payNowButton = findViewById(R.id.payNowButton);

            if (paymentCardView != null) {
                paymentCardView.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error initializing views: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing booking form", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadTurfDetails() {
        try {
            // Get turf from database
            turf = dbHelper.getTurfById(turfId);

            if (turf != null) {
                // Set turf details
                turfNameText.setText(turf.getName());
                turfLocationText.setText(turf.getLocation());
                pricePerHour = turf.getPrice();
                turfPriceText.setText(currencyFormat.format(pricePerHour) + " per hour");
                pricePerHourText.setText(currencyFormat.format(pricePerHour));

                // Update price calculations
                updatePriceCalculations();
            } else {
                Toast.makeText(this, "Error: Turf not found", Toast.LENGTH_SHORT).show();
                finish();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error loading turf details: " + e.getMessage(), e);
            Toast.makeText(this, "Error loading turf details", Toast.LENGTH_SHORT).show();
        }
    }

    private void setupDatePicker() {
        try {
            // Set current date as default
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            selectedDate = dateFormat.format(calendar.getTime());
            dateInput.setText(selectedDate);

            // Set up date picker dialog
            dateInput.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DatePickerDialog datePickerDialog = new DatePickerDialog(
                            BookingActivity.this,
                            new DatePickerDialog.OnDateSetListener() {
                                @Override
                                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                    calendar.set(Calendar.YEAR, year);
                                    calendar.set(Calendar.MONTH, month);
                                    calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                                    // Update selected date
                                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                                    selectedDate = dateFormat.format(calendar.getTime());
                                    dateInput.setText(selectedDate);

                                    // Refresh available time slots for the new date
                                    refreshAvailableTimeSlots();
                                }
                            },
                            calendar.get(Calendar.YEAR),
                            calendar.get(Calendar.MONTH),
                            calendar.get(Calendar.DAY_OF_MONTH)
                    );

                    // Set min date to today
                    datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);

                    datePickerDialog.show();
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error setting up date picker: " + e.getMessage(), e);
        }
    }

    private void refreshAvailableTimeSlots() {
        try {
            if (turf != null && !TextUtils.isEmpty(selectedDate)) {
                // Get all booked time slots for this turf on the selected date
                List<String> bookedSlots = dbHelper.getBookedTimeSlots(turfId, selectedDate);

                // Get all available time slots for this turf
                String[] allSlots = getTimeSlots(turf.getOpeningTime(), turf.getClosingTime());

                // Filter out booked slots
                availableTimeSlots = new ArrayList<>();
                for (String slot : allSlots) {
                    if (!bookedSlots.contains(slot)) {
                        availableTimeSlots.add(slot);
                    }
                }

                // Update spinner
                ArrayAdapter<String> adapter = new ArrayAdapter<>(
                        this, android.R.layout.simple_spinner_item, availableTimeSlots);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                timeSlotSpinner.setAdapter(adapter);

                if (availableTimeSlots.isEmpty()) {
                    Toast.makeText(this, "No available time slots for this date", Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error refreshing time slots: " + e.getMessage(), e);
            Toast.makeText(this, "Error loading available time slots", Toast.LENGTH_SHORT).show();
        }
    }

    private String[] getTimeSlots(String openingTime, String closingTime) {
        try {
            // Parse opening and closing times
            String[] openParts = openingTime.split(":");
            String[] closeParts = closingTime.split(":");

            int openHour = Integer.parseInt(openParts[0]);
            int closeHour = Integer.parseInt(closeParts[0]);

            // Create time slots (hourly)
            List<String> slots = new ArrayList<>();
            for (int hour = openHour; hour < closeHour; hour++) {
                slots.add(String.format(Locale.getDefault(), "%02d:00", hour));
            }

            return slots.toArray(new String[0]);
        } catch (Exception e) {
            Log.e(TAG, "Error generating time slots: " + e.getMessage(), e);
            // Return default slots if error
            return new String[]{"06:00", "07:00", "08:00", "09:00", "10:00",
                    "11:00", "12:00", "13:00", "14:00", "15:00",
                    "16:00", "17:00", "18:00", "19:00", "20:00", "21:00"};
        }
    }

    private void setupTimeSlotSpinner() {
        try {
            // Set default time slots
            String[] defaultSlots = {"06:00", "07:00", "08:00", "09:00", "10:00",
                    "11:00", "12:00", "13:00", "14:00", "15:00",
                    "16:00", "17:00", "18:00", "19:00", "20:00", "21:00"};

            availableTimeSlots = new ArrayList<>();
            for (String slot : defaultSlots) {
                availableTimeSlots.add(slot);
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<>(
                    this, android.R.layout.simple_spinner_item, availableTimeSlots);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            timeSlotSpinner.setAdapter(adapter);

            timeSlotSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    selectedTimeSlot = availableTimeSlots.get(position);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    if (!availableTimeSlots.isEmpty()) {
                        selectedTimeSlot = availableTimeSlots.get(0);
                    }
                }
            });

            // Refresh available time slots for the current date
            refreshAvailableTimeSlots();
        } catch (Exception e) {
            Log.e(TAG, "Error setting up time slot spinner: " + e.getMessage(), e);
        }
    }

    private void setupInputListeners() {
        try {
            // Hours input listener
            hoursInput.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    // Not used
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    // Not used
                }

                @Override
                public void afterTextChanged(Editable s) {
                    try {
                        String hoursStr = s.toString();
                        if (!TextUtils.isEmpty(hoursStr)) {
                            hours = Integer.parseInt(hoursStr);

                            // Validate hours (1-8)
                            if (hours < 1) {
                                hours = 1;
                                hoursInput.setText(String.valueOf(hours));
                                hoursInput.setSelection(hoursInput.getText().length());
                                Toast.makeText(BookingActivity.this,
                                        "Minimum booking is 1 hour", Toast.LENGTH_SHORT).show();
                            } else if (hours > 8) {
                                hours = 8;
                                hoursInput.setText(String.valueOf(hours));
                                hoursInput.setSelection(hoursInput.getText().length());
                                Toast.makeText(BookingActivity.this,
                                        "Maximum booking is 8 hours", Toast.LENGTH_SHORT).show();
                            }

                            // Update price calculations
                            updatePriceCalculations();
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error processing hours input: " + e.getMessage(), e);
                    }
                }
            });

            // Player count input listener
            playerCountInput.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    // Not used
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    // Not used
                }

                @Override
                public void afterTextChanged(Editable s) {
                    try {
                        String countStr = s.toString();
                        if (!TextUtils.isEmpty(countStr)) {
                            playerCount = Integer.parseInt(countStr);

                            // Validate player count (1-30)
                            if (playerCount < 1) {
                                playerCount = 1;
                                playerCountInput.setText(String.valueOf(playerCount));
                                playerCountInput.setSelection(playerCountInput.getText().length());
                                Toast.makeText(BookingActivity.this,
                                        "Minimum player count is 1", Toast.LENGTH_SHORT).show();
                            } else if (playerCount > 30) {
                                playerCount = 30;
                                playerCountInput.setText(String.valueOf(playerCount));
                                playerCountInput.setSelection(playerCountInput.getText().length());
                                Toast.makeText(BookingActivity.this,
                                        "Maximum player count is 30", Toast.LENGTH_SHORT).show();
                            }

                            // Update price calculations
                            updatePriceCalculations();
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error processing player count input: " + e.getMessage(), e);
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error setting up input listeners: " + e.getMessage(), e);
        }
    }

    private void updatePriceCalculations() {
        try {
            // Calculate total price
            double totalPrice = pricePerHour * hours;

            // Update UI
            numberOfHoursText.setText(String.valueOf(hours));
            totalPriceText.setText(currencyFormat.format(totalPrice));

            // Calculate and update price per person
            if (playerCount > 0) {
                double pricePerPerson = totalPrice / playerCount;
                pricePerPersonText.setText(currencyFormat.format(pricePerPerson));
            } else {
                pricePerPersonText.setText(currencyFormat.format(totalPrice));
            }
        } catch (Exception e) {
            Log.e(TAG, "Error updating price calculations: " + e.getMessage(), e);
        }
    }

    private void setupConfirmButton() {
        try {
            confirmBookingButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (validateInputs()) {
                        // Show confirmation dialog instead of immediately saving
                        showBookingConfirmationDialog();
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error setting up confirm button: " + e.getMessage(), e);
        }
    }

    private void showBookingConfirmationDialog() {
        try {
            // Calculate total price for confirmation message
            double totalPrice = pricePerHour * hours;
            String formattedPrice = currencyFormat.format(totalPrice);

            // Create an AlertDialog to confirm booking with Material Design
            MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
            builder.setTitle("Confirm Booking");
            builder.setMessage("You are about to book " + turf.getName() +
                    "\nDate: " + selectedDate +
                    "\nTime: " + selectedTimeSlot +
                    "\nDuration: " + hours + " hour(s)" +
                    "\nPlayers: " + playerCount +
                    "\nTotal Price: " + formattedPrice);

            builder.setPositiveButton("Confirm", (dialog, which) -> {
                // Process the booking
                saveBooking();
            });

            builder.setNegativeButton("Cancel", (dialog, which) -> {
                dialog.dismiss();
            });

            builder.show();
        } catch (Exception e) {
            Log.e(TAG, "Error showing confirmation dialog: " + e.getMessage(), e);
            // Fallback to direct booking if dialog fails
            saveBooking();
        }
    }

    private boolean validateInputs() {
        try {
            boolean isValid = true;

            // Validate date
            if (TextUtils.isEmpty(selectedDate)) {
                dateInputLayout.setError("Please select a date");
                isValid = false;
            } else {
                dateInputLayout.setError(null);
            }

            // Validate time slot
            if (TextUtils.isEmpty(selectedTimeSlot)) {
                Toast.makeText(this, "Please select a time slot", Toast.LENGTH_SHORT).show();
                isValid = false;
            }

            // Validate hours
            String hoursStr = hoursInput.getText().toString();
            if (TextUtils.isEmpty(hoursStr)) {
                hoursInputLayout.setError("Please enter number of hours");
                isValid = false;
            } else {
                int hours = Integer.parseInt(hoursStr);
                if (hours < 1 || hours > 8) {
                    hoursInputLayout.setError("Hours must be between 1 and 8");
                    isValid = false;
                } else {
                    hoursInputLayout.setError(null);
                }
            }

            // Validate player count
            String countStr = playerCountInput.getText().toString();
            if (TextUtils.isEmpty(countStr)) {
                playerCountInputLayout.setError("Please enter number of players");
                isValid = false;
            } else {
                int count = Integer.parseInt(countStr);
                if (count < 1 || count > 30) {
                    playerCountInputLayout.setError("Player count must be between 1 and 30");
                    isValid = false;
                } else {
                    playerCountInputLayout.setError(null);
                }
            }

            return isValid;
        } catch (Exception e) {
            Log.e(TAG, "Error validating inputs: " + e.getMessage(), e);
            Toast.makeText(this, "Error validating booking details", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private void saveBooking() {
        try {
            // Calculate total price
            double totalPrice = pricePerHour * hours;

            // Get current user details
            User currentUser = SessionManager.getLoggedInUser(this);
            String userPhone = null;
            
            if (currentUser == null) {
                // Fallback if session management isn't implemented yet
                currentUser = new User();
                currentUser.setId(userId);
                // Try to get user info from database
                String userName = dbHelper.getUserNameById(userId);
                if (userName != null) {
                    currentUser.setName(userName);
                }
                
                try {
                    // Try to get phone - this now has graceful fallback if column doesn't exist
                    userPhone = dbHelper.getUserPhoneById(userId);
                    if (userPhone != null && !userPhone.startsWith("Error:") && !userPhone.equals("No phone available")) {
                        currentUser.setPhone(userPhone);
                    } else {
                        // Set a fallback phone number for testing
                        currentUser.setPhone("1234567890");
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error getting user phone: " + e.getMessage());
                    // Set a fallback phone number
                    currentUser.setPhone("1234567890");
                }
            } else {
                // If phone is not set in the session, try to get it from DB
                if (currentUser.getPhone() == null || currentUser.getPhone().isEmpty()) {
                    try {
                        userPhone = dbHelper.getUserPhoneById(currentUser.getId());
                        if (userPhone != null && !userPhone.startsWith("Error:") && !userPhone.equals("No phone available")) {
                            currentUser.setPhone(userPhone);
                        } else {
                            // Set a fallback phone number for testing
                            currentUser.setPhone("1234567890");
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error getting user phone from session: " + e.getMessage());
                        // Set a fallback phone number
                        currentUser.setPhone("1234567890");
                    }
                }
            }

            // Save booking to database
            long bookingId = dbHelper.addBooking(
                    currentUser.getId(),
                    turfId,
                    selectedDate,
                    selectedTimeSlot,
                    hours,
                    playerCount,
                    totalPrice
            );

            if (bookingId != -1) {
                // Create a booking object with all details for WhatsApp
                Booking booking = new Booking(
                        currentUser.getId(),
                        turfId,
                        selectedDate,
                        selectedTimeSlot,
                        hours,
                        playerCount,
                        totalPrice
                );
                booking.setId(bookingId);
                booking.setTurfName(turf.getName());
                booking.setTurfLocation(turf.getLocation());
                
                // Show success message with material design snackbar
                View rootView = findViewById(android.R.id.content);
                Snackbar.make(rootView, "Booking confirmed! Booking ID: " + bookingId, Snackbar.LENGTH_LONG)
                        .setAction("View Details", v -> {
                            // Open booking details activity
                            Intent intent = new Intent(BookingActivity.this, BookingDetailsActivity.class);
                            intent.putExtra("booking_id", bookingId);
                            startActivity(intent);
                            finish();
                        })
                        .setActionTextColor(getResources().getColor(R.color.green_500))
                        .show();
                
                // Ask if user wants to receive WhatsApp confirmation
                askForWhatsAppConfirmation(booking, currentUser.getPhone());
            } else {
                // Show error with material design
                new MaterialAlertDialogBuilder(this)
                        .setTitle("Booking Failed")
                        .setMessage("Unable to save your booking. Please try again.")
                        .setPositiveButton("Try Again", (dialog, which) -> {
                            dialog.dismiss();
                        })
                        .setNegativeButton("Cancel", (dialog, which) -> {
                            dialog.dismiss();
                            finish();
                        })
                        .show();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error saving booking: " + e.getMessage(), e);
            Toast.makeText(this, "Error saving booking: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Ask user if they want to receive a WhatsApp confirmation message
     */
    private void askForWhatsAppConfirmation(Booking booking, String phone) {
        try {
            // Only ask if WhatsApp is installed
            if (WhatsAppUtil.isWhatsAppInstalled(this)) {
                new MaterialAlertDialogBuilder(this)
                        .setTitle("Booking Confirmation")
                        .setMessage("Would you like to receive your booking details on WhatsApp?")
                        .setIcon(R.drawable.ic_whatsapp)
                        .setPositiveButton("Yes, Send", (dialog, which) -> {
                            // Send WhatsApp message
                            WhatsAppUtil.sendBookingConfirmation(this, phone, booking);
                            finish();
                        })
                        .setNegativeButton("No, Thanks", (dialog, which) -> {
                            dialog.dismiss();
                            finish();
                        })
                        .show();
            } else {
                // If WhatsApp not installed, just finish the activity
                finish();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error showing WhatsApp dialog: " + e.getMessage(), e);
            finish();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}