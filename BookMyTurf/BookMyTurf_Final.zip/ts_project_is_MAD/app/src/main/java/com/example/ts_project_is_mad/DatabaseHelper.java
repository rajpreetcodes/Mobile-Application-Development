package com.example.ts_project_is_mad;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String TAG = "DatabaseHelper";
    private static final String DATABASE_NAME = "TurfBooking.db";
    private static final int DATABASE_VERSION = 8; // Increased version for new columns
    private final Context context;

    // Table names
    private static final String TABLE_USERS = "users";
    private static final String TABLE_TURFS = "turfs";
    private static final String TABLE_BOOKINGS = "bookings";
    private static final String TABLE_REVIEWS = "reviews";

    // Common column names
    private static final String KEY_ID = "id";
    private static final String KEY_CREATED_AT = "created_at";

    // User table column names
    private static final String KEY_NAME = "name";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_PASSWORD = "password";
    private static final String KEY_USER_TYPE = "user_type";
    private static final String KEY_PHONE = "phone";

    // Turf table column names
    private static final String KEY_TURF_NAME = "turf_name";
    private static final String KEY_DESCRIPTION = "description";
    private static final String KEY_LOCATION = "location";
    private static final String KEY_PRICE = "price";
    private static final String KEY_OWNER_ID = "owner_id";
    private static final String KEY_CONTACT_INFO = "contact_info";
    private static final String KEY_OPENING_TIME = "opening_time";
    private static final String KEY_CLOSING_TIME = "closing_time";
    private static final String KEY_IMAGE_URL = "image_url";
    private static final String KEY_LATITUDE = "latitude";
    private static final String KEY_LONGITUDE = "longitude";
    private static final String KEY_UPI_ID = "upi_id";
    private static final String KEY_PAYMENT_METHOD = "payment_method";

    // Booking table column names
    private static final String KEY_BOOKING_ID = "booking_id";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_TURF_ID = "turf_id";
    private static final String KEY_BOOKING_DATE = "booking_date";
    private static final String KEY_TIME_SLOT = "time_slot";
    private static final String KEY_HOURS = "hours";
    private static final String KEY_PLAYER_COUNT = "player_count";
    private static final String KEY_TOTAL_PRICE = "total_price";
    private static final String KEY_BOOKING_STATUS = "booking_status";

    // Create table statements
    private static final String CREATE_TABLE_USERS = "CREATE TABLE " + TABLE_USERS +
            "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            KEY_NAME + " TEXT," +
            KEY_EMAIL + " TEXT UNIQUE," +
            KEY_PASSWORD + " TEXT," +
            KEY_USER_TYPE + " TEXT," +
            KEY_PHONE + " TEXT," +
            KEY_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP)";

    private static final String CREATE_TABLE_TURFS = "CREATE TABLE " + TABLE_TURFS +
            "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            KEY_TURF_NAME + " TEXT," +
            KEY_DESCRIPTION + " TEXT," +
            KEY_LOCATION + " TEXT," +
            KEY_PRICE + " REAL," +
            KEY_OWNER_ID + " INTEGER," +
            KEY_CONTACT_INFO + " TEXT," +
            KEY_OPENING_TIME + " TEXT DEFAULT '06:00'," +
            KEY_CLOSING_TIME + " TEXT DEFAULT '22:00'," +
            KEY_IMAGE_URL + " TEXT," +
            KEY_LATITUDE + " REAL," +
            KEY_LONGITUDE + " REAL," +
            KEY_UPI_ID + " TEXT," +
            KEY_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP," +
            "FOREIGN KEY(" + KEY_OWNER_ID + ") REFERENCES " + TABLE_USERS + "(" + KEY_ID + "))";

    // Create table for bookings
    private static final String CREATE_TABLE_BOOKINGS = "CREATE TABLE " + TABLE_BOOKINGS +
            "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            KEY_USER_ID + " INTEGER," +
            KEY_TURF_ID + " INTEGER," +
            KEY_BOOKING_DATE + " TEXT," +
            KEY_TIME_SLOT + " TEXT," +
            KEY_HOURS + " INTEGER," +
            KEY_PLAYER_COUNT + " INTEGER," +
            KEY_TOTAL_PRICE + " REAL," +
            KEY_BOOKING_STATUS + " TEXT DEFAULT 'confirmed'," +
            KEY_PAYMENT_METHOD + " TEXT DEFAULT 'cash'," +
            KEY_UPI_ID + " TEXT," +
            KEY_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP," +
            "FOREIGN KEY(" + KEY_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + KEY_ID + ")," +
            "FOREIGN KEY(" + KEY_TURF_ID + ") REFERENCES " + TABLE_TURFS + "(" + KEY_ID + "))";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            Log.d(TAG, "Creating database tables");
            
            // Drop existing tables if they exist to ensure we have the latest schema
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKINGS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_TURFS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
            
            // Create the tables with the latest schema
            db.execSQL(CREATE_TABLE_USERS);
            db.execSQL(CREATE_TABLE_TURFS);
            db.execSQL(CREATE_TABLE_BOOKINGS);
            Log.d(TAG, "Database tables created successfully");
        } catch (Exception e) {
            Log.e(TAG, "Error creating database tables: " + e.getMessage(), e);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            Log.d(TAG, "Upgrading database from version " + oldVersion + " to " + newVersion);

            if (oldVersion < 4) {
                // Add the image_url column to the turfs table if upgrading from version < 4
                try {
                    db.execSQL("ALTER TABLE " + TABLE_TURFS + " ADD COLUMN " + KEY_IMAGE_URL + " TEXT");
                    Log.d(TAG, "Added image_url column to turfs table");
                } catch (Exception e) {
                    Log.e(TAG, "Error adding image_url column: " + e.getMessage(), e);
                }
            }
            
            if (oldVersion < 5) {
                // Add latitude and longitude columns if upgrading from version < 5
                try {
                    db.execSQL("ALTER TABLE " + TABLE_TURFS + " ADD COLUMN " + KEY_LATITUDE + " REAL");
                    db.execSQL("ALTER TABLE " + TABLE_TURFS + " ADD COLUMN " + KEY_LONGITUDE + " REAL");
                    Log.d(TAG, "Added latitude and longitude columns to turfs table");
                } catch (Exception e) {
                    Log.e(TAG, "Error adding coordinates columns: " + e.getMessage(), e);
                }
            }
            
            if (oldVersion < 6) {
                // For version 6, ensure coordinate columns exist and are working
                try {
                    // Check if the columns exist first to avoid errors
                    Cursor cursor = db.rawQuery("PRAGMA table_info(" + TABLE_TURFS + ")", null);
                    boolean hasLatitude = false;
                    boolean hasLongitude = false;
                    
                    if (cursor != null) {
                        int nameIndex = cursor.getColumnIndex("name");
                        if (nameIndex != -1) {
                            while (cursor.moveToNext()) {
                                String columnName = cursor.getString(nameIndex);
                                if (KEY_LATITUDE.equals(columnName)) {
                                    hasLatitude = true;
                                } else if (KEY_LONGITUDE.equals(columnName)) {
                                    hasLongitude = true;
                                }
                            }
                        }
                        cursor.close();
                    }
                    
                    // Add columns if they don't exist
                    if (!hasLatitude) {
                        db.execSQL("ALTER TABLE " + TABLE_TURFS + " ADD COLUMN " + KEY_LATITUDE + " REAL");
                        Log.d(TAG, "Added latitude column to turfs table during v6 upgrade");
                    }
                    
                    if (!hasLongitude) {
                        db.execSQL("ALTER TABLE " + TABLE_TURFS + " ADD COLUMN " + KEY_LONGITUDE + " REAL");
                        Log.d(TAG, "Added longitude column to turfs table during v6 upgrade");
                    }
                    
                    Log.d(TAG, "Verified coordinate columns for version 6 upgrade");
                } catch (Exception e) {
                    Log.e(TAG, "Error during version 6 upgrade: " + e.getMessage(), e);
                }
            }
            
            if (oldVersion < 7) {
                // For version 7, fix column name issue by recreating tables
                Log.d(TAG, "Performing database upgrade to version 7 - recreating tables with correct column names");
                try {
                    // Backup any existing data
                    List<Turf> turfs = new ArrayList<>();
                    try {
                        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_TURFS, null);
                        if (cursor != null && cursor.moveToFirst()) {
                            // We won't attempt to load the data since the column names might be inconsistent
                            Log.d(TAG, "Found " + cursor.getCount() + " turfs in database before upgrade");
                            cursor.close();
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error backing up turfs: " + e.getMessage());
                    }
                    
                    // Drop and recreate all tables to ensure schema consistency
                    db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKINGS);
                    db.execSQL("DROP TABLE IF EXISTS " + TABLE_TURFS);
                    db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
                    onCreate(db);
                    
                    Log.d(TAG, "Tables recreated with correct column names");
                } catch (Exception e) {
                    Log.e(TAG, "Error during version 7 upgrade: " + e.getMessage(), e);
                }
            }
            
            if (oldVersion < 8) {
                // Add UPI ID column to turfs table
                try {
                    db.execSQL("ALTER TABLE " + TABLE_TURFS + " ADD COLUMN " + KEY_UPI_ID + " TEXT");
                    Log.d(TAG, "Added UPI ID column to turfs table");
                } catch (Exception e) {
                    Log.e(TAG, "Error adding UPI ID column: " + e.getMessage(), e);
                }
                
                // Add payment method column to bookings table
                try {
                    db.execSQL("ALTER TABLE " + TABLE_BOOKINGS + " ADD COLUMN " + KEY_PAYMENT_METHOD + " TEXT DEFAULT 'cash'");
                    Log.d(TAG, "Added payment method column to bookings table");
                } catch (Exception e) {
                    Log.e(TAG, "Error adding payment method column: " + e.getMessage(), e);
                }
            }
            
            // Only do complete reset if absolutely necessary
            if (oldVersion < 2) {
                // For complete database reset
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKINGS);
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_TURFS);
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
                onCreate(db);
            }

            Log.d(TAG, "Database upgrade completed successfully");
        } catch (Exception e) {
            Log.e(TAG, "Error upgrading database: " + e.getMessage(), e);
        }
    }

    // ... existing methods ...

    /**
     * Add a new turf to the database with image URL
     * @param name The name of the turf
     * @param description The description of the turf
     * @param location The location of the turf
     * @param price The price per hour
     * @param ownerId The ID of the owner
     * @param contactInfo Contact information for the turf
     * @param openingTime Opening time in 24-hour format (HH:MM)
     * @param closingTime Closing time in 24-hour format (HH:MM)
     * @param imageUrl URL to the turf image in Firebase Storage
     * @return The ID of the newly inserted turf, or -1 if the operation failed
     */
    public long addTurf(String name, String description, String location, double price,
                        int ownerId, String contactInfo, String openingTime, String closingTime, String imageUrl) {
        SQLiteDatabase db = null;
        long id = -1;

        try {
            Log.d(TAG, String.format("Adding turf - Name: %s, Location: %s, Price: %.2f, Owner ID: %d, Contact: %s, ImageUrl: %s",
                    name, location, price, ownerId, contactInfo, imageUrl));

            db = this.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(KEY_TURF_NAME, name);
            values.put(KEY_DESCRIPTION, description);
            values.put(KEY_LOCATION, location);
            values.put(KEY_PRICE, price);
            values.put(KEY_OWNER_ID, ownerId);
            values.put(KEY_CONTACT_INFO, contactInfo);
            values.put(KEY_OPENING_TIME, openingTime);
            values.put(KEY_CLOSING_TIME, closingTime);
            if (imageUrl != null) {
                values.put(KEY_IMAGE_URL, imageUrl);
            }

            // Insert row
            id = db.insert(TABLE_TURFS, null, values);
            
            if (id > 0) {
                Log.d(TAG, "Added turf with ID: " + id);
            } else {
                Log.e(TAG, "Failed to add turf with values: " + values);
            }
            
            return id;
        } catch (Exception e) {
            Log.e(TAG, "Error adding turf: " + e.getMessage(), e);
            return -1;
        } finally {
            if (db != null && db.isOpen()) {
                db.close();
            }
        }
    }

    /**
     * Add a new turf to the database (simplified version for backward compatibility)
     */
    public long addTurf(String name, String description, String location, double price, int ownerId) {
        return addTurf(name, description, location, price, ownerId,
                "Contact information not available", "06:00", "22:00", null);
    }

    /**
     * Add a turf to the database using a Turf object
     * @param turf The Turf object containing all information
     * @return The ID of the newly added turf, or -1 if failed
     */
    public long addTurf(Turf turf) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        
        values.put(KEY_TURF_NAME, turf.getName());
        values.put(KEY_DESCRIPTION, turf.getDescription());
        values.put(KEY_LOCATION, turf.getLocation());
        values.put(KEY_PRICE, turf.getPrice());
        values.put(KEY_OWNER_ID, turf.getOwnerId());
        values.put(KEY_CONTACT_INFO, turf.getContactInfo());
        values.put(KEY_OPENING_TIME, turf.getOpeningTime());
        values.put(KEY_CLOSING_TIME, turf.getClosingTime());
        values.put(KEY_IMAGE_URL, turf.getImageUrl());
        values.put(KEY_LATITUDE, turf.getLatitude());
        values.put(KEY_LONGITUDE, turf.getLongitude());
        values.put(KEY_UPI_ID, turf.getUpiId());
        
        // Insert row
        long id = db.insert(TABLE_TURFS, null, values);
        db.close();
        
        return id;
    }

    // ... other methods ...

    // Update the getAllTurfsAsList method to retrieve the image URL
    public List<Turf> getAllTurfsAsList() {
        List<Turf> turfList = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;

        try {
            db = this.getReadableDatabase();

            Log.d(TAG, "Getting all turfs from database");

            String[] columns = {
                    KEY_ID,
                    KEY_TURF_NAME,
                    KEY_DESCRIPTION,
                    KEY_LOCATION,
                    KEY_PRICE,
                    KEY_OWNER_ID,
                    KEY_CONTACT_INFO,
                    KEY_OPENING_TIME,
                    KEY_CLOSING_TIME,
                    KEY_IMAGE_URL,
                    KEY_LATITUDE,
                    KEY_LONGITUDE
            };

            String orderBy = KEY_CREATED_AT + " DESC";

            cursor = db.query(TABLE_TURFS, columns, null, null, null, null, orderBy);

            Log.d(TAG, "Query returned " + (cursor != null ? cursor.getCount() : 0) + " turfs");

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    int idIndex = cursor.getColumnIndex(KEY_ID);
                    int nameIndex = cursor.getColumnIndex(KEY_TURF_NAME);
                    int descIndex = cursor.getColumnIndex(KEY_DESCRIPTION);
                    int locIndex = cursor.getColumnIndex(KEY_LOCATION);
                    int priceIndex = cursor.getColumnIndex(KEY_PRICE);
                    int ownerIdIndex = cursor.getColumnIndex(KEY_OWNER_ID);
                    int contactIndex = cursor.getColumnIndex(KEY_CONTACT_INFO);
                    int openTimeIndex = cursor.getColumnIndex(KEY_OPENING_TIME);
                    int closeTimeIndex = cursor.getColumnIndex(KEY_CLOSING_TIME);
                    int imageUrlIndex = cursor.getColumnIndex(KEY_IMAGE_URL);
                    int latIndex = cursor.getColumnIndex(KEY_LATITUDE);
                    int lngIndex = cursor.getColumnIndex(KEY_LONGITUDE);

                    // Check if all required columns exist
                    if (idIndex == -1 || nameIndex == -1 || descIndex == -1 ||
                            locIndex == -1 || priceIndex == -1) {
                        Log.e(TAG, "Missing required columns in turf query result");
                        continue;
                    }

                    Turf turf = new Turf(
                            cursor.getLong(idIndex),
                            cursor.getString(nameIndex),
                            cursor.getString(descIndex),
                            cursor.getString(locIndex),
                            cursor.getDouble(priceIndex)
                    );

                    // Set owner ID if available
                    if (ownerIdIndex != -1) {
                        turf.setOwnerId(cursor.getInt(ownerIdIndex));
                    }

                    // Set contact info if available
                    if (contactIndex != -1) {
                        turf.setContactInfo(cursor.getString(contactIndex));
                    }

                    // Set opening/closing times if available
                    if (openTimeIndex != -1) {
                        turf.setOpeningTime(cursor.getString(openTimeIndex));
                    }

                    if (closeTimeIndex != -1) {
                        turf.setClosingTime(cursor.getString(closeTimeIndex));
                    }

                    // Set image URL if available
                    if (imageUrlIndex != -1 && !cursor.isNull(imageUrlIndex)) {
                        turf.setImageUrl(cursor.getString(imageUrlIndex));
                    }
                    
                    // Set latitude and longitude if available
                    if (latIndex != -1 && !cursor.isNull(latIndex)) {
                        turf.setLatitude(cursor.getDouble(latIndex));
                    }
                    
                    if (lngIndex != -1 && !cursor.isNull(lngIndex)) {
                        turf.setLongitude(cursor.getDouble(lngIndex));
                    }

                    turfList.add(turf);
                    Log.d(TAG, "Added turf: " + turf.getName() + " (ID: " + turf.getId() + ")");
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting all turfs: " + e.getMessage(), e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null && db.isOpen()) {
                db.close();
            }
        }

        return turfList;
    }

    // ... other methods ...

    // Make sure to update getTurfById to include imageUrl
    public Turf getTurfById(long turfId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Turf turf = null;
        Cursor cursor = null;
        
        try {
            String query = "SELECT * FROM " + TABLE_TURFS + " WHERE " + KEY_ID + " = ?";
            cursor = db.rawQuery(query, new String[]{String.valueOf(turfId)});
            
            if (cursor != null && cursor.moveToFirst()) {
                turf = new Turf();
                turf.setId(cursor.getLong(cursor.getColumnIndex(KEY_ID)));
                turf.setName(cursor.getString(cursor.getColumnIndex(KEY_TURF_NAME)));
                turf.setDescription(cursor.getString(cursor.getColumnIndex(KEY_DESCRIPTION)));
                turf.setLocation(cursor.getString(cursor.getColumnIndex(KEY_LOCATION)));
                turf.setPrice(cursor.getDouble(cursor.getColumnIndex(KEY_PRICE)));
                turf.setOwnerId(cursor.getInt(cursor.getColumnIndex(KEY_OWNER_ID)));
                turf.setContactInfo(cursor.getString(cursor.getColumnIndex(KEY_CONTACT_INFO)));
                
                // Get opening and closing times if available
                int openingTimeIndex = cursor.getColumnIndex(KEY_OPENING_TIME);
                int closingTimeIndex = cursor.getColumnIndex(KEY_CLOSING_TIME);
                
                if (openingTimeIndex != -1 && !cursor.isNull(openingTimeIndex)) {
                    turf.setOpeningTime(cursor.getString(openingTimeIndex));
                }
                
                if (closingTimeIndex != -1 && !cursor.isNull(closingTimeIndex)) {
                    turf.setClosingTime(cursor.getString(closingTimeIndex));
                }
                
                // Get image URL if available
                int imageUrlIndex = cursor.getColumnIndex(KEY_IMAGE_URL);
                if (imageUrlIndex != -1 && !cursor.isNull(imageUrlIndex)) {
                    turf.setImageUrl(cursor.getString(imageUrlIndex));
                }
                
                // Get coordinates if available
                int latIndex = cursor.getColumnIndex(KEY_LATITUDE);
                int longIndex = cursor.getColumnIndex(KEY_LONGITUDE);
                
                if (latIndex != -1 && !cursor.isNull(latIndex)) {
                    turf.setLatitude(cursor.getDouble(latIndex));
                }
                
                if (longIndex != -1 && !cursor.isNull(longIndex)) {
                    turf.setLongitude(cursor.getDouble(longIndex));
                }
                
                // Get UPI ID if available
                int upiIdIndex = cursor.getColumnIndex(KEY_UPI_ID);
                if (upiIdIndex != -1 && !cursor.isNull(upiIdIndex)) {
                    turf.setUpiId(cursor.getString(upiIdIndex));
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting turf by ID: " + e.getMessage(), e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null && db.isOpen()) {
                db.close();
            }
        }
        
        return turf;
    }

    // Make sure to update updateTurf method to include imageUrl
    public int updateTurf(Turf turf) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_TURF_NAME, turf.getName());
        values.put(KEY_DESCRIPTION, turf.getDescription());
        values.put(KEY_LOCATION, turf.getLocation());
        values.put(KEY_PRICE, turf.getPrice());
        values.put(KEY_CONTACT_INFO, turf.getContactInfo());
        values.put(KEY_OPENING_TIME, turf.getOpeningTime());
        values.put(KEY_CLOSING_TIME, turf.getClosingTime());
        values.put(KEY_OWNER_ID, turf.getOwnerId());
        if (turf.getImageUrl() != null) {
            values.put(KEY_IMAGE_URL, turf.getImageUrl());
        }
        
        // Add latitude and longitude
        if (turf.getLatitude() != 0 || turf.getLongitude() != 0) {
            values.put(KEY_LATITUDE, turf.getLatitude());
            values.put(KEY_LONGITUDE, turf.getLongitude());
        }

        return db.update(TABLE_TURFS, values, KEY_ID + "=?", new String[]{String.valueOf(turf.getId())});
    }

    /**
     * Add a new booking to the database
     * @param userId The ID of the user making the booking
     * @param turfId The ID of the turf being booked
     * @param bookingDate The date of the booking
     * @param timeSlot The time slot being booked
     * @param hours Number of hours booked
     * @param playerCount Number of players
     * @param totalPrice Total price of the booking
     * @return The ID of the new booking, or -1 if the booking failed
     */
    public long addBooking(long userId, long turfId, String bookingDate,
                           String timeSlot, int hours, int playerCount, double totalPrice) {
        SQLiteDatabase db = null;
        long bookingId = -1;

        try {
            // First check if the time slot is available
            if (isTimeSlotAvailable(turfId, bookingDate, timeSlot)) {
                db = this.getWritableDatabase();
                ContentValues values = new ContentValues();

                values.put(KEY_USER_ID, userId);
                values.put(KEY_TURF_ID, turfId);
                values.put(KEY_BOOKING_DATE, bookingDate);
                values.put(KEY_TIME_SLOT, timeSlot);
                values.put(KEY_HOURS, hours);
                values.put(KEY_PLAYER_COUNT, playerCount);
                values.put(KEY_TOTAL_PRICE, totalPrice);
                values.put(KEY_BOOKING_STATUS, "confirmed");

                bookingId = db.insert(TABLE_BOOKINGS, null, values);
                Log.d(TAG, "Booking added with ID: " + bookingId);
            } else {
                Log.e(TAG, "Time slot not available: " + timeSlot + " on " + bookingDate);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error adding booking: " + e.getMessage(), e);
        } finally {
            if (db != null && db.isOpen()) {
                db.close();
            }
        }

        return bookingId;
    }

    /**
     * Check if a time slot is available for booking
     * @param turfId The ID of the turf
     * @param bookingDate The date to check
     * @param timeSlot The time slot to check
     * @return true if the time slot is available, false otherwise
     */
    public boolean isTimeSlotAvailable(long turfId, String bookingDate, String timeSlot) {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        boolean isAvailable = true;

        try {
            db = this.getReadableDatabase();

            String selection = KEY_TURF_ID + " = ? AND " +
                    KEY_BOOKING_DATE + " = ? AND " +
                    KEY_TIME_SLOT + " = ? AND " +
                    KEY_BOOKING_STATUS + " = ?";
            String[] selectionArgs = {
                    String.valueOf(turfId),
                    bookingDate,
                    timeSlot,
                    "confirmed"
            };

            cursor = db.query(TABLE_BOOKINGS, new String[]{KEY_ID},
                    selection, selectionArgs, null, null, null);

            // If any bookings found, the time slot is not available
            isAvailable = (cursor == null || cursor.getCount() == 0);
        } catch (Exception e) {
            Log.e(TAG, "Error checking time slot availability: " + e.getMessage(), e);
            isAvailable = false; // Assume not available if there's an error
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null && db.isOpen()) {
                db.close();
            }
        }

        return isAvailable;
    }

    /**
     * Get all booked time slots for a turf on a specific date
     * @param turfId The ID of the turf
     * @param bookingDate The date to check
     * @return List of booked time slots
     */
    public List<String> getBookedTimeSlots(long turfId, String bookingDate) {
        List<String> bookedSlots = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;

        try {
            db = this.getReadableDatabase();

            String selection = KEY_TURF_ID + " = ? AND " +
                    KEY_BOOKING_DATE + " = ? AND " +
                    KEY_BOOKING_STATUS + " = ?";
            String[] selectionArgs = {
                    String.valueOf(turfId),
                    bookingDate,
                    "confirmed"
            };

            cursor = db.query(TABLE_BOOKINGS, new String[]{KEY_TIME_SLOT},
                    selection, selectionArgs, null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    bookedSlots.add(cursor.getString(cursor.getColumnIndex(KEY_TIME_SLOT)));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting booked time slots: " + e.getMessage(), e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null && db.isOpen()) {
                db.close();
            }
        }

        return bookedSlots;
    }

    /**
     * Get all bookings for a user
     * @param userId The ID of the user
     * @return List of bookings
     */
    public List<Booking> getUserBookings(long userId) {
        List<Booking> bookings = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;

        try {
            db = this.getReadableDatabase();

            String query = "SELECT b.*, t.turf_name, t.location FROM " + TABLE_BOOKINGS + " b " +
                    "JOIN " + TABLE_TURFS + " t ON b." + KEY_TURF_ID + " = t." + KEY_ID + " " +
                    "WHERE b." + KEY_USER_ID + " = ? " +
                    "ORDER BY b." + KEY_BOOKING_DATE + " DESC, b." + KEY_TIME_SLOT + " ASC";

            cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    Booking booking = new Booking();
                    booking.setId(cursor.getInt(cursor.getColumnIndex(KEY_ID)));
                    booking.setUserId(cursor.getInt(cursor.getColumnIndex(KEY_USER_ID)));
                    booking.setTurfId(cursor.getInt(cursor.getColumnIndex(KEY_TURF_ID)));
                    booking.setBookingDate(cursor.getString(cursor.getColumnIndex(KEY_BOOKING_DATE)));
                    booking.setTimeSlot(cursor.getString(cursor.getColumnIndex(KEY_TIME_SLOT)));
                    booking.setHours(cursor.getInt(cursor.getColumnIndex(KEY_HOURS)));
                    booking.setPlayerCount(cursor.getInt(cursor.getColumnIndex(KEY_PLAYER_COUNT)));
                    booking.setTotalPrice(cursor.getDouble(cursor.getColumnIndex(KEY_TOTAL_PRICE)));
                    booking.setStatus(cursor.getString(cursor.getColumnIndex(KEY_BOOKING_STATUS)));
                    booking.setTurfName(cursor.getString(cursor.getColumnIndex("turf_name")));
                    booking.setTurfLocation(cursor.getString(cursor.getColumnIndex("location")));

                    bookings.add(booking);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting user bookings: " + e.getMessage(), e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null && db.isOpen()) {
                db.close();
            }
        }

        return bookings;
    }

    /**
     * Get the absolute path of the database file
     * @return String representing the full path to the database file
     */
    public String getDatabasePath() {
        return context.getDatabasePath(DATABASE_NAME).getAbsolutePath();
    }

    /**
     * Get user type (owner or user) by email
     * @param email The email to check
     * @return String representing the user type or null if not found
     */
    public String getUserType(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{KEY_USER_TYPE},
                KEY_EMAIL + "=?",
                new String[]{email},
                null, null, null);

        String userType = null;
        if (cursor.moveToFirst()) {
            int userTypeIndex = cursor.getColumnIndex(KEY_USER_TYPE);
            if (userTypeIndex != -1) {
                userType = cursor.getString(userTypeIndex);
            }
        }
        cursor.close();
        return userType;
    }

    /**
     * Get user ID by email
     * @param email The email to check
     * @return long representing the user ID or -1 if not found
     */
    public long getUserId(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{KEY_ID},
                KEY_EMAIL + "=?",
                new String[]{email},
                null, null, null);

        long userId = -1;
        if (cursor.moveToFirst()) {
            int idIndex = cursor.getColumnIndex(KEY_ID);
            if (idIndex != -1) {
                userId = cursor.getLong(idIndex);
            }
        }
        cursor.close();
        return userId;
    }

    /**
     * Check if a user with the given email already exists
     * @param email The email to check
     * @return true if the email exists, false otherwise
     */
    public boolean checkEmailExists(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{KEY_ID},
                KEY_EMAIL + "=?",
                new String[]{email},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    /**
     * Check if user credentials are valid
     * @param email The email to check
     * @param password The password to check
     * @return true if credentials are valid, false otherwise
     */
    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{KEY_ID},
                KEY_EMAIL + "=? AND " + KEY_PASSWORD + "=?",
                new String[]{email, password},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    /**
     * Add a new user to the database
     * @param name The user's name
     * @param email The user's email
     * @param password The user's password
     * @param userType The user's type (owner or user)
     * @return The ID of the newly inserted user, or -1 if the operation failed
     */
    public long addUser(String name, String email, String password, String userType) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_NAME, name);
        values.put(KEY_EMAIL, email);
        values.put(KEY_PASSWORD, password);
        values.put(KEY_USER_TYPE, userType);
        return db.insert(TABLE_USERS, null, values);
    }

    /**
     * Get all turfs owned by a specific owner
     * @param ownerId The ID of the owner
     * @return List of turfs owned by the specified owner
     */
    public List<Turf> getTurfsByOwnerId(long ownerId) {
        List<Turf> turfList = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;

        try {
            db = this.getReadableDatabase();

            Log.d(TAG, "Querying turfs for owner ID: " + ownerId);

            String[] columns = {
                    KEY_ID,
                    KEY_TURF_NAME,
                    KEY_DESCRIPTION,
                    KEY_LOCATION,
                    KEY_PRICE,
                    KEY_CONTACT_INFO,
                    KEY_OPENING_TIME,
                    KEY_CLOSING_TIME,
                    KEY_IMAGE_URL
            };

            String selection = KEY_OWNER_ID + " = ?";
            String[] selectionArgs = { String.valueOf(ownerId) };
            String orderBy = KEY_CREATED_AT + " DESC";

            cursor = db.query(TABLE_TURFS, columns, selection, selectionArgs, null, null, orderBy);

            Log.d(TAG, "Query returned " + (cursor != null ? cursor.getCount() : 0) + " turfs");

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    int idIndex = cursor.getColumnIndex(KEY_ID);
                    int nameIndex = cursor.getColumnIndex(KEY_TURF_NAME);
                    int descIndex = cursor.getColumnIndex(KEY_DESCRIPTION);
                    int locIndex = cursor.getColumnIndex(KEY_LOCATION);
                    int priceIndex = cursor.getColumnIndex(KEY_PRICE);
                    int contactIndex = cursor.getColumnIndex(KEY_CONTACT_INFO);
                    int openTimeIndex = cursor.getColumnIndex(KEY_OPENING_TIME);
                    int closeTimeIndex = cursor.getColumnIndex(KEY_CLOSING_TIME);
                    int imageUrlIndex = cursor.getColumnIndex(KEY_IMAGE_URL);

                    // Check if required columns exist
                    if (idIndex == -1 || nameIndex == -1 || descIndex == -1 || 
                            locIndex == -1 || priceIndex == -1) {
                        Log.e(TAG, "Missing required columns in turf query result");
                        continue;
                    }

                    // Using getLong for ID to ensure consistency
                    Turf turf = new Turf(
                            cursor.getLong(idIndex),
                            cursor.getString(nameIndex),
                            cursor.getString(descIndex),
                            cursor.getString(locIndex),
                            cursor.getDouble(priceIndex)
                    );

                    // Set owner ID
                    turf.setOwnerId((int)ownerId);

                    // Set contact info if available
                    if (contactIndex != -1) {
                        turf.setContactInfo(cursor.getString(contactIndex));
                    }

                    // Set opening/closing times if available
                    if (openTimeIndex != -1) {
                        turf.setOpeningTime(cursor.getString(openTimeIndex));
                    }

                    if (closeTimeIndex != -1) {
                        turf.setClosingTime(cursor.getString(closeTimeIndex));
                    }
                    
                    // Set image URL if available
                    if (imageUrlIndex != -1 && !cursor.isNull(imageUrlIndex)) {
                        turf.setImageUrl(cursor.getString(imageUrlIndex));
                    }

                    turfList.add(turf);
                    Log.d(TAG, "Added turf: " + turf.getName() + " (ID: " + turf.getId() + ")");
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting turfs by owner ID: " + e.getMessage(), e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null && db.isOpen()) {
                db.close();
            }
        }

        return turfList;
    }

    /**
     * Delete a turf by its ID
     * @param turfId The ID of the turf to delete
     * @return The number of rows affected, should be 1 if successful
     */
    public int deleteTurf(long turfId) {
        SQLiteDatabase db = null;
        int deletedRows = 0;
        
        try {
            db = this.getWritableDatabase();
            Log.d(TAG, "Deleting turf with ID: " + turfId);
            
            // First delete all bookings associated with this turf
            db.delete(TABLE_BOOKINGS, KEY_TURF_ID + "=?", new String[]{String.valueOf(turfId)});
            
            // Then delete the turf
            deletedRows = db.delete(TABLE_TURFS, KEY_ID + "=?", new String[]{String.valueOf(turfId)});
            
            Log.d(TAG, "Deleted " + deletedRows + " turf records");
        } catch (Exception e) {
            Log.e(TAG, "Error deleting turf: " + e.getMessage(), e);
        } finally {
            if (db != null && db.isOpen()) {
                db.close();
            }
        }
        
        return deletedRows;
    }

    /**
     * Get all turfs from the database
     * @return A list of all turfs
     */
    public List<Turf> getAllTurfs() {
        List<Turf> turfList = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;

        try {
            db = this.getReadableDatabase();

            String query = "SELECT * FROM " + TABLE_TURFS + " ORDER BY " + KEY_CREATED_AT + " DESC";
            cursor = db.rawQuery(query, null);

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    Turf turf = new Turf();
                    turf.setId(cursor.getLong(cursor.getColumnIndex(KEY_ID)));
                    turf.setName(cursor.getString(cursor.getColumnIndex(KEY_TURF_NAME)));
                    turf.setDescription(cursor.getString(cursor.getColumnIndex(KEY_DESCRIPTION)));
                    turf.setLocation(cursor.getString(cursor.getColumnIndex(KEY_LOCATION)));
                    turf.setPrice(cursor.getDouble(cursor.getColumnIndex(KEY_PRICE)));
                    turf.setOwnerId(cursor.getInt(cursor.getColumnIndex(KEY_OWNER_ID)));
                    turf.setContactInfo(cursor.getString(cursor.getColumnIndex(KEY_CONTACT_INFO)));

                    // Get opening and closing times if available
                    int openingTimeIndex = cursor.getColumnIndex(KEY_OPENING_TIME);
                    int closingTimeIndex = cursor.getColumnIndex(KEY_CLOSING_TIME);
                    if (openingTimeIndex != -1) {
                        turf.setOpeningTime(cursor.getString(openingTimeIndex));
                    }
                    if (closingTimeIndex != -1) {
                        turf.setClosingTime(cursor.getString(closingTimeIndex));
                    }

                    // Get image URL if available
                    int imageUrlIndex = cursor.getColumnIndex(KEY_IMAGE_URL);
                    if (imageUrlIndex != -1) {
                        turf.setImageUrl(cursor.getString(imageUrlIndex));
                    }

                    turfList.add(turf);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting all turfs: " + e.getMessage(), e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null && db.isOpen()) {
                db.close();
            }
        }

        return turfList;
    }

    /**
     * Force database recreation - USE WITH CAUTION
     * This method will delete and recreate all tables, resulting in data loss
     */
    public void recreateDatabase() {
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            
            Log.d(TAG, "Forcibly recreating all database tables");
            
            // Drop all tables
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKINGS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_TURFS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
            
            // Recreate them
            db.execSQL(CREATE_TABLE_USERS);
            db.execSQL(CREATE_TABLE_TURFS);
            db.execSQL(CREATE_TABLE_BOOKINGS);
            
            Log.d(TAG, "Database tables recreated successfully");
        } catch (Exception e) {
            Log.e(TAG, "Error recreating database tables: " + e.getMessage(), e);
        } finally {
            if (db != null && db.isOpen()) {
                db.close();
            }
        }
    }

    /**
     * Get a user's name by their ID
     * @param userId The ID of the user
     * @return The user's name, or null if not found
     */
    public String getUserNameById(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String name = null;
        Cursor cursor = null;
        
        try {
            cursor = db.query(
                    TABLE_USERS,
                    new String[]{KEY_NAME},
                    KEY_ID + " = ?",
                    new String[]{String.valueOf(userId)},
                    null, null, null
            );
            
            if (cursor != null && cursor.moveToFirst()) {
                int nameColumnIndex = cursor.getColumnIndex(KEY_NAME);
                if (nameColumnIndex != -1) {
                    name = cursor.getString(nameColumnIndex);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting user name by ID: " + e.getMessage(), e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        
        return name;
    }

    /**
     * Get a user's phone number by their ID
     * @param userId The ID of the user
     * @return The user's phone number, or null if not found
     */
    public String getUserPhoneById(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String phone = null;
        Cursor cursor = null;
        
        try {
            // First check if the phone column exists in the users table
            boolean hasPhoneColumn = false;
            Cursor columnCursor = db.rawQuery("PRAGMA table_info(" + TABLE_USERS + ")", null);
            if (columnCursor != null) {
                int nameIndex = columnCursor.getColumnIndex("name");
                if (nameIndex >= 0) {
                    while (columnCursor.moveToNext()) {
                        String columnName = columnCursor.getString(nameIndex);
                        if (KEY_PHONE.equals(columnName)) {
                            hasPhoneColumn = true;
                            break;
                        }
                    }
                }
                columnCursor.close();
            }
            
            // If the column doesn't exist, add it to the table
            if (!hasPhoneColumn) {
                Log.d(TAG, "Phone column not found, adding it to users table");
                try {
                    db.execSQL("ALTER TABLE " + TABLE_USERS + " ADD COLUMN " + KEY_PHONE + " TEXT");
                    hasPhoneColumn = true;
                } catch (Exception e) {
                    Log.e(TAG, "Error adding phone column: " + e.getMessage(), e);
                }
            }
            
            // Now query the table for the phone number
            if (hasPhoneColumn) {
                cursor = db.query(
                        TABLE_USERS,
                        new String[]{KEY_PHONE},
                        KEY_ID + " = ?",
                        new String[]{String.valueOf(userId)},
                        null, null, null
                );
                
                if (cursor != null && cursor.moveToFirst()) {
                    int phoneColumnIndex = cursor.getColumnIndex(KEY_PHONE);
                    if (phoneColumnIndex != -1) {
                        phone = cursor.getString(phoneColumnIndex);
                    }
                }
            } else {
                // Fallback if we couldn't add the column
                return "No phone available";
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting user phone by ID: " + e.getMessage(), e);
            return "Error: " + e.getMessage(); // Return a fallback message instead of null
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        
        return phone != null ? phone : "No phone available"; // Return a default value if phone is null
    }

    /**
     * Get all bookings for a specific owner (bookings made for their turfs)
     * @param ownerId The ID of the owner
     * @return List of bookings for turfs owned by this owner
     */
    public List<Booking> getBookingsByOwnerId(long ownerId) {
        List<Booking> bookingList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        
        try {
            // Query to get bookings for owner's turfs
            String query = "SELECT b.* FROM " + TABLE_BOOKINGS + " b " +
                    "JOIN " + TABLE_TURFS + " t ON b." + KEY_TURF_ID + " = t." + KEY_ID + " " +
                    "WHERE t." + KEY_OWNER_ID + " = ? " +
                    "ORDER BY b." + KEY_BOOKING_DATE + " DESC, b." + KEY_TIME_SLOT + " ASC";
            
            cursor = db.rawQuery(query, new String[]{String.valueOf(ownerId)});
            
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    Booking booking = new Booking();
                    booking.setId(cursor.getLong(cursor.getColumnIndex(KEY_ID)));
                    booking.setUserId(cursor.getLong(cursor.getColumnIndex(KEY_USER_ID)));
                    booking.setTurfId(cursor.getLong(cursor.getColumnIndex(KEY_TURF_ID)));
                    booking.setBookingDate(cursor.getString(cursor.getColumnIndex(KEY_BOOKING_DATE)));
                    booking.setTimeSlot(cursor.getString(cursor.getColumnIndex(KEY_TIME_SLOT)));
                    booking.setHours(cursor.getInt(cursor.getColumnIndex(KEY_HOURS)));
                    booking.setPlayerCount(cursor.getInt(cursor.getColumnIndex(KEY_PLAYER_COUNT)));
                    booking.setTotalPrice(cursor.getDouble(cursor.getColumnIndex(KEY_TOTAL_PRICE)));
                    booking.setStatus(cursor.getString(cursor.getColumnIndex(KEY_BOOKING_STATUS)));
                    
                    // Get the turf name and user name for convenience
                    Turf turf = getTurfById(booking.getTurfId());
                    if (turf != null) {
                        booking.setTurfName(turf.getName());
                    }
                    
                    String userName = getUserNameById(booking.getUserId());
                    if (userName != null) {
                        booking.setUserName(userName);
                    }
                    
                    bookingList.add(booking);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting bookings by owner ID: " + e.getMessage(), e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        
        return bookingList;
    }

    /**
     * Get all bookings for a specific user
     * @param userId The ID of the user
     * @return List of bookings made by this user
     */
    public List<Booking> getBookingsByUserId(long userId) {
        List<Booking> bookingList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        
        try {
            // Query to get bookings for a specific user
            String query = "SELECT * FROM " + TABLE_BOOKINGS + " WHERE " + KEY_USER_ID + " = ? " +
                    "ORDER BY " + KEY_BOOKING_DATE + " DESC, " + KEY_TIME_SLOT + " ASC";
            
            cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});
            
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    Booking booking = new Booking();
                    booking.setId(cursor.getLong(cursor.getColumnIndex(KEY_ID)));
                    booking.setUserId(cursor.getLong(cursor.getColumnIndex(KEY_USER_ID)));
                    booking.setTurfId(cursor.getLong(cursor.getColumnIndex(KEY_TURF_ID)));
                    booking.setBookingDate(cursor.getString(cursor.getColumnIndex(KEY_BOOKING_DATE)));
                    booking.setTimeSlot(cursor.getString(cursor.getColumnIndex(KEY_TIME_SLOT)));
                    booking.setHours(cursor.getInt(cursor.getColumnIndex(KEY_HOURS)));
                    booking.setPlayerCount(cursor.getInt(cursor.getColumnIndex(KEY_PLAYER_COUNT)));
                    booking.setTotalPrice(cursor.getDouble(cursor.getColumnIndex(KEY_TOTAL_PRICE)));
                    booking.setStatus(cursor.getString(cursor.getColumnIndex(KEY_BOOKING_STATUS)));
                    
                    // Get the turf name for convenience
                    Turf turf = getTurfById(booking.getTurfId());
                    if (turf != null) {
                        booking.setTurfName(turf.getName());
                    }
                    
                    bookingList.add(booking);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting bookings by user ID: " + e.getMessage(), e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        
        return bookingList;
    }

    /**
     * Get a booking by its ID
     * @param bookingId The ID of the booking to retrieve
     * @return The booking object, or null if not found
     */
    public Booking getBookingById(long bookingId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Booking booking = null;

        String[] columns = {
            KEY_BOOKING_ID, KEY_USER_ID, KEY_TURF_ID, KEY_BOOKING_DATE,
            KEY_TIME_SLOT, KEY_HOURS, KEY_TOTAL_PRICE, KEY_BOOKING_STATUS,
            KEY_PAYMENT_METHOD, KEY_UPI_ID
        };

        String selection = KEY_BOOKING_ID + " = ?";
        String[] selectionArgs = {String.valueOf(bookingId)};

        Cursor cursor = db.query(TABLE_BOOKINGS, columns, selection, selectionArgs, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            booking = new Booking(
                cursor.getLong(cursor.getColumnIndex(KEY_BOOKING_ID)),
                cursor.getLong(cursor.getColumnIndex(KEY_USER_ID)),
                cursor.getLong(cursor.getColumnIndex(KEY_TURF_ID)),
                cursor.getString(cursor.getColumnIndex(KEY_BOOKING_DATE)),
                cursor.getString(cursor.getColumnIndex(KEY_TIME_SLOT)),
                cursor.getInt(cursor.getColumnIndex(KEY_HOURS)),
                cursor.getDouble(cursor.getColumnIndex(KEY_TOTAL_PRICE)),
                cursor.getString(cursor.getColumnIndex(KEY_BOOKING_STATUS)),
                cursor.getString(cursor.getColumnIndex(KEY_PAYMENT_METHOD)),
                cursor.getString(cursor.getColumnIndex(KEY_UPI_ID))
            );

            // Get turf details
            Turf turf = getTurfById(booking.getTurfId());
            if (turf != null) {
                booking.setTurf(turf);
                booking.setTurfName(turf.getName());
                booking.setTurfLocation(turf.getLocation());
            }

            // Get user details
            User user = getUserById(booking.getUserId());
            if (user != null) {
                booking.setUserName(user.getName());
                booking.setUserPhone(user.getPhone());
            }

            cursor.close();
        }

        return booking;
    }

    public long saveBooking(Booking booking) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_USER_ID, booking.getUserId());
        values.put(KEY_TURF_ID, booking.getTurfId());
        values.put(KEY_BOOKING_DATE, booking.getBookingDate());
        values.put(KEY_TIME_SLOT, booking.getTimeSlot());
        values.put(KEY_HOURS, booking.getHours());
        values.put(KEY_TOTAL_PRICE, booking.getTotalPrice());
        values.put(KEY_BOOKING_STATUS, booking.getBookingStatus());
        values.put(KEY_PAYMENT_METHOD, booking.getPaymentMethod());
        values.put(KEY_UPI_ID, booking.getUpiId());
        return db.insert(TABLE_BOOKINGS, null, values);
    }

    /**
     * Get a user by their ID
     * @param userId The ID of the user to retrieve
     * @return The User object, or null if not found
     */
    public User getUserById(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        User user = null;
        Cursor cursor = null;
        
        try {
            String[] columns = {
                KEY_ID, KEY_NAME, KEY_EMAIL, KEY_PASSWORD, 
                KEY_USER_TYPE, KEY_PHONE
            };
            
            String selection = KEY_ID + " = ?";
            String[] selectionArgs = {String.valueOf(userId)};
            
            cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
            
            if (cursor != null && cursor.moveToFirst()) {
                user = new User();
                user.setId(cursor.getLong(cursor.getColumnIndex(KEY_ID)));
                user.setName(cursor.getString(cursor.getColumnIndex(KEY_NAME)));
                user.setEmail(cursor.getString(cursor.getColumnIndex(KEY_EMAIL)));
                user.setPassword(cursor.getString(cursor.getColumnIndex(KEY_PASSWORD)));
                user.setUserType(cursor.getString(cursor.getColumnIndex(KEY_USER_TYPE)));
                
                // Get phone if available
                int phoneIndex = cursor.getColumnIndex(KEY_PHONE);
                if (phoneIndex != -1 && !cursor.isNull(phoneIndex)) {
                    user.setPhone(cursor.getString(phoneIndex));
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting user by ID: " + e.getMessage(), e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        
        return user;
    }
}