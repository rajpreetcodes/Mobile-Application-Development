package com.example.ts_project_is_mad;

import java.io.Serializable;

/**
 * Class representing a booking in the system
 */
public class Booking implements Serializable {
    private long id;
    private long userId;
    private long turfId;
    private String bookingDate;
    private String timeSlot;
    private int hours;
    private int playerCount;
    private double totalPrice;
    private String status;
    private String createdAt;
    
    // Additional fields for convenience (not stored directly in booking table)
    private String userName;
    private String userPhone;
    private String turfName;
    private String turfLocation;
    
    private String bookingStatus;
    private String paymentMethod;
    private String upiId;
    private Turf turf;
    
    // Default constructor
    public Booking() {
    }
    
    // Constructor with primary fields
    public Booking(long userId, long turfId, String bookingDate, String timeSlot, 
                   int hours, int playerCount, double totalPrice) {
        this.userId = userId;
        this.turfId = turfId;
        this.bookingDate = bookingDate;
        this.timeSlot = timeSlot;
        this.hours = hours;
        this.playerCount = playerCount;
        this.totalPrice = totalPrice;
        this.status = "confirmed"; // Default status
    }
    
    // Constructor
    public Booking(long id, long userId, long turfId, String bookingDate, String timeSlot, 
                  int hours, double totalPrice, String bookingStatus, String paymentMethod, String upiId) {
        this.id = id;
        this.userId = userId;
        this.turfId = turfId;
        this.bookingDate = bookingDate;
        this.timeSlot = timeSlot;
        this.hours = hours;
        this.totalPrice = totalPrice;
        this.bookingStatus = bookingStatus;
        this.paymentMethod = paymentMethod;
        this.upiId = upiId;
    }
    
    // Getters and setters
    public long getId() {
        return id;
    }
    
    public void setId(long id) {
        this.id = id;
    }
    
    public long getUserId() {
        return userId;
    }
    
    public void setUserId(long userId) {
        this.userId = userId;
    }
    
    public long getTurfId() {
        return turfId;
    }
    
    public void setTurfId(long turfId) {
        this.turfId = turfId;
    }
    
    public String getBookingDate() {
        return bookingDate;
    }
    
    public void setBookingDate(String bookingDate) {
        this.bookingDate = bookingDate;
    }
    
    public String getTimeSlot() {
        return timeSlot;
    }
    
    public void setTimeSlot(String timeSlot) {
        this.timeSlot = timeSlot;
    }
    
    public int getHours() {
        return hours;
    }
    
    public void setHours(int hours) {
        this.hours = hours;
    }
    
    public int getPlayerCount() {
        return playerCount;
    }
    
    public void setPlayerCount(int playerCount) {
        this.playerCount = playerCount;
    }
    
    public double getTotalPrice() {
        return totalPrice;
    }
    
    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
    
    public String getUserName() {
        return userName;
    }
    
    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    public String getUserPhone() {
        return userPhone;
    }
    
    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }
    
    public String getTurfName() {
        return turfName;
    }
    
    public void setTurfName(String turfName) {
        this.turfName = turfName;
    }
    
    public String getTurfLocation() {
        return turfLocation;
    }
    
    public void setTurfLocation(String turfLocation) {
        this.turfLocation = turfLocation;
    }
    
    public String getPaymentMethod() {
        return paymentMethod;
    }
    
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
    
    public String getUpiId() {
        return upiId;
    }
    
    public void setUpiId(String upiId) {
        this.upiId = upiId;
    }
    
    public Turf getTurf() {
        return turf;
    }
    
    public void setTurf(Turf turf) {
        this.turf = turf;
    }
    
    public String getBookingStatus() {
        return status;
    }
    
    // Format the booking time range (e.g., "14:00 - 16:00")
    public String getTimeRange() {
        if (timeSlot == null || hours <= 0) {
            return "N/A";
        }
        
        try {
            // Parse the starting time
            String[] timeParts = timeSlot.split(":");
            int startHour = Integer.parseInt(timeParts[0]);
            int endHour = startHour + hours;
            
            // Format the time range
            return String.format("%02d:%s - %02d:00", 
                     startHour, timeParts[1], endHour);
        } catch (Exception e) {
            return timeSlot;
        }
    }
    
    // Generate a comprehensive booking summary
    public String getBookingSummary() {
        StringBuilder summary = new StringBuilder();
        
        if (turfName != null) {
            summary.append("Turf: ").append(turfName).append("\n");
        }
        
        if (bookingDate != null) {
            summary.append("Date: ").append(bookingDate).append("\n");
        }
        
        summary.append("Time: ").append(getTimeRange()).append("\n");
        summary.append("Duration: ").append(hours).append(" hour(s)\n");
        summary.append("Players: ").append(playerCount).append("\n");
        summary.append("Total Price: ₹").append(String.format("%.2f", totalPrice));
        
        return summary.toString();
    }
}