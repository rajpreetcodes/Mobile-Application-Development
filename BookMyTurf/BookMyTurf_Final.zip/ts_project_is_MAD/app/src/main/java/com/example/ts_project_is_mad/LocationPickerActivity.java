package com.example.ts_project_is_mad;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

public class LocationPickerActivity extends AppCompatActivity implements OnMapReadyCallback {
    private static final String TAG = "LocationPickerActivity";
    
    private GoogleMap mMap;
    private LatLng selectedLocation;
    private Button confirmButton;
    private AutoCompleteTextView locationSearchView;
    private ImageView clearSearchButton;
    private Marker currentMarker;
    private ExecutorService executorService;
    private volatile boolean isExecutorActive = true;
    private List<Address> autocompleteResults = new ArrayList<>();
    private ArrayAdapter<String> autocompleteAdapter;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_picker);
        
        // Initialize background thread executor for geocoding
        executorService = Executors.newSingleThreadExecutor();
        isExecutorActive = true;
        
        // Set up toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setTitle("Select Turf Location");
            }
        }
        
        // Get map fragment
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.mapPicker);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
        
        // Set up search functionality
        setupSearchFunctionality();
        
        // Set up confirm button
        confirmButton = findViewById(R.id.confirmLocationButton);
        confirmButton.setEnabled(false); // Disable until location is selected
        confirmButton.setOnClickListener(v -> confirmSelectedLocation());
    }
    
    private void setupSearchFunctionality() {
        locationSearchView = findViewById(R.id.locationSearchView);
        clearSearchButton = findViewById(R.id.clearSearchButton);
        
        // Initialize adapter for autocomplete
        autocompleteAdapter = new ArrayAdapter<>(this, 
                android.R.layout.simple_dropdown_item_1line, new ArrayList<>());
        locationSearchView.setAdapter(autocompleteAdapter);
        
        // Handle text changes for autocomplete
        locationSearchView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 2) {
                    performGeocoding(s.toString());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                clearSearchButton.setVisibility(s.length() > 0 ? View.VISIBLE : View.GONE);
            }
        });
        
        // Handle item selection from dropdown
        locationSearchView.setOnItemClickListener((parent, view, position, id) -> {
            if (position < autocompleteResults.size()) {
                Address selected = autocompleteResults.get(position);
                LatLng location = new LatLng(selected.getLatitude(), selected.getLongitude());
                updateSelectedLocation(location);
                locationSearchView.clearFocus();
            }
        });
        
        // Handle search action
        locationSearchView.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                String query = locationSearchView.getText().toString();
                if (!query.isEmpty()) {
                    performGeocoding(query);
                }
                return true;
            }
            return false;
        });
        
        // Clear button functionality
        clearSearchButton.setOnClickListener(v -> {
            locationSearchView.setText("");
            locationSearchView.clearFocus();
        });
        
        // Initially hide clear button
        clearSearchButton.setVisibility(View.GONE);
    }
    
    private void performGeocoding(String query) {
        if (!isExecutorActive || executorService == null || executorService.isShutdown()) {
            Log.e(TAG, "ExecutorService is not available, recreating...");
            recreateExecutorService();
            if (executorService == null || executorService.isShutdown()) {
                // If we still can't get a valid executor, don't proceed
                return;
            }
        }
        
        try {
            executorService.execute(() -> {
                try {
                    Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                    autocompleteResults = geocoder.getFromLocationName(query, 5);
                    
                    if (autocompleteResults != null && !autocompleteResults.isEmpty()) {
                        List<String> addressStrings = new ArrayList<>();
                        for (Address address : autocompleteResults) {
                            StringBuilder sb = new StringBuilder();
                            
                            // Build a readable address string
                            if (address.getFeatureName() != null) {
                                sb.append(address.getFeatureName());
                            }
                            
                            if (address.getLocality() != null) {
                                if (sb.length() > 0) sb.append(", ");
                                sb.append(address.getLocality());
                            }
                            
                            if (address.getAdminArea() != null) {
                                if (sb.length() > 0) sb.append(", ");
                                sb.append(address.getAdminArea());
                            }
                            
                            if (address.getCountryName() != null) {
                                if (sb.length() > 0) sb.append(", ");
                                sb.append(address.getCountryName());
                            }
                            
                            addressStrings.add(sb.toString());
                        }
                        
                        // Update adapter on UI thread
                        runOnUiThread(() -> {
                            autocompleteAdapter.clear();
                            autocompleteAdapter.addAll(addressStrings);
                            autocompleteAdapter.notifyDataSetChanged();
                            
                            // Move to the first result if it exists
                            if (!autocompleteResults.isEmpty() && query.length() > 4) {
                                Address firstResult = autocompleteResults.get(0);
                                LatLng location = new LatLng(firstResult.getLatitude(), firstResult.getLongitude());
                                updateSelectedLocation(location);
                            }
                        });
                    }
                } catch (IOException e) {
                    Log.e(TAG, "Error performing geocoding: " + e.getMessage(), e);
                    if (!isFinishing()) {
                        runOnUiThread(() -> 
                            Toast.makeText(LocationPickerActivity.this, 
                                "Error searching for location", Toast.LENGTH_SHORT).show()
                        );
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Unexpected error in geocoding: " + e.getMessage(), e);
                }
            });
        } catch (RejectedExecutionException e) {
            Log.e(TAG, "Task rejected - Executor service might be terminated: " + e.getMessage());
            // Try to recreate the executor
            recreateExecutorService();
            Toast.makeText(this, "Please try searching again", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e(TAG, "Error submitting geocoding task: " + e.getMessage(), e);
            Toast.makeText(this, "Error processing your request. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }
    
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        
        try {
            // Apply modern styling
            boolean success = mMap.setMapStyle(
                MapStyleOptions.loadRawResourceStyle(this, R.raw.maps_style_2024));
            
            if (!success) {
                Log.e(TAG, "Style parsing failed.");
            }
        } catch (Exception e) {
            Log.e(TAG, "Can't find style. Error: ", e);
        }
        
        // Default position in India (Mumbai)
        LatLng defaultPosition = new LatLng(19.0760, 72.8777);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultPosition, 12));
        
        // Enable map features
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setZoomGesturesEnabled(true);
        mMap.getUiSettings().setCompassEnabled(true);
        mMap.getUiSettings().setMyLocationButtonEnabled(true);
        mMap.getUiSettings().setMapToolbarEnabled(true);
        
        // Set click listener for the map
        mMap.setOnMapClickListener(this::updateSelectedLocation);
    }
    
    private void updateSelectedLocation(LatLng latLng) {
        // Remove previous marker
        if (currentMarker != null) {
            currentMarker.remove();
        }
        
        // Add new marker
        currentMarker = mMap.addMarker(new MarkerOptions()
                .position(latLng)
                .title("Selected Location")
                .draggable(true));
        
        // Store the selected location
        selectedLocation = latLng;
        
        // Move camera to selected location
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
        
        // Enable confirm button
        confirmButton.setEnabled(true);
        
        // Perform reverse geocoding to get address
        if (isExecutorActive && executorService != null && !executorService.isShutdown()) {
            try {
                executorService.execute(() -> {
                    String address = getAddressFromLocation(latLng);
                    
                    // Update search field with address
                    if (!address.isEmpty() && !isFinishing()) {
                        runOnUiThread(() -> locationSearchView.setText(address));
                    }
                });
            } catch (RejectedExecutionException e) {
                Log.e(TAG, "Task rejected - Executor service might be terminated: " + e.getMessage());
                // Try to recreate the executor service
                recreateExecutorService();
            } catch (Exception e) {
                Log.e(TAG, "Error executing reverse geocoding task: " + e.getMessage(), e);
                // Continue without address lookup
            }
        } else {
            Log.e(TAG, "ExecutorService not available for reverse geocoding");
            // Try to recreate the executor if it's been shut down
            recreateExecutorService();
        }
    }
    
    /**
     * Recreate the executor service if it was shut down
     */
    private void recreateExecutorService() {
        try {
            if (executorService == null || executorService.isShutdown() || executorService.isTerminated()) {
                Log.d(TAG, "Recreating executor service");
                executorService = Executors.newSingleThreadExecutor();
                isExecutorActive = true;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error recreating executor service: " + e.getMessage(), e);
        }
    }
    
    private void confirmSelectedLocation() {
        if (selectedLocation == null) {
            Toast.makeText(this, "Please select a location on the map", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Get address from location coordinates (reverse geocoding)
        String address = getAddressFromLocation(selectedLocation);
        
        // Return the selected location to the calling activity
        Intent resultIntent = new Intent();
        resultIntent.putExtra("latitude", selectedLocation.latitude);
        resultIntent.putExtra("longitude", selectedLocation.longitude);
        resultIntent.putExtra("address", address);
        setResult(RESULT_OK, resultIntent);
        finish();
    }
    
    private String getAddressFromLocation(LatLng location) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        String addressText = "";
        
        try {
            List<Address> addresses = geocoder.getFromLocation(
                    location.latitude, location.longitude, 1);
            
            if (addresses != null && addresses.size() > 0) {
                Address address = addresses.get(0);
                StringBuilder sb = new StringBuilder();
                
                for (int i = 0; i <= address.getMaxAddressLineIndex(); i++) {
                    sb.append(address.getAddressLine(i));
                    if (i < address.getMaxAddressLineIndex()) {
                        sb.append(", ");
                    }
                }
                
                addressText = sb.toString();
            }
        } catch (IOException e) {
            Log.e(TAG, "Error getting address from location: " + e.getMessage(), e);
        }
        
        return addressText;
    }
    
    @Override
    protected void onDestroy() {
        // Properly shutdown executor service
        isExecutorActive = false;
        if (executorService != null && !executorService.isShutdown()) {
            try {
                // Initiate an orderly shutdown
                executorService.shutdown();
                // Wait for tasks to complete
                if (!executorService.awaitTermination(500, java.util.concurrent.TimeUnit.MILLISECONDS)) {
                    executorService.shutdownNow();
                }
            } catch (Exception e) {
                Log.e(TAG, "Error shutting down executor service: " + e.getMessage(), e);
                executorService.shutdownNow();
            }
        }
        super.onDestroy();
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        // Additional safety check
        if (isFinishing()) {
            isExecutorActive = false;
        }
    }
    
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
} 