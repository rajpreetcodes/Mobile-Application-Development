package com.example.ts_project_is_mad;

import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;

import java.util.List;

public class TurfAdapter extends RecyclerView.Adapter<TurfAdapter.TurfViewHolder> {
    private static final String TAG = "TurfAdapter";
    private List<Turf> turfList;
    private OnTurfClickListener listener;

    public interface OnTurfClickListener {
        void onTurfClick(Turf turf);
    }

    // Constructor with just the list
    public TurfAdapter(List<Turf> turfList) {
        this.turfList = turfList;
    }

    // Setter for the click listener
    public void setOnTurfClickListener(OnTurfClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public TurfViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_turf, parent, false);
        return new TurfViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TurfViewHolder holder, int position) {
        Turf turf = turfList.get(position);
        holder.bind(turf, listener);
    }

    @Override
    public int getItemCount() {
        return turfList != null ? turfList.size() : 0;
    }

    static class TurfViewHolder extends RecyclerView.ViewHolder {
        private ImageView turfImageView;
        private TextView nameTextView;
        private TextView descriptionTextView;
        private TextView locationTextView;
        private TextView priceTextView;
        private Button bookNowButton;

        public TurfViewHolder(@NonNull View itemView) {
            super(itemView);
            turfImageView = itemView.findViewById(R.id.turfImage);
            nameTextView = itemView.findViewById(R.id.turfName);
            descriptionTextView = itemView.findViewById(R.id.turfDescription);
            locationTextView = itemView.findViewById(R.id.turfLocation);
            priceTextView = itemView.findViewById(R.id.turfPrice);
            bookNowButton = itemView.findViewById(R.id.bookNowButton);
        }

        public void bind(final Turf turf, final OnTurfClickListener listener) {
            try {
                // Load turf image if available
                if (turf.getImageUrl() != null && !turf.getImageUrl().isEmpty()) {
                    Glide.with(itemView.getContext())
                            .load(turf.getImageUrl())
                            .transition(DrawableTransitionOptions.withCrossFade())
                            .apply(new RequestOptions()
                                    .placeholder(android.R.drawable.ic_menu_gallery)
                                    .error(android.R.drawable.ic_menu_report_image))
                            .centerCrop()
                            .into(turfImageView);
                } else {
                    // Load placeholder if no image
                    turfImageView.setImageResource(android.R.drawable.ic_menu_gallery);
                }

                nameTextView.setText(turf.getName());
                descriptionTextView.setText(turf.getDescription());
                locationTextView.setText(turf.getLocation());
                priceTextView.setText(String.format("₹%.2f/hr", turf.getPrice()));

                // Make the entire item clickable
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (listener != null) {
                            listener.onTurfClick(turf);
                        }
                    }
                });

                // Make the Book Now button clickable
                if (bookNowButton != null) {
                    bookNowButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            try {
                                Log.d(TAG, "Book Now button clicked for turf: " + turf.getName());
                                // Navigate directly to BookingActivity
                                Intent intent = new Intent(itemView.getContext(), BookingActivity.class);
                                intent.putExtra("turf_id", turf.getId());
                                itemView.getContext().startActivity(intent);
                            } catch (Exception e) {
                                Log.e(TAG, "Error navigating to booking screen: " + e.getMessage(), e);
                                Toast.makeText(itemView.getContext(),
                                        "Error opening booking screen", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            } catch (Exception e) {
                Log.e(TAG, "Error binding turf data: " + e.getMessage(), e);
            }
        }
    }
}