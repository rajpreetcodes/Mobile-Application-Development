package com.example.ts_project_is_mad;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private FloatingActionButton addTurfFab;
    private Button browseTurfsButton;
    private Button viewBookingsButton;
    private DatabaseHelper dbHelper;
    private long userId;
    private String userType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Get user info from shared preferences
        getUserInfo();

        // Set up toolbar without setting it as support action bar
        Toolbar toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
            toolbar.setTitle("Book My Turf");
        }

        // Initialize buttons
        initializeButtons();

        // Configure buttons based on user type
        configureUIByUserType();
    }

    private void getUserInfo() {
        try {
            SharedPreferences sharedPreferences = getSharedPreferences("TurfBookingPrefs", MODE_PRIVATE);
            String userEmail = sharedPreferences.getString("userEmail", "");
            
            if (!userEmail.isEmpty()) {
                userId = dbHelper.getUserId(userEmail);
                userType = dbHelper.getUserType(userEmail);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error retrieving user info", Toast.LENGTH_SHORT).show();
            // Default to regular user
            userType = "user";
        }
    }

    private void initializeButtons() {
        // Initialize browse turfs button
        browseTurfsButton = findViewById(R.id.browseTurfsButton);
        if (browseTurfsButton != null) {
            browseTurfsButton.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, TurfListActivity.class);
                startActivity(intent);
            });
        }
        
        // Initialize view map button
        Button viewMapButton = findViewById(R.id.viewMapButton);
        if (viewMapButton != null) {
            viewMapButton.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, MapViewActivity.class);
                startActivity(intent);
            });
        }

        // Initialize view bookings button
        viewBookingsButton = findViewById(R.id.viewBookingsButton);
        if (viewBookingsButton != null) {
            viewBookingsButton.setOnClickListener(v -> {
                // We'll create BookingHistoryActivity later
                Toast.makeText(MainActivity.this, "View Bookings clicked", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, BookingHistoryActivity.class);
                intent.putExtra("user_id", userId);
                startActivity(intent);
            });
        }

        // Initialize add turf FAB
        addTurfFab = findViewById(R.id.addTurfFab);
        if (addTurfFab != null) {
            addTurfFab.setOnClickListener(v -> {
                if ("owner".equals(userType)) {
                    Intent intent = new Intent(MainActivity.this, AddTurfActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Only turf owners can add turfs", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void configureUIByUserType() {
        if (addTurfFab != null) {
            // Only show FAB for turf owners
            if ("owner".equals(userType)) {
                addTurfFab.setVisibility(View.VISIBLE);
            } else {
                addTurfFab.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_logout) {
            // Clear shared preferences
            SharedPreferences sharedPreferences = getSharedPreferences("TurfBookingPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.clear();
            editor.apply();

            // Handle logout
            Toast.makeText(this, "Logging out...", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}