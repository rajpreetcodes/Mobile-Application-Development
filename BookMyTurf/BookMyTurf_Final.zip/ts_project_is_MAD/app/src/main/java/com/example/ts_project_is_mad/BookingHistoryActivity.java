package com.example.ts_project_is_mad;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class BookingHistoryActivity extends AppCompatActivity {
    private static final String TAG = "BookingHistoryActivity";
    private RecyclerView bookingsRecyclerView;
    private TextView emptyBookingsText;
    private DatabaseHelper dbHelper;
    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_history);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Get user ID from intent
        userId = getIntent().getLongExtra("user_id", -1);
        if (userId == -1) {
            Toast.makeText(this, "Error: User ID not provided", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Set up toolbar
        setupToolbar();

        // Initialize views
        initializeViews();

        // Load booking history
        loadBookingHistory();
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setTitle("My Bookings");
            }
        }
    }

    private void initializeViews() {
        try {
            bookingsRecyclerView = findViewById(R.id.bookingsRecyclerView);
            emptyBookingsText = findViewById(R.id.emptyBookingsText);

            // Set up the RecyclerView
            bookingsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        } catch (Exception e) {
            Log.e(TAG, "Error initializing views: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing views", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadBookingHistory() {
        try {
            // Get the user's bookings
            List<Booking> bookings = dbHelper.getUserBookings(userId);

            if (bookings.isEmpty()) {
                // Show empty state
                bookingsRecyclerView.setVisibility(View.GONE);
                emptyBookingsText.setVisibility(View.VISIBLE);
            } else {
                // Show the bookings
                bookingsRecyclerView.setVisibility(View.VISIBLE);
                emptyBookingsText.setVisibility(View.GONE);

                // Create and set the adapter
                BookingAdapter adapter = new BookingAdapter(this, bookings);
                bookingsRecyclerView.setAdapter(adapter);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error loading booking history: " + e.getMessage(), e);
            Toast.makeText(this, "Error loading booking history", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
} 