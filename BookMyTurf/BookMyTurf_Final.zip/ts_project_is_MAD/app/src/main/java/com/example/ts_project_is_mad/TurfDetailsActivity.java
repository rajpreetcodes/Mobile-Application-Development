package com.example.ts_project_is_mad;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;

public class TurfDetailsActivity extends AppCompatActivity {
    private static final String TAG = "TurfDetailsActivity";
    private ImageView turfImage;
    private TextView turfName;
    private TextView turfDescription;
    private TextView turfLocation;
    private TextView turfPrice;
    private Button bookButton;
    private DatabaseHelper dbHelper;
    private Turf turf;
    private long turfId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_turf_details);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Initialize views
        initializeViews();

        // Get turf ID from intent with better error handling
        boolean turfIdReceived = false;
        
        try {
            // Try as long first (preferred)
            if (getIntent().hasExtra("turf_id")) {
                turfId = getIntent().getLongExtra("turf_id", -1);
                turfIdReceived = turfId != -1;
                Log.d(TAG, "Received turf_id as long: " + turfId);
                
                // If we got -1, also try as int for backwards compatibility
                if (turfId == -1) {
                    int intTurfId = getIntent().getIntExtra("turf_id", -1);
                    if (intTurfId != -1) {
                        turfId = intTurfId;
                        turfIdReceived = true;
                        Log.d(TAG, "Received turf_id as int: " + turfId);
                    }
                }
            }
            
            // If still not found, check for alternative parameter names
            if (!turfIdReceived) {
                if (getIntent().hasExtra("id")) {
                    turfId = getIntent().getLongExtra("id", -1);
                    turfIdReceived = turfId != -1;
                    Log.d(TAG, "Received id as long: " + turfId);
                }
            }
            
            if (!turfIdReceived) {
                // Log all extras for debugging
                Bundle extras = getIntent().getExtras();
                if (extras != null) {
                    for (String key : extras.keySet()) {
                        Log.d(TAG, "Intent extra: " + key + " = " + extras.get(key));
                    }
                } else {
                    Log.e(TAG, "No extras provided in intent");
                }
                
                Toast.makeText(this, "Error: No turf selected", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error retrieving turf ID from intent: " + e.getMessage(), e);
            Toast.makeText(this, "Error retrieving turf ID: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Load turf details
        loadTurfDetails();

        // Setup booking button
        setupBookButton();
    }

    private void initializeViews() {
        try {
            // Set up toolbar
            Toolbar toolbar = findViewById(R.id.toolbar);
            if (toolbar != null) {
                toolbar.setTitle("Turf Details");
                // Check if we're using a theme with no action bar before setting support action bar
                try {
                    // Only set support action bar for No ActionBar themes
                    if (getTheme().obtainStyledAttributes(new int[]{android.R.attr.windowActionBar}).getBoolean(0, true) == false) {
                        setSupportActionBar(toolbar);
                    }
                    if (getSupportActionBar() != null) {
                        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                    }
                } catch (Exception e) {
                    Log.w(TAG, "Theme already has action bar, skipping toolbar setup: " + e.getMessage());
                    // Just ensure back button is enabled in existing action bar
                    if (getSupportActionBar() != null) {
                        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                        getSupportActionBar().setTitle("Turf Details");
                    }
                }
            } else {
                // If no toolbar in layout, just set the title in the existing action bar
                if (getSupportActionBar() != null) {
                    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                    getSupportActionBar().setTitle("Turf Details");
                }
            }

            // Find views with null checks and detailed logging
            turfImage = findViewById(R.id.turfImage);
            turfName = findViewById(R.id.turfName);
            turfDescription = findViewById(R.id.turfDescription);
            turfLocation = findViewById(R.id.turfLocation);
            turfPrice = findViewById(R.id.turfPrice);
            bookButton = findViewById(R.id.bookButton);

            // Log the view IDs to help debugging
            Log.d(TAG, "View IDs - Image: " + (turfImage != null ? "Found" : "NULL") +
                    ", Name: " + (turfName != null ? "Found" : "NULL") +
                    ", Description: " + (turfDescription != null ? "Found" : "NULL") +
                    ", Location: " + (turfLocation != null ? "Found" : "NULL") +
                    ", Price: " + (turfPrice != null ? "Found" : "NULL") +
                    ", Book Button: " + (bookButton != null ? "Found" : "NULL"));

            // Check if any views are null and report the error
            if (turfImage == null || turfName == null || turfDescription == null || 
                    turfLocation == null || turfPrice == null) {
                Log.e(TAG, "One or more views not found in layout");
                Toast.makeText(this, "Error: Some turf details views could not be found", Toast.LENGTH_SHORT).show();
            }

            // Ensure book button is configured properly
            if (bookButton == null) {
                Log.e(TAG, "Book button not found in layout");
                Toast.makeText(this, "Error: Book button not found", Toast.LENGTH_SHORT).show();
            } else {
                Log.d(TAG, "Book button found in layout");
                // Explicitly set important properties
                bookButton.setVisibility(View.VISIBLE);
                bookButton.setEnabled(true);
                bookButton.setClickable(true);
                bookButton.setBackgroundColor(getResources().getColor(R.color.green_500));
                bookButton.setTextColor(getResources().getColor(android.R.color.white));
                Log.d(TAG, "Book button visibility set to VISIBLE");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error initializing views: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing views: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void loadTurfDetails() {
        try {
            // Get turf from database
            turf = dbHelper.getTurfById(turfId);

            if (turf != null) {
                Log.d(TAG, "Loaded turf: " + turf.getName() + " (ID: " + turf.getId() + ")");

                // Make sure views are initialized before setting data
                if (turfName == null || turfDescription == null || turfLocation == null || turfPrice == null) {
                    Log.e(TAG, "Views not initialized properly before setting turf details");
                    initializeViews(); // Try to initialize views again
                }

                // Set turf details with null checks
                if (turfName != null) turfName.setText(turf.getName());
                if (turfDescription != null) turfDescription.setText(turf.getDescription());
                if (turfLocation != null) turfLocation.setText(turf.getLocation());
                if (turfPrice != null) turfPrice.setText(String.format("₹%.2f/hr", turf.getPrice()));

                // Load and display turf image if available
                if (turf.getImageUrl() != null && !turf.getImageUrl().isEmpty() && turfImage != null) {
                    loadTurfImage(turf.getImageUrl());
                } else if (turfImage != null) {
                    // Set a default image
                    turfImage.setImageResource(android.R.drawable.ic_menu_gallery);
                    Log.d(TAG, "Using default image (no image URL provided)");
                }
            } else {
                Log.e(TAG, "Turf not found with ID: " + turfId);
                // Show error message
                Toast.makeText(this, "Error: Turf not found", Toast.LENGTH_SHORT).show();
                // Use dummy data if turf not found
                setTurfDetails("Sample Turf",
                        "A beautiful turf with excellent facilities",
                        "Mumbai, Maharashtra",
                        "₹1000/hr");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error loading turf details: " + e.getMessage(), e);
            Toast.makeText(this, "Error loading turf details: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void loadTurfImage(String imageUrl) {
        if (turfImage != null) {
            try {
                Log.d(TAG, "Loading turf image from URL: " + imageUrl);

                Glide.with(this)
                        .load(imageUrl)
                        .transition(DrawableTransitionOptions.withCrossFade())
                        .apply(new RequestOptions()
                                .placeholder(android.R.drawable.ic_menu_gallery)
                                .error(android.R.drawable.ic_menu_report_image))
                        .centerCrop()
                        .into(turfImage);
            } catch (Exception e) {
                Log.e(TAG, "Error loading turf image: " + e.getMessage(), e);
                // Set a default image if loading fails
                turfImage.setImageResource(android.R.drawable.ic_menu_gallery);
            }
        }
    }

    private void setTurfDetails(String name, String description, String location, String price) {
        try {
            if (turfName != null) turfName.setText(name);
            if (turfDescription != null) turfDescription.setText(description);
            if (turfLocation != null) turfLocation.setText(location);
            if (turfPrice != null) turfPrice.setText(price);
        } catch (Exception e) {
            Log.e(TAG, "Error setting turf details: " + e.getMessage(), e);
        }
    }

    private void setupBookButton() {
        try {
            if (bookButton != null) {
                // Make sure the button is clickable and enabled
                bookButton.setClickable(true);
                bookButton.setEnabled(true);

                // Set a background color to make it visually clear it's clickable
                bookButton.setBackgroundColor(getResources().getColor(R.color.green_500));
                bookButton.setTextColor(getResources().getColor(android.R.color.white));

                Log.d(TAG, "Setting up book button click listener");

                bookButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            Log.d(TAG, "Book button clicked for turf ID: " + turfId);
                            // Navigate to BookingActivity
                            Intent intent = new Intent(TurfDetailsActivity.this, BookingActivity.class);
                            intent.putExtra("turf_id", turfId);
                            startActivity(intent);
                        } catch (Exception e) {
                            Log.e(TAG, "Error navigating to booking screen: " + e.getMessage(), e);
                            Toast.makeText(TurfDetailsActivity.this,
                                    "Error opening booking screen", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

                // Add a touch listener for additional debugging
                bookButton.setOnTouchListener((v, event) -> {
                    Log.d(TAG, "Book button touch event: " + event.getAction());
                    return false; // Return false to allow the click event to be processed
                });
            } else {
                Log.e(TAG, "Book button is null, cannot set click listener");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error setting up book button: " + e.getMessage(), e);
            Toast.makeText(this, "Error setting up booking button", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}