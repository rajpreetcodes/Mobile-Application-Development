package com.example.ts_project_is_mad;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class DatabaseInfoActivity extends AppCompatActivity {
    private TextView dbPathText;
    private TextView userCountText;
    private TextView turfCountText;
    private Button clearDatabaseButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_database_info);

            // Initialize database helper
            dbHelper = new DatabaseHelper(this);

            // Set up toolbar
            Toolbar toolbar = findViewById(R.id.toolbar);
            if (toolbar != null) {
                setSupportActionBar(toolbar);
                if (getSupportActionBar() != null) {
                    getSupportActionBar().setTitle("Database Information");
                    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                }
            }

            // Initialize views
            dbPathText = findViewById(R.id.dbPathText);
            userCountText = findViewById(R.id.userCountText);
            turfCountText = findViewById(R.id.turfCountText);
            clearDatabaseButton = findViewById(R.id.clearDatabaseButton);

            // Display database information
            displayDatabaseInfo();

            // Set up clear database button
            if (clearDatabaseButton != null) {
                clearDatabaseButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        clearDatabase();
                    }
                });
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error initializing Database Info screen: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void displayDatabaseInfo() {
        try {
            // Get database path
            String dbPath = dbHelper.getDatabasePath();
            dbPathText.setText("Database Path:\n" + dbPath);

            // Get user count
            int userCount = getUserCount();
            userCountText.setText("Users in database: " + userCount);

            // Get turf count
            int turfCount = getTurfCount();
            turfCountText.setText("Turfs in database: " + turfCount);
        } catch (Exception e) {
            Toast.makeText(this, "Error displaying database info: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }
    }

    private int getUserCount() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM users", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    private int getTurfCount() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM turfs", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    private void clearDatabase() {
        try {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            // Delete all records but keep the tables
            db.execSQL("DELETE FROM turfs");
            db.execSQL("DELETE FROM users");

            Toast.makeText(this, "Database cleared successfully", Toast.LENGTH_SHORT).show();

            // Refresh the counts
            displayDatabaseInfo();
        } catch (Exception e) {
            Toast.makeText(this, "Error clearing database: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        try {
            if (item.getItemId() == android.R.id.home) {
                onBackPressed();
                return true;
            }
            return super.onOptionsItemSelected(item);
        } catch (Exception e) {
            Toast.makeText(this, "Error handling menu item: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
            return false;
        }
    }
}