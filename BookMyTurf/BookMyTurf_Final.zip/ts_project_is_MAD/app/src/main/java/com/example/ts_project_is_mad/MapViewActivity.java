package com.example.ts_project_is_mad;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MapViewActivity extends AppCompatActivity implements OnMapReadyCallback {
    private static final String TAG = "MapViewActivity";
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    private GoogleMap mMap;
    private DatabaseHelper dbHelper;
    private List<Turf> turfList;
    private long highlightTurfId = -1;
    private LatLng selectedLocation = null;
    private Marker selectedLocationMarker = null;
    private Button sortByDistanceButton;
    private Button confirmSelectionButton;
    private boolean isSelectionMode = false;
    private Map<Marker, Turf> markerTurfMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_view);

        try {
            // Get turf ID to highlight if provided
            highlightTurfId = getIntent().getLongExtra("highlight_turf_id", -1);
            
            // Check if we're in location selection mode
            isSelectionMode = getIntent().getBooleanExtra("selection_mode", false);

            // Set up toolbar
            Toolbar toolbar = findViewById(R.id.toolbar);
            if (toolbar != null) {
                setSupportActionBar(toolbar);
                if (getSupportActionBar() != null) {
                    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                    getSupportActionBar().setTitle(isSelectionMode ? "Select Location" : "Turf Locations");
                }
            }

            // Initialize buttons
            sortByDistanceButton = findViewById(R.id.sortByDistanceButton);
            confirmSelectionButton = findViewById(R.id.confirmSelectionButton);
            
            if (sortByDistanceButton != null) {
                sortByDistanceButton.setOnClickListener(v -> selectLocationForSorting());
                sortByDistanceButton.setVisibility(isSelectionMode ? View.GONE : View.VISIBLE);
            }
            
            if (confirmSelectionButton != null) {
                confirmSelectionButton.setOnClickListener(v -> confirmLocationSelection());
                confirmSelectionButton.setVisibility(isSelectionMode ? View.VISIBLE : View.GONE);
            }

            // Initialize database helper
            dbHelper = new DatabaseHelper(this);

            // Obtain the SupportMapFragment and get notified when the map is ready to be used
            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.map);
            if (mapFragment != null) {
                mapFragment.getMapAsync(this);
            } else {
                Log.e(TAG, "Map fragment not found");
                Toast.makeText(this, "Error: Map could not be initialized", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }

            // Load turf data
            loadTurfData();
        } catch (Exception e) {
            Log.e(TAG, "Error initializing map activity: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing map view", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void loadTurfData() {
        try {
            // Initialize turfList if it's null
            if (turfList == null) {
                turfList = new ArrayList<>();
            }
            
            // Check if we received specific turf IDs from the calling activity
            long[] turfIds = getIntent().getLongArrayExtra("turf_ids");
            
            if (turfIds != null && turfIds.length > 0) {
                // Load only the specific turfs from the database
                turfList.clear();
                for (long turfId : turfIds) {
                    Turf turf = dbHelper.getTurfById(turfId);
                    if (turf != null) {
                        turfList.add(turf);
                    }
                }
                
                // Update toolbar title if we also have a search query
                String searchQuery = getIntent().getStringExtra("search_query");
                if (searchQuery != null && !searchQuery.isEmpty() && getSupportActionBar() != null) {
                    getSupportActionBar().setTitle("Search Results: " + searchQuery);
                }
            } else {
                // Get all turfs from database if no specific IDs were passed
                turfList = dbHelper.getAllTurfs();
            }
            
            Log.d(TAG, "Loaded " + turfList.size() + " turfs from database");
        } catch (Exception e) {
            Log.e(TAG, "Error loading turf data: " + e.getMessage(), e);
            Toast.makeText(this, "Error loading turf data", Toast.LENGTH_SHORT).show();
            // Initialize an empty list if there was an error
            turfList = new ArrayList<>();
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        try {
            mMap = googleMap;

            // Check for location permission
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                mMap.setMyLocationEnabled(true);
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                        LOCATION_PERMISSION_REQUEST_CODE);
            }

            // Set map type to Normal (default)
            mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);

            // Enable zoom controls
            mMap.getUiSettings().setZoomControlsEnabled(true);
            mMap.getUiSettings().setZoomGesturesEnabled(true);

            // Add markers for each turf
            addTurfMarkers();

            // Set info window click listener for navigation
            mMap.setOnInfoWindowClickListener(marker -> {
                // Only navigate to turfs, not to the selection marker
                if (marker != selectedLocationMarker) {
                    // Get the position of the marker
                    LatLng position = marker.getPosition();
                    // Create a navigation intent
                    startNavigation(position.latitude, position.longitude, marker.getTitle());
                }
            });
            
            // Set map click listener for location selection mode
            mMap.setOnMapClickListener(latLng -> {
                if (isSelectionMode) {
                    // In selection mode, update the selected location
                    selectedLocation = latLng;
                    updateSelectionMarker();
                }
            });

            // Default position in India (Mumbai)
            LatLng defaultPosition = new LatLng(19.0760, 72.8777);
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultPosition, 10));
        } catch (Exception e) {
            Log.e(TAG, "Error initializing map: " + e.getMessage(), e);
            Toast.makeText(this, "Error setting up map", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void selectLocationForSorting() {
        // Clear previous selection if any
        selectedLocation = null;
        if (selectedLocationMarker != null) {
            selectedLocationMarker.remove();
            selectedLocationMarker = null;
        }
        
        // Show instruction to user
        Toast.makeText(this, "Tap on the map to select a location", Toast.LENGTH_LONG).show();
        
        // Enable location selection mode
        mMap.setOnMapClickListener(latLng -> {
            selectedLocation = latLng;
            updateSelectionMarker();
            sortTurfsByDistance();
        });
    }
    
    private void updateSelectionMarker() {
        // Remove previous marker if exists
        if (selectedLocationMarker != null) {
            selectedLocationMarker.remove();
        }
        
        // Add new marker at selected location
        if (selectedLocation != null) {
            selectedLocationMarker = mMap.addMarker(new MarkerOptions()
                    .position(selectedLocation)
                    .title("Selected Location")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));
            
            // Move camera to selected location
            mMap.animateCamera(CameraUpdateFactory.newLatLng(selectedLocation));
        }
    }
    
    private void sortTurfsByDistance() {
        if (selectedLocation == null || turfList == null || turfList.isEmpty()) {
            return;
        }
        
        // Clear existing markers
        mMap.clear();
        markerTurfMap.clear();
        
        // Add back the selection marker
        updateSelectionMarker();
        
        // Sort turfs by distance to selected location
        Collections.sort(turfList, new Comparator<Turf>() {
            @Override
            public int compare(Turf t1, Turf t2) {
                float[] results1 = new float[1];
                float[] results2 = new float[1];
                
                // Calculate distance for first turf
                Location.distanceBetween(
                        selectedLocation.latitude,
                        selectedLocation.longitude,
                        t1.getLatitude() != 0 ? t1.getLatitude() : 19.0760, // Default to Mumbai if no location
                        t1.getLongitude() != 0 ? t1.getLongitude() : 72.8777,
                        results1);
                
                // Calculate distance for second turf
                Location.distanceBetween(
                        selectedLocation.latitude,
                        selectedLocation.longitude,
                        t2.getLatitude() != 0 ? t2.getLatitude() : 19.0760,
                        t2.getLongitude() != 0 ? t2.getLongitude() : 72.8777,
                        results2);
                
                // Compare distances
                return Float.compare(results1[0], results2[0]);
            }
        });
        
        // Add markers for sorted turfs with distance information
        for (int i = 0; i < turfList.size(); i++) {
            Turf turf = turfList.get(i);
            LatLng position;
            
            if (turf.getLatitude() != 0 && turf.getLongitude() != 0) {
                position = new LatLng(turf.getLatitude(), turf.getLongitude());
            } else {
                // Default position with offset if no coordinates available
                double latOffset = (Math.random() - 0.5) * 0.04;
                double lngOffset = (Math.random() - 0.5) * 0.04;
                position = new LatLng(19.0760 + latOffset, 72.8777 + lngOffset);
            }
            
            // Calculate distance
            float[] results = new float[1];
            Location.distanceBetween(
                    selectedLocation.latitude,
                    selectedLocation.longitude,
                    position.latitude,
                    position.longitude,
                    results);
            
            // Format distance string
            String distanceStr;
            if (results[0] < 1000) {
                distanceStr = String.format(Locale.getDefault(), "%.0f m", results[0]);
            } else {
                distanceStr = String.format(Locale.getDefault(), "%.2f km", results[0] / 1000);
            }
            
            // Create marker with rank and distance info
            Marker marker = mMap.addMarker(new MarkerOptions()
                    .position(position)
                    .title(turf.getName())
                    .snippet("#" + (i+1) + " - " + distanceStr + " - ₹" + turf.getPrice() + "/hr")
                    .icon(BitmapDescriptorFactory.defaultMarker(
                            i < 3 ? BitmapDescriptorFactory.HUE_GREEN : BitmapDescriptorFactory.HUE_RED)));
            
            // Store marker to turf mapping
            markerTurfMap.put(marker, turf);
        }
        
        // Return sorted list to the calling activity
        Intent data = new Intent();
        long[] sortedIds = new long[turfList.size()];
        for (int i = 0; i < turfList.size(); i++) {
            sortedIds[i] = turfList.get(i).getId();
        }
        data.putExtra("sorted_turf_ids", sortedIds);
        data.putExtra("selected_latitude", selectedLocation.latitude);
        data.putExtra("selected_longitude", selectedLocation.longitude);
        setResult(RESULT_OK, data);
        
        Toast.makeText(this, "Turfs sorted by distance. Nearest turfs shown in green.", Toast.LENGTH_LONG).show();
    }
    
    private void confirmLocationSelection() {
        if (selectedLocation != null) {
            Intent resultIntent = new Intent();
            resultIntent.putExtra("latitude", selectedLocation.latitude);
            resultIntent.putExtra("longitude", selectedLocation.longitude);
            setResult(RESULT_OK, resultIntent);
            finish();
        } else {
            Toast.makeText(this, "Please select a location first", Toast.LENGTH_SHORT).show();
        }
    }

    private void addTurfMarkers() {
        try {
            if (mMap == null || turfList == null || turfList.isEmpty()) {
                Log.d(TAG, "No map or turfs available for adding markers");
                return;
            }
            
            // Clear existing markers
            mMap.clear();
            markerTurfMap.clear();
            
            Log.d(TAG, "Adding " + turfList.size() + " turf markers to map");
            
            // Initial position for camera
            LatLng initialPosition = null;
            
            for (Turf turf : turfList) {
                try {
                    double latitude = turf.getLatitude();
                    double longitude = turf.getLongitude();
                    
                    // Skip if the coordinates are 0, which indicates no location is set
                    if (latitude == 0 && longitude == 0) {
                        Log.d(TAG, "Skipping turf " + turf.getId() + " - no coordinates");
                        continue;
                    }
                    
                    LatLng position = new LatLng(latitude, longitude);
                    
                    // Use the first valid position or highlighted turf position as initial position
                    if (initialPosition == null || turf.getId() == highlightTurfId) {
                        initialPosition = position;
                    }
                    
                    // Create marker with turf info
                    MarkerOptions markerOptions = new MarkerOptions()
                            .position(position)
                            .title(turf.getName())
                            .snippet(String.format(Locale.getDefault(), "₹%.2f/hr - %s", turf.getPrice(), turf.getLocation()));
                    
                    // Highlight marker if it matches highlightTurfId
                    if (turf.getId() == highlightTurfId) {
                        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
                    }
                    
                    Marker marker = mMap.addMarker(markerOptions);
                    
                    if (marker != null) {
                        // Store marker-turf mapping
                        markerTurfMap.put(marker, turf);
                        
                        // Show info window if this is the highlighted turf
                        if (turf.getId() == highlightTurfId) {
                            marker.showInfoWindow();
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error adding marker for turf " + turf.getId() + ": " + e.getMessage(), e);
                }
            }
            
            // Move camera to initial position if set
            if (initialPosition != null) {
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(initialPosition, 13));
            } else if (!markerTurfMap.isEmpty()) {
                // If no initial position but we have markers, zoom to include all markers
                // This is just a fallback
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(
                        new LatLng(19.0760, 72.8777), 10));
            }
        } catch (Exception e) {
            Log.e(TAG, "Error adding turf markers: " + e.getMessage(), e);
            Toast.makeText(this, "Error displaying turf locations", Toast.LENGTH_SHORT).show();
        }
    }
    
    /**
     * Start navigation to the turf using external maps app
     */
    private void startNavigation(double latitude, double longitude, String turfName) {
        try {
            // Format the location data for the URI
            String uriString = String.format(Locale.ENGLISH, 
                    "geo:%f,%f?q=%f,%f(%s)", 
                    latitude, longitude, latitude, longitude, 
                    Uri.encode(turfName));
            
            // Create the intent
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uriString));
            
            // Check if there's an app that can handle this intent
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            } else {
                Toast.makeText(this, "No maps app found to navigate", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error starting navigation: " + e.getMessage());
            Toast.makeText(this, "Error starting navigation", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                if (mMap != null && ActivityCompat.checkSelfPermission(this,
                        android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    mMap.setMyLocationEnabled(true);
                }
            } else {
                // Permission denied
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
} 