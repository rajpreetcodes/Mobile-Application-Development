package com.example.ts_project_is_mad;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

/**
 * Class for managing user sessions
 */
public class SessionManager {
    private static final String TAG = "SessionManager";
    private static final String PREF_NAME = "BookMyTurfSession";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static final String KEY_USER_ID = "userId";
    private static final String KEY_USER_NAME = "userName";
    private static final String KEY_USER_EMAIL = "userEmail";
    private static final String KEY_USER_TYPE = "userType";
    private static final String KEY_USER_PHONE = "userPhone";
    
    /**
     * Save user login session
     * @param context The application context
     * @param user The user object to save
     */
    public static void saveLoggedInUser(Context context, User user) {
        try {
            SharedPreferences pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = pref.edit();
            
            editor.putBoolean(KEY_IS_LOGGED_IN, true);
            editor.putLong(KEY_USER_ID, user.getId());
            editor.putString(KEY_USER_NAME, user.getName());
            editor.putString(KEY_USER_EMAIL, user.getEmail());
            editor.putString(KEY_USER_TYPE, user.getUserType());
            editor.putString(KEY_USER_PHONE, user.getPhone());
            
            editor.apply();
            Log.d(TAG, "User session saved: " + user.getName());
        } catch (Exception e) {
            Log.e(TAG, "Error saving user session: " + e.getMessage(), e);
        }
    }
    
    /**
     * Get the currently logged in user
     * @param context The application context
     * @return The logged in user, or null if not logged in
     */
    public static User getLoggedInUser(Context context) {
        try {
            SharedPreferences pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            
            if (!pref.getBoolean(KEY_IS_LOGGED_IN, false)) {
                return null; // No logged in user
            }
            
            User user = new User();
            user.setId(pref.getLong(KEY_USER_ID, -1));
            user.setName(pref.getString(KEY_USER_NAME, ""));
            user.setEmail(pref.getString(KEY_USER_EMAIL, ""));
            user.setUserType(pref.getString(KEY_USER_TYPE, ""));
            user.setPhone(pref.getString(KEY_USER_PHONE, ""));
            
            return user;
        } catch (Exception e) {
            Log.e(TAG, "Error getting logged in user: " + e.getMessage(), e);
            return null;
        }
    }
    
    /**
     * Check if a user is logged in
     * @param context The application context
     * @return true if a user is logged in, false otherwise
     */
    public static boolean isLoggedIn(Context context) {
        try {
            SharedPreferences pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            return pref.getBoolean(KEY_IS_LOGGED_IN, false);
        } catch (Exception e) {
            Log.e(TAG, "Error checking login status: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * Logout the current user
     * @param context The application context
     */
    public static void logout(Context context) {
        try {
            SharedPreferences pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = pref.edit();
            
            // Clear all data
            editor.clear();
            editor.apply();
            
            Log.d(TAG, "User logged out");
        } catch (Exception e) {
            Log.e(TAG, "Error logging out: " + e.getMessage(), e);
        }
    }
} 