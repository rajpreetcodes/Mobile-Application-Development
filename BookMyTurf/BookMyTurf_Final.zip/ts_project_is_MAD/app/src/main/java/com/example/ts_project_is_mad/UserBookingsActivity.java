package com.example.ts_project_is_mad;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class UserBookingsActivity extends AppCompatActivity {
    private static final String TAG = "UserBookingsActivity";
    
    private DatabaseHelper dbHelper;
    private RecyclerView recyclerView;
    private BookingAdapter bookingAdapter;
    private SwipeRefreshLayout swipeRefreshLayout;
    private List<Booking> bookingsList;
    private View emptyView;
    private TabLayout tabLayout;
    private FloatingActionButton newBookingFab;
    
    private long userId = 1; // Default user ID for testing
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_bookings);
        
        // Initialize database helper
        dbHelper = new DatabaseHelper(this);
        
        // Set up toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setTitle("My Bookings");
            }
        }
        
        // Try to get logged in user from session
        User currentUser = SessionManager.getLoggedInUser(this);
        if (currentUser != null) {
            userId = currentUser.getId();
        } else {
            // Get user ID from intent if passed
            userId = getIntent().getLongExtra("user_id", 1);
        }
        
        // Initialize views
        recyclerView = findViewById(R.id.bookingsRecyclerView);
        emptyView = findViewById(R.id.emptyView);
        tabLayout = findViewById(R.id.tabLayout);
        newBookingFab = findViewById(R.id.newBookingFab);
        
        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        bookingsList = new ArrayList<>();
        bookingAdapter = new BookingAdapter(this, bookingsList);
        bookingAdapter.setOnItemClickListener(booking -> {
            // Navigate to booking details when clicked
            Intent intent = new Intent(UserBookingsActivity.this, BookingDetailsActivity.class);
            intent.putExtra("booking_id", booking.getId());
            startActivity(intent);
        });
        recyclerView.setAdapter(bookingAdapter);
        
        // Set up tab layout for filtering (All, Upcoming, Past)
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                filterBookings(tab.getPosition());
            }
            
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}
            
            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
        
        // Initialize SwipeRefreshLayout
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setOnRefreshListener(this::loadBookings);
        swipeRefreshLayout.setColorSchemeResources(
                android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light
        );
        
        // Set up FAB for new booking
        newBookingFab.setOnClickListener(v -> {
            Intent intent = new Intent(UserBookingsActivity.this, TurfListActivity.class);
            startActivity(intent);
        });
        
        // Load bookings
        loadBookings();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        // Reload bookings when coming back to this activity
        loadBookings();
    }
    
    private void loadBookings() {
        try {
            swipeRefreshLayout.setRefreshing(true);
            
            // Get all bookings for this user from database
            List<Booking> allBookings = dbHelper.getBookingsByUserId(userId);
            
            // Update the adapter data
            bookingsList.clear();
            bookingsList.addAll(allBookings);
            
            // Apply current tab filter
            filterBookings(tabLayout.getSelectedTabPosition());
            
            swipeRefreshLayout.setRefreshing(false);
            
            // Show/hide empty view
            updateEmptyViewVisibility();
        } catch (Exception e) {
            Log.e(TAG, "Error loading bookings: " + e.getMessage(), e);
            swipeRefreshLayout.setRefreshing(false);
            showError("Error loading bookings: " + e.getMessage());
        }
    }
    
    private void filterBookings(int tabPosition) {
        if (bookingsList.isEmpty()) {
            return;
        }
        
        try {
            List<Booking> filteredList = new ArrayList<>();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            SimpleDateFormat bookingDateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            String today = dateFormat.format(new Date());
            
            // Get current time
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
            String currentTime = timeFormat.format(new Date());
            
            switch (tabPosition) {
                case 0: // All bookings
                    filteredList.addAll(bookingsList);
                    break;
                case 1: // Upcoming bookings
                    for (Booking booking : bookingsList) {
                        try {
                            // Convert booking date to standard format for comparison
                            Date bookingDate = bookingDateFormat.parse(booking.getBookingDate());
                            if (bookingDate == null) continue;
                            
                            String standardBookingDate = dateFormat.format(bookingDate);
                            
                            // For future dates
                            if (standardBookingDate.compareTo(today) > 0) {
                                filteredList.add(booking);
                            } 
                            // For today's bookings, check if the time is in the future
                            else if (standardBookingDate.equals(today) && booking.getTimeSlot().compareTo(currentTime) >= 0) {
                                filteredList.add(booking);
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error converting date: " + e.getMessage(), e);
                        }
                    }
                    break;
                case 2: // Past bookings
                    for (Booking booking : bookingsList) {
                        try {
                            // Convert booking date to standard format for comparison
                            Date bookingDate = bookingDateFormat.parse(booking.getBookingDate());
                            if (bookingDate == null) continue;
                            
                            String standardBookingDate = dateFormat.format(bookingDate);
                            
                            // Past dates
                            if (standardBookingDate.compareTo(today) < 0) {
                                filteredList.add(booking);
                            } 
                            // Today's bookings with past time
                            else if (standardBookingDate.equals(today) && booking.getTimeSlot().compareTo(currentTime) < 0) {
                                filteredList.add(booking);
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error converting date: " + e.getMessage(), e);
                        }
                    }
                    break;
            }
            
            // Update adapter with filtered results
            bookingAdapter.updateBookings(filteredList);
            
            // Show/hide empty view based on filtered results
            updateEmptyViewVisibility();
        } catch (Exception e) {
            Log.e(TAG, "Error filtering bookings: " + e.getMessage(), e);
            showError("Error filtering bookings");
        }
    }
    
    private void updateEmptyViewVisibility() {
        if (bookingAdapter.getItemCount() == 0) {
            recyclerView.setVisibility(View.GONE);
            emptyView.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            emptyView.setVisibility(View.GONE);
        }
    }
    
    private void showError(String message) {
        View rootView = findViewById(android.R.id.content);
        Snackbar.make(rootView, message, Snackbar.LENGTH_LONG).show();
    }
    
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
} 