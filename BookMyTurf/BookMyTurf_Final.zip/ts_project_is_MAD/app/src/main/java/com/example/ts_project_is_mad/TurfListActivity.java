package com.example.ts_project_is_mad;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TurfListActivity extends AppCompatActivity implements TurfAdapter.OnTurfClickListener {
    private static final String TAG = "TurfListActivity";
    private static final int REQUEST_MAP_VIEW = 1001;
    
    private RecyclerView turfRecyclerView;
    private TurfAdapter turfAdapter;
    private EditText searchInput;
    private Button searchButton;
    private Button viewMapButton;
    private TextView emptyView;
    private TextView welcomeMessageTextView;
    private DatabaseHelper dbHelper;
    private List<Turf> allTurfs = new ArrayList<>();
    private List<Turf> filteredTurfs = new ArrayList<>();
    private double selectedLatitude = 0;
    private double selectedLongitude = 0;
    private boolean locationSelected = false;
    
    // ActivityResultLauncher for map view
    private ActivityResultLauncher<Intent> mapViewLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_turf_list);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);
        
        // Register activity result launcher
        mapViewLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Intent data = result.getData();
                    long[] sortedIds = data.getLongArrayExtra("sorted_turf_ids");
                    
                    if (sortedIds != null && sortedIds.length > 0) {
                        // User sorted turfs by distance, update our list to match
                        updateTurfOrderFromSortedIds(sortedIds);
                        
                        // Get the selected location
                        selectedLatitude = data.getDoubleExtra("selected_latitude", 0);
                        selectedLongitude = data.getDoubleExtra("selected_longitude", 0);
                        locationSelected = true;
                        
                        // Update UI to indicate we're showing sorted results
                        if (viewMapButton != null) {
                            viewMapButton.setText("View Results Sorted by Distance");
                        }
                        
                        Toast.makeText(this, "Showing turfs sorted by distance", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        );

        // Initialize views
        initializeViews();

        // Load all turfs
        loadTurfs();

        // Set up search button
        setupSearchButton();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload turfs when returning to this activity
        loadTurfs();
    }

    private void initializeViews() {
        try {
            // Set up toolbar
            Toolbar toolbar = findViewById(R.id.toolbar);
            if (toolbar != null) {
                // Don't call setSupportActionBar as it's causing conflicts
                toolbar.setTitle("Available Turfs");
                toolbar.setNavigationIcon(android.R.drawable.ic_menu_revert);
                toolbar.setNavigationOnClickListener(v -> onBackPressed());
            }

            // Initialize views
            turfRecyclerView = findViewById(R.id.turfRecyclerView);
            searchInput = findViewById(R.id.searchInput);
            searchButton = findViewById(R.id.searchButton);
            viewMapButton = findViewById(R.id.viewMapButton);
            emptyView = findViewById(R.id.emptyView);
            welcomeMessageTextView = findViewById(R.id.welcomeMessageTextView);
            
            // Set welcome message with user's name
            if (welcomeMessageTextView != null) {
                // Get user ID from intent
                long userId = getIntent().getLongExtra("user_id", -1);
                if (userId > 0) {
                    String userName = dbHelper.getUserNameById(userId);
                    if (userName != null && !userName.isEmpty()) {
                        welcomeMessageTextView.setText("Welcome to BookMyTurf, " + userName);
                        Log.d(TAG, "Set welcome message for user: " + userName);
                    }
                }
            }
            
            // Set up "View on Map" button
            if (viewMapButton != null) {
                viewMapButton.setOnClickListener(v -> viewCurrentResultsOnMap());
            }

            // Set up RecyclerView
            turfRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        } catch (Exception e) {
            Log.e(TAG, "Error initializing views: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing views", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadTurfs() {
        try {
            // Get all turfs from database
            Log.d(TAG, "Loading all turfs from database");
            allTurfs = dbHelper.getAllTurfsAsList();
            filteredTurfs = new ArrayList<>(allTurfs);

            Log.d(TAG, "Found " + allTurfs.size() + " turfs in database");

            if (allTurfs.isEmpty()) {
                showEmptyState("No turfs available");
            } else {
                showTurfs(allTurfs);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error loading turfs: " + e.getMessage(), e);
            Toast.makeText(this, "Error loading turfs", Toast.LENGTH_SHORT).show();
            showEmptyState("Error loading turfs");
        }
    }

    private void setupSearchButton() {
        if (searchButton != null) {
            searchButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        String query = searchInput.getText().toString().trim().toLowerCase();
                        Log.d(TAG, "Search query: " + query);

                        if (TextUtils.isEmpty(query)) {
                            // If search is empty, show all turfs
                            filteredTurfs = new ArrayList<>(allTurfs);
                            Log.d(TAG, "Empty query, showing all " + allTurfs.size() + " turfs");
                        } else {
                            // Filter turfs based on search query
                            filteredTurfs = new ArrayList<>();
                            for (Turf turf : allTurfs) {
                                if (turf.getName().toLowerCase().contains(query) ||
                                        turf.getLocation().toLowerCase().contains(query) ||
                                        turf.getDescription().toLowerCase().contains(query)) {
                                    filteredTurfs.add(turf);
                                }
                            }
                            Log.d(TAG, "Found " + filteredTurfs.size() + " turfs matching query: " + query);
                        }

                        if (filteredTurfs.isEmpty()) {
                            showEmptyState("No turfs found matching '" + query + "'");
                        } else {
                            showTurfs(filteredTurfs);
                            Toast.makeText(TurfListActivity.this,
                                    "Found " + filteredTurfs.size() + " turfs", Toast.LENGTH_SHORT).show();
                        }
                        
                        // Reset location sorting indicator when searching
                        locationSelected = false;
                        if (viewMapButton != null) {
                            viewMapButton.setText("View Search Results on Map");
                        }
                        
                    } catch (Exception e) {
                        Log.e(TAG, "Error searching turfs: " + e.getMessage(), e);
                        Toast.makeText(TurfListActivity.this,
                                "Error searching turfs", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    private void viewCurrentResultsOnMap() {
        if (filteredTurfs.isEmpty()) {
            Toast.makeText(this, "No turfs to display on map", Toast.LENGTH_SHORT).show();
            return;
        }
        
        try {
            // Create an intent to open the MapViewActivity
            Intent intent = new Intent(TurfListActivity.this, MapViewActivity.class);
            
            // Pass the filtered turf IDs
            long[] turfIds = new long[filteredTurfs.size()];
            for (int i = 0; i < filteredTurfs.size(); i++) {
                turfIds[i] = filteredTurfs.get(i).getId();
            }
            
            intent.putExtra("turf_ids", turfIds);
            
            // Include search query if present
            if (searchInput != null && searchInput.getText() != null) {
                String query = searchInput.getText().toString().trim();
                if (!query.isEmpty()) {
                    intent.putExtra("search_query", query);
                }
            }
            
            // Launch map activity with result launcher
            mapViewLauncher.launch(intent);
        } catch (Exception e) {
            Log.e(TAG, "Error launching map view: " + e.getMessage(), e);
            Toast.makeText(this, "Error opening map view", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void updateTurfOrderFromSortedIds(long[] sortedIds) {
        if (sortedIds == null || sortedIds.length == 0) {
            return;
        }
        
        try {
            // Create a map of turf ID to turf object for quick lookup
            Map<Long, Turf> turfMap = new HashMap<>();
            for (Turf turf : filteredTurfs) {
                turfMap.put((long) turf.getId(), turf);
            }
            
            // Create a new ordered list based on the sortedIds array
            List<Turf> sortedTurfs = new ArrayList<>();
            for (long id : sortedIds) {
                Turf turf = turfMap.get(id);
                if (turf != null) {
                    sortedTurfs.add(turf);
                }
            }
            
            // Update our filtered list with the sorted order if we have matches
            if (!sortedTurfs.isEmpty()) {
                filteredTurfs = sortedTurfs;
                showTurfs(filteredTurfs);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error updating turf order: " + e.getMessage(), e);
            Toast.makeText(this, "Error sorting turfs", Toast.LENGTH_SHORT).show();
        }
    }

    private void showEmptyState(String message) {
        if (turfRecyclerView != null && emptyView != null) {
            Log.d(TAG, "Showing empty state: " + message);
            turfRecyclerView.setVisibility(View.GONE);
            emptyView.setVisibility(View.VISIBLE);
            emptyView.setText(message);
        }
    }

    private void showTurfs(List<Turf> turfs) {
        if (turfRecyclerView != null && emptyView != null) {
            Log.d(TAG, "Showing " + turfs.size() + " turfs in RecyclerView");
            turfRecyclerView.setVisibility(View.VISIBLE);
            emptyView.setVisibility(View.GONE);

            turfAdapter = new TurfAdapter(turfs);
            turfAdapter.setOnTurfClickListener(this);
            turfRecyclerView.setAdapter(turfAdapter);
        }
    }

    @Override
    public void onTurfClick(Turf turf) {
        try {
            Log.d(TAG, "Turf clicked: " + turf.getName() + " (ID: " + turf.getId() + ")");
            Intent intent = new Intent(TurfListActivity.this, TurfDetailsActivity.class);
            intent.putExtra("turf_id", turf.getId());
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "Error navigating to turf details: " + e.getMessage(), e);
            Toast.makeText(this, "Error opening turf details", Toast.LENGTH_SHORT).show();
        }
    }
    
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_turf_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        
        if (id == R.id.action_my_bookings) {
            // Open user bookings activity
            Intent intent = new Intent(this, UserBookingsActivity.class);
            startActivity(intent);
            return true;
        } else if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }
        
        return super.onOptionsItemSelected(item);
    }
} 