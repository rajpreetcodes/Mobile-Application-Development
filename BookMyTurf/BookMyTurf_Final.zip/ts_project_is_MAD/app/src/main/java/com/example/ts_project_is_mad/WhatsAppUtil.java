package com.example.ts_project_is_mad;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.util.Log;
import android.widget.Toast;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * Utility class for WhatsApp integration
 */
public class WhatsAppUtil {
    private static final String TAG = "WhatsAppUtil";
    
    /**
     * Sends a booking confirmation message via WhatsApp
     * @param context The application context
     * @param phoneNumber The phone number to send the message to (with country code, no '+')
     * @param booking The booking object containing the details
     * @return true if WhatsApp was launched, false otherwise
     */
    public static boolean sendBookingConfirmation(Context context, String phoneNumber, Booking booking) {
        try {
            // Validate phone number
            if (phoneNumber == null || phoneNumber.isEmpty()) {
                Log.e(TAG, "Phone number is empty");
                Toast.makeText(context, "Phone number not available", Toast.LENGTH_SHORT).show();
                return false;
            }
            
            // Format phone number (ensure it has country code)
            if (!phoneNumber.startsWith("+")) {
                // Assume Indian number if no country code
                if (phoneNumber.startsWith("0")) {
                    phoneNumber = "+91" + phoneNumber.substring(1);
                } else {
                    phoneNumber = "+91" + phoneNumber;
                }
            }
            
            // Remove any '+' as the URL needs the number without it
            phoneNumber = phoneNumber.replace("+", "");
            
            // Create the message
            String message = "🎉 *Booking Confirmed!* 🎉\n\n" +
                    "*Booking ID:* #" + booking.getId() + "\n\n" +
                    booking.getBookingSummary() + "\n\n" +
                    "Thank you for booking with BookMyTurf!\n" +
                    "Please arrive 15 minutes before your slot.\n" +
                    "For any queries, please contact the turf owner.";
            
            // Encode the message
            String encodedMessage = URLEncoder.encode(message, "UTF-8");
            
            // Create WhatsApp intent
            Intent whatsappIntent = new Intent(Intent.ACTION_VIEW);
            whatsappIntent.setData(Uri.parse("https://api.whatsapp.com/send?phone=" + phoneNumber + "&text=" + encodedMessage));
            
            // Check if WhatsApp is installed
            PackageManager packageManager = context.getPackageManager();
            if (whatsappIntent.resolveActivity(packageManager) != null) {
                context.startActivity(whatsappIntent);
                Log.d(TAG, "WhatsApp message intent launched");
                return true;
            } else {
                Log.e(TAG, "WhatsApp is not installed");
                Toast.makeText(context, "WhatsApp is not installed on this device", Toast.LENGTH_LONG).show();
                
                // Fallback to a browser-based WhatsApp
                Intent browserIntent = new Intent(Intent.ACTION_VIEW);
                browserIntent.setData(Uri.parse("https://api.whatsapp.com/send?phone=" + phoneNumber + "&text=" + encodedMessage));
                context.startActivity(browserIntent);
                return true;
            }
        } catch (UnsupportedEncodingException e) {
            Log.e(TAG, "Error encoding message: " + e.getMessage(), e);
            Toast.makeText(context, "Error preparing WhatsApp message", Toast.LENGTH_SHORT).show();
            return false;
        } catch (Exception e) {
            Log.e(TAG, "Error sending WhatsApp message: " + e.getMessage(), e);
            Toast.makeText(context, "Error launching WhatsApp", Toast.LENGTH_SHORT).show();
            return false;
        }
    }
    
    /**
     * Check if WhatsApp is installed on the device
     * @param context The application context
     * @return true if WhatsApp is installed, false otherwise
     */
    public static boolean isWhatsAppInstalled(Context context) {
        try {
            context.getPackageManager().getPackageInfo("com.whatsapp", PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
} 