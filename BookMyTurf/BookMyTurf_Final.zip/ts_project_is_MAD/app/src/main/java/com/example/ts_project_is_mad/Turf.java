package com.example.ts_project_is_mad;

public class Turf {
    private long id;
    private String name;
    private String description;
    private String location;
    private double price;
    private String contactInfo;
    private String openingTime = "06:00"; // Default opening time (6 AM)
    private String closingTime = "22:00"; // Default closing time (10 PM)
    private int ownerId;
    private String imageUrl; // URL to the turf image
    private double latitude;
    private double longitude;
    private String upiId;  // Add UPI ID field

    // No-argument constructor
    public Turf() {
        // Initialize with default values
        this.id = 0;
        this.name = "";
        this.description = "";
        this.location = "";
        this.price = 0.0;
        this.contactInfo = "Contact information not available";
        this.openingTime = "06:00";
        this.closingTime = "22:00";
        this.ownerId = 0;
        this.imageUrl = "";
        this.latitude = 0;
        this.longitude = 0;
    }

    // Constructor with all fields including imageUrl
    public Turf(long id, String name, String description, String location, double price,
                String contactInfo, String openingTime, String closingTime, int ownerId) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.location = location;
        this.price = price;
        this.contactInfo = contactInfo;
        this.openingTime = openingTime;
        this.closingTime = closingTime;
        this.ownerId = ownerId;
        this.imageUrl = "";
    }

    // Constructor with essential fields
    public Turf(long id, String name, String description, String location, double price) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.location = location;
        this.price = price;
        this.contactInfo = "Contact information not available";
        this.imageUrl = "";
    }

    // Constructor with contact info
    public Turf(long id, String name, String description, String location, double price, String contactInfo) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.location = location;
        this.price = price;
        this.contactInfo = contactInfo;
        this.imageUrl = "";
    }

    // Getters and setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }

    public String getOpeningTime() {
        return openingTime;
    }

    public void setOpeningTime(String openingTime) {
        this.openingTime = openingTime;
    }

    public String getClosingTime() {
        return closingTime;
    }

    public void setClosingTime(String closingTime) {
        this.closingTime = closingTime;
    }

    public int getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(int ownerId) {
        this.ownerId = ownerId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    // Getters and setters for latitude and longitude
    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getUpiId() {
        return upiId;
    }

    public void setUpiId(String upiId) {
        this.upiId = upiId;
    }

    // Calculate price per person
    public double getPricePerPerson(int numberOfPlayers) {
        if (numberOfPlayers <= 0) {
            return price; // Return full price if invalid player count
        }
        return price / numberOfPlayers;
    }

    // Get available time slots (1-hour slots between opening and closing time)
    public String[] getAvailableTimeSlots() {
        try {
            // Parse opening and closing hours
            int openingHour = Integer.parseInt(openingTime.split(":")[0]);
            int closingHour = Integer.parseInt(closingTime.split(":")[0]);

            // Calculate number of slots
            int numberOfSlots = closingHour - openingHour;

            // Create array of time slots
            String[] timeSlots = new String[numberOfSlots];
            for (int i = 0; i < numberOfSlots; i++) {
                int startHour = openingHour + i;
                int endHour = startHour + 1;
                timeSlots[i] = String.format("%02d:00 - %02d:00", startHour, endHour);
            }

            return timeSlots;
        } catch (Exception e) {
            // Return default slots if there's an error
            return new String[]{"06:00 - 07:00", "07:00 - 08:00", "08:00 - 09:00",
                    "09:00 - 10:00", "10:00 - 11:00", "11:00 - 12:00",
                    "12:00 - 13:00", "13:00 - 14:00", "14:00 - 15:00",
                    "15:00 - 16:00", "16:00 - 17:00", "17:00 - 18:00",
                    "18:00 - 19:00", "19:00 - 20:00", "20:00 - 21:00",
                    "21:00 - 22:00"};
        }
    }
}