package com.example.ts_project_is_mad;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;

public class TurfOwnerActivity extends AppCompatActivity implements TurfAdapter.OnTurfClickListener {
    private static final String TAG = "TurfOwnerActivity";
    private RecyclerView ownerTurfRecyclerView;
    private TurfAdapter turfAdapter;
    private FloatingActionButton addTurfFab;
    private TextView emptyView;
    private DatabaseHelper dbHelper;
    private long ownerId = -1; // Default to invalid ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_turf_owner);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Get owner ID from intent - check for both "owner_id" and "userId"
        if (getIntent().hasExtra("owner_id")) {
            ownerId = getIntent().getLongExtra("owner_id", -1);
            Log.d(TAG, "Owner ID from intent (owner_id): " + ownerId);
        } else if (getIntent().hasExtra("userId")) {
            // This is needed for compatibility with test cases and other parts of the app
            ownerId = getIntent().getLongExtra("userId", -1);
            Log.d(TAG, "Owner ID from intent (userId): " + ownerId);
        } else {
            // If no owner ID in intent, try to get from extras
            Bundle extras = getIntent().getExtras();
            if (extras != null) {
                if (extras.containsKey("owner_id")) {
                    ownerId = extras.getLong("owner_id", -1);
                    Log.d(TAG, "Owner ID from extras (owner_id): " + ownerId);
                } else if (extras.containsKey("userId")) {
                    ownerId = extras.getLong("userId", -1);
                    Log.d(TAG, "Owner ID from extras (userId): " + ownerId);
                }
            }
        }

        // If still no valid owner ID, show error and finish
        if (ownerId == -1) {
            Toast.makeText(this, "Error: Owner ID not found", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "No owner ID found in intent or extras");
            finish();
            return;
        }

        // Initialize views
        initializeViews();

        // Load turfs for this owner
        loadTurfs();
    }

    private void initializeViews() {
        try {
            ownerTurfRecyclerView = findViewById(R.id.ownerTurfRecyclerView);
            emptyView = findViewById(R.id.emptyView);
            addTurfFab = findViewById(R.id.addTurfFab);
            TextView welcomeMessageTextView = findViewById(R.id.welcomeMessageTextView);

            // Check if any views are null
            if (ownerTurfRecyclerView == null || emptyView == null || addTurfFab == null) {
                Toast.makeText(this, "Error: Some views could not be initialized",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            
            // Set welcome message with owner's name
            if (welcomeMessageTextView != null && ownerId > 0) {
                String ownerName = dbHelper.getUserNameById(ownerId);
                if (ownerName != null && !ownerName.isEmpty()) {
                    welcomeMessageTextView.setText("Welcome to BookMyTurf, " + ownerName);
                    Log.d(TAG, "Set welcome message for owner: " + ownerName);
                }
            }
            
            // Make sure FAB is visible
            addTurfFab.setVisibility(View.VISIBLE);
            Log.d(TAG, "FAB set to VISIBLE");
            Log.d(TAG, "FAB visibility: " + (addTurfFab.getVisibility() == View.VISIBLE ? "VISIBLE" : "NOT VISIBLE"));

            // Set up toolbar
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null) {
                getSupportActionBar().setTitle("My Turfs");
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            }

            // Set up RecyclerView
            ownerTurfRecyclerView.setLayoutManager(new LinearLayoutManager(this));

            // Set up FAB click listener
            addTurfFab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        Log.d(TAG, "Add turf FAB clicked");
                        // Navigate to AddTurfActivity
                        Intent intent = new Intent(TurfOwnerActivity.this, AddTurfActivity.class);
                        intent.putExtra("owner_id", ownerId);
                        startActivity(intent);
                    } catch (Exception e) {
                        Log.e(TAG, "Error navigating to AddTurfActivity: " + e.getMessage(), e);
                        Toast.makeText(TurfOwnerActivity.this,
                                "Error opening add turf screen", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error initializing Owner Dashboard: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing Owner Dashboard: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload turfs when returning to this activity
        loadTurfs();
        
        // Ensure FAB is visible when activity resumes
        if (addTurfFab != null) {
            addTurfFab.setVisibility(View.VISIBLE);
            addTurfFab.setElevation(16f); // Increase elevation to ensure it appears above other views
            Log.d(TAG, "FAB set to VISIBLE in onResume");
        }
    }

    private void loadTurfs() {
        if (ownerTurfRecyclerView == null || emptyView == null) {
            Toast.makeText(this, "Error: Views not properly initialized", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            // Get turfs from database for this owner
            Log.d(TAG, "Loading turfs for owner ID: " + ownerId);
            List<Turf> turfs = dbHelper.getTurfsByOwnerId(ownerId);

            // Update UI based on whether turfs were found
            if (turfs.isEmpty()) {
                Log.d(TAG, "No turfs found for owner ID: " + ownerId);
                ownerTurfRecyclerView.setVisibility(View.GONE);
                emptyView.setVisibility(View.VISIBLE);
                emptyView.setText("No turfs registered yet.\nClick the + button to add a new turf.");
            } else {
                Log.d(TAG, "Found " + turfs.size() + " turfs for owner ID: " + ownerId);
                ownerTurfRecyclerView.setVisibility(View.VISIBLE);
                emptyView.setVisibility(View.GONE);

                // Set up adapter with the owner's turfs
                turfAdapter = new TurfAdapter(turfs);
                turfAdapter.setOnTurfClickListener(this);
                ownerTurfRecyclerView.setAdapter(turfAdapter);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error loading turfs: " + e.getMessage(), e);
            Toast.makeText(this, "Error loading turfs: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            // Show empty state with error message
            ownerTurfRecyclerView.setVisibility(View.GONE);
            emptyView.setVisibility(View.VISIBLE);
            emptyView.setText("Error loading turfs.\nPlease try again.");
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_logout) {
            // Handle logout
            Toast.makeText(this, "Logging out...", Toast.LENGTH_SHORT).show();

            // Navigate back to login screen with proper flags
            Intent intent = new Intent(this, LoginActivity.class);
            // Clear back stack but don't use FLAG_ACTIVITY_CLEAR_TASK to avoid closing app
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            // Don't call finish() - let the intent flags handle the navigation
            return true;
        } else if (id == R.id.action_view_bookings) {
            // Navigate to the bookings dashboard
            try {
                Intent intent = new Intent(this, OwnerBookingsActivity.class);
                
                // Always pass the owner ID to ensure correct data loading
                User currentUser = SessionManager.getLoggedInUser(this);
                if (currentUser != null) {
                    intent.putExtra("owner_id", currentUser.getId());
                    Log.d(TAG, "Navigating to OwnerBookingsActivity with owner_id: " + currentUser.getId());
                } else {
                    // Fallback to the cached owner ID if session is null
                    intent.putExtra("owner_id", ownerId);
                    Log.d(TAG, "Navigating to OwnerBookingsActivity with cached owner_id: " + ownerId);
                }
                
                startActivity(intent);
                return true;
            } catch (Exception e) {
                Log.e(TAG, "Error navigating to bookings dashboard: " + e.getMessage(), e);
                Toast.makeText(this, "Error opening bookings dashboard", Toast.LENGTH_SHORT).show();
            }
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onTurfClick(Turf turf) {
        try {
            // Show options dialog
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
            builder.setTitle("Turf Options")
                    .setItems(new CharSequence[]{"View Details", "Delete Turf"},
                            (dialog, which) -> {
                                switch (which) {
                                    case 0: // View Details
                                        Intent intent = new Intent(TurfOwnerActivity.this, TurfDetailsActivity.class);
                                        intent.putExtra("turf_id", turf.getId());
                                        intent.putExtra("is_owner", true);
                                        startActivity(intent);
                                        break;
                                    case 1: // Delete Turf
                                        confirmDelete(turf);
                                        break;
                                }
                            });
            builder.show();
        } catch (Exception e) {
            Log.e(TAG, "Error handling turf click: " + e.getMessage(), e);
            Toast.makeText(this, "Error handling turf selection", Toast.LENGTH_SHORT).show();
        }
    }

    private void confirmDelete(Turf turf) {
        try {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
            builder.setTitle("Delete Turf")
                    .setMessage("Are you sure you want to delete " + turf.getName() + "?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        try {
                            dbHelper.deleteTurf(turf.getId());  // Now uses long directly without casting
                            Toast.makeText(this, "Turf deleted successfully", Toast.LENGTH_SHORT).show();
                            loadTurfs(); // Refresh the list
                        } catch (Exception e) {
                            Log.e(TAG, "Error deleting turf: " + e.getMessage(), e);
                            Toast.makeText(this, "Error deleting turf", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        } catch (Exception e) {
            Log.e(TAG, "Error showing delete confirmation: " + e.getMessage(), e);
            Toast.makeText(this, "Error showing delete confirmation", Toast.LENGTH_SHORT).show();
        }
    }
}