package com.example.ts_project_is_mad;

import android.app.Application;

/**
 * Custom Application class to initialize app-wide configurations
 */
public class BookMyTurfApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
} 