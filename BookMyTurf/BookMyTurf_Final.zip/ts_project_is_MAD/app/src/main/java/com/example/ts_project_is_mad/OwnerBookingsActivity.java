package com.example.ts_project_is_mad;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

public class OwnerBookingsActivity extends AppCompatActivity {
    private static final String TAG = "OwnerBookingsActivity";
    
    private RecyclerView bookingsRecyclerView;
    private TextView emptyView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private TabLayout tabLayout;
    
    private DatabaseHelper dbHelper;
    private BookingAdapter bookingAdapter;
    private List<Booking> allBookings = new ArrayList<>();
    private List<Booking> filteredBookings = new ArrayList<>();
    
    // Owner ID passed from calling activity
    private long ownerId = -1;
    
    // Filter options
    private static final int FILTER_ALL = 0;
    private static final int FILTER_UPCOMING = 1;
    private static final int FILTER_PAST = 2;
    private int currentFilter = FILTER_ALL;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner_bookings);
        
        // Initialize database helper
        dbHelper = new DatabaseHelper(this);
        
        // Get owner ID from intent
        if (getIntent().hasExtra("owner_id")) {
            ownerId = getIntent().getLongExtra("owner_id", -1);
            Log.d(TAG, "Received owner_id from intent: " + ownerId);
        }
        
        // Set up toolbar
        setupToolbar();
        
        // Initialize views
        initializeViews();
        
        // Load bookings
        loadBookings();
    }
    
    private void setupToolbar() {
        try {
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setTitle("Bookings Dashboard");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error setting up toolbar: " + e.getMessage(), e);
        }
    }
    
    private void initializeViews() {
        try {
            // Initialize RecyclerView
            bookingsRecyclerView = findViewById(R.id.bookingsRecyclerView);
            bookingsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            
            // Initialize empty view
            emptyView = findViewById(R.id.emptyView);
            
            // Initialize SwipeRefreshLayout
            swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
            swipeRefreshLayout.setOnRefreshListener(this::loadBookings);
            swipeRefreshLayout.setColorSchemeResources(
                    R.color.green_500,
                    R.color.green_700,
                    R.color.blue_500
            );
            
            // Initialize TabLayout for filtering
            tabLayout = findViewById(R.id.tabLayout);
            tabLayout.addTab(tabLayout.newTab().setText("All"));
            tabLayout.addTab(tabLayout.newTab().setText("Upcoming"));
            tabLayout.addTab(tabLayout.newTab().setText("Past"));
            
            tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
                @Override
                public void onTabSelected(TabLayout.Tab tab) {
                    currentFilter = tab.getPosition();
                    filterBookings();
                }
                
                @Override
                public void onTabUnselected(TabLayout.Tab tab) {
                    // Not used
                }
                
                @Override
                public void onTabReselected(TabLayout.Tab tab) {
                    // Not used
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error initializing views: " + e.getMessage(), e);
        }
    }
    
    private void loadBookings() {
        try {
            // Show loading indicator
            swipeRefreshLayout.setRefreshing(true);
            
            // Check if we have a valid owner ID either from intent or session
            boolean validOwner = false;
            
            // If we have an owner ID from the intent, use that
            if (ownerId > 0) {
                Log.d(TAG, "Using owner ID from intent: " + ownerId);
                validOwner = true;
            } else {
                // Try to get logged in user from session as fallback
                User currentUser = SessionManager.getLoggedInUser(this);
                
                // DEBUG: Log user details to diagnose the issue
                if (currentUser != null) {
                    Log.d(TAG, "Current user: id=" + currentUser.getId() + 
                          ", name=" + currentUser.getName() + 
                          ", type=" + currentUser.getUserType() + 
                          ", isOwner=" + currentUser.isOwner());
                    
                    if (currentUser.isOwner()) {
                        ownerId = currentUser.getId();
                        validOwner = true;
                        Log.d(TAG, "Using owner ID from session: " + ownerId);
                    } else {
                        Log.e(TAG, "User is not an owner: " + currentUser.getUserType());
                    }
                    
                    // Query database directly to check if there are any turfs owned by this user
                    List<Turf> ownedTurfs = dbHelper.getTurfsByOwnerId(currentUser.getId());
                    Log.d(TAG, "Number of turfs owned by user: " + (ownedTurfs != null ? ownedTurfs.size() : 0));
                    
                    // If there are turfs, log their IDs
                    if (ownedTurfs != null && !ownedTurfs.isEmpty()) {
                        StringBuilder turfIds = new StringBuilder();
                        for (Turf turf : ownedTurfs) {
                            turfIds.append(turf.getId()).append(", ");
                        }
                        Log.d(TAG, "Turf IDs: " + turfIds.toString());
                    }
                } else {
                    Log.e(TAG, "No user logged in and no owner ID in intent");
                }
            }
            
            if (!validOwner) {
                Log.e(TAG, "No valid owner ID found. Owner ID: " + ownerId);
                swipeRefreshLayout.setRefreshing(false);
                showEmptyView("Please log in as a turf owner");
                return;
            }
            
            // Get bookings for this owner
            allBookings = dbHelper.getBookingsByOwnerId(ownerId);
            
            // DEBUG: Log the number of bookings found
            Log.d(TAG, "Number of bookings found for owner " + ownerId + ": " + allBookings.size());
            
            // Apply current filter
            filterBookings();
            
            // Hide loading indicator
            swipeRefreshLayout.setRefreshing(false);
        } catch (Exception e) {
            Log.e(TAG, "Error loading bookings: " + e.getMessage(), e);
            swipeRefreshLayout.setRefreshing(false);
            showEmptyView("Error loading bookings: " + e.getMessage());
        }
    }
    
    private void filterBookings() {
        try {
            filteredBookings.clear();
            
            if (allBookings.isEmpty()) {
                showEmptyView("No bookings found");
                return;
            }
            
            // Get current date
            java.util.Date currentDate = new java.util.Date();
            java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault());
            String today = dateFormat.format(currentDate);
            
            // Filter bookings based on current filter
            switch (currentFilter) {
                case FILTER_ALL:
                    filteredBookings.addAll(allBookings);
                    break;
                case FILTER_UPCOMING:
                    for (Booking booking : allBookings) {
                        try {
                            // Compare dates
                            java.util.Date bookingDate = dateFormat.parse(booking.getBookingDate());
                            if (bookingDate != null && bookingDate.compareTo(currentDate) >= 0) {
                                filteredBookings.add(booking);
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error parsing date: " + e.getMessage(), e);
                        }
                    }
                    break;
                case FILTER_PAST:
                    for (Booking booking : allBookings) {
                        try {
                            // Compare dates
                            java.util.Date bookingDate = dateFormat.parse(booking.getBookingDate());
                            if (bookingDate != null && bookingDate.compareTo(currentDate) < 0) {
                                filteredBookings.add(booking);
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error parsing date: " + e.getMessage(), e);
                        }
                    }
                    break;
            }
            
            // Update RecyclerView
            if (filteredBookings.isEmpty()) {
                showEmptyView("No bookings found for this filter");
            } else {
                showBookings();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error filtering bookings: " + e.getMessage(), e);
            showEmptyView("Error filtering bookings");
        }
    }
    
    private void showBookings() {
        try {
            // Hide empty view
            emptyView.setVisibility(View.GONE);
            bookingsRecyclerView.setVisibility(View.VISIBLE);
            
            // Create or update adapter
            if (bookingAdapter == null) {
                bookingAdapter = new BookingAdapter(this, filteredBookings);
                
                // Set click listener for bookings
                bookingAdapter.setOnItemClickListener(booking -> {
                    // Open booking details activity
                    Intent intent = new Intent(this, BookingDetailsActivity.class);
                    intent.putExtra("booking_id", booking.getId());
                    startActivity(intent);
                });
                
                bookingsRecyclerView.setAdapter(bookingAdapter);
            } else {
                bookingAdapter.updateBookings(filteredBookings);
                bookingAdapter.notifyDataSetChanged();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error showing bookings: " + e.getMessage(), e);
        }
    }
    
    private void showEmptyView(String message) {
        try {
            // Show empty view
            emptyView.setText(message);
            emptyView.setVisibility(View.VISIBLE);
            bookingsRecyclerView.setVisibility(View.GONE);
        } catch (Exception e) {
            Log.e(TAG, "Error showing empty view: " + e.getMessage(), e);
        }
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
} 