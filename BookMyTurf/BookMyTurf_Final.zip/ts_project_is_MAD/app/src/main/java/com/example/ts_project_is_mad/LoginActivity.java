package com.example.ts_project_is_mad;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {
    private static final String TAG = "LoginActivity";
    private TextInputLayout emailInputLayout;
    private TextInputLayout passwordInputLayout;
    private TextInputEditText emailInput;
    private TextInputEditText passwordInput;
    private Button loginButton;
    private TextView registerLink;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_login);

            dbHelper = new DatabaseHelper(this);

            // Initialize views
            initializeViews();

            // Add text change listener for email
            if (emailInput != null) {
                emailInput.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        if (!hasFocus) {
                            validateEmail();
                        }
                    }
                });
            }

            if (loginButton != null) {
                loginButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (validateInputs()) {
                            String email = emailInput.getText().toString().trim();
                            String password = passwordInput.getText().toString().trim();

                            try {
                                // For testing purposes, allow any login
                                boolean loginSuccess = true;

                                // In production, uncomment this to check credentials
                                // loginSuccess = dbHelper.checkUser(email, password);

                                if (loginSuccess) {
                                    handleLoginSuccess(email);
                                } else {
                                    Toast.makeText(LoginActivity.this, "Invalid email or password", Toast.LENGTH_SHORT).show();
                                }
                            } catch (Exception e) {
                                // Handle database errors
                                Log.e(TAG, "Database error: " + e.getMessage(), e);
                                Toast.makeText(LoginActivity.this,
                                        "Database error: " + e.getMessage(),
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });
            }

            if (registerLink != null) {
                registerLink.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
                        } catch (Exception e) {
                            Toast.makeText(LoginActivity.this,
                                    "Error opening registration: " + e.getMessage(),
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        } catch (Exception e) {
            Log.e(TAG, "Error initializing Login screen: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing Login screen: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void initializeViews() {
        try {
            emailInputLayout = findViewById(R.id.emailInputLayout);
            passwordInputLayout = findViewById(R.id.passwordInputLayout);
            emailInput = findViewById(R.id.emailInput);
            passwordInput = findViewById(R.id.passwordInput);
            loginButton = findViewById(R.id.loginButton);
            registerLink = findViewById(R.id.registerLink);

            // Check if any views are null
            if (emailInputLayout == null || passwordInputLayout == null ||
                    emailInput == null || passwordInput == null ||
                    loginButton == null || registerLink == null) {
                Toast.makeText(this, "Error: Some views could not be initialized",
                        Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error finding views: " + e.getMessage(), e);
            Toast.makeText(this, "Error finding views: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }
    }

    private boolean validateEmail() {
        try {
            String email = emailInput.getText().toString().trim();

            if (TextUtils.isEmpty(email)) {
                emailInputLayout.setError("Email is required");
                Toast.makeText(this, "Please enter your email address", Toast.LENGTH_SHORT).show();
                return false;
            } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                emailInputLayout.setError("Please enter a valid email address");
                Toast.makeText(this, "Please enter a valid email address (e.g., user@example.com)", Toast.LENGTH_LONG).show();
                return false;
            } else {
                emailInputLayout.setError(null);
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error validating email: " + e.getMessage(), e);
            Toast.makeText(this, "Error validating email: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean validatePassword() {
        try {
            String password = passwordInput.getText().toString().trim();

            if (TextUtils.isEmpty(password)) {
                passwordInputLayout.setError("Password is required");
                Toast.makeText(this, "Please enter your password", Toast.LENGTH_SHORT).show();
                return false;
            } else {
                passwordInputLayout.setError(null);
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error validating password: " + e.getMessage(), e);
            Toast.makeText(this, "Error validating password: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean validateInputs() {
        boolean isEmailValid = validateEmail();
        boolean isPasswordValid = validatePassword();
        return isEmailValid && isPasswordValid;
    }

    private void handleLoginSuccess(String email) {
        try {
            // Get user type (owner or regular user)
            String userType = dbHelper.getUserType(email);
            Log.d(TAG, "User type from database: " + userType);

            // Get user ID
            long userId = dbHelper.getUserId(email);
            Log.d(TAG, "User ID from database: " + userId);

            if (userType == null || userId == -1) {
                Toast.makeText(this, "Error: User not found", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent;

            // Navigate to appropriate activity based on user type
            if (userType.equals("owner")) {
                // Navigate to owner dashboard
                intent = new Intent(LoginActivity.this, TurfOwnerActivity.class);
                intent.putExtra("owner_id", userId);
                Log.d(TAG, "Navigating to TurfOwnerActivity with owner_id: " + userId);
            } else {
                // Navigate to user dashboard (turf list)
                intent = new Intent(LoginActivity.this, TurfListActivity.class);
                intent.putExtra("user_id", userId);
                Log.d(TAG, "Navigating to TurfListActivity with user_id: " + userId);
            }

            // Clear back stack so user can't go back to login screen
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        } catch (Exception e) {
            Log.e(TAG, "Error handling login success: " + e.getMessage(), e);
            Toast.makeText(this, "Error navigating after login", Toast.LENGTH_SHORT).show();
        }
    }
}