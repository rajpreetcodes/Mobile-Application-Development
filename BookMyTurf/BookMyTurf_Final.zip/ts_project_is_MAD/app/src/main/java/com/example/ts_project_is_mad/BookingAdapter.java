package com.example.ts_project_is_mad;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.chip.Chip;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Adapter for displaying bookings in a RecyclerView
 */
public class BookingAdapter extends RecyclerView.Adapter<BookingAdapter.BookingViewHolder> {
    private Context context;
    private List<Booking> bookings;
    private OnItemClickListener listener;
    
    /**
     * Interface for booking click events
     */
    public interface OnItemClickListener {
        void onItemClick(Booking booking);
    }
    
    public BookingAdapter(Context context, List<Booking> bookings) {
        this.context = context;
        this.bookings = bookings;
    }
    
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }
    
    @NonNull
    @Override
    public BookingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_booking, parent, false);
        return new BookingViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull BookingViewHolder holder, int position) {
        Booking booking = bookings.get(position);
        
        // Set turf name
        holder.turfNameText.setText(booking.getTurfName());
        
        // Set date
        holder.dateText.setText(booking.getBookingDate());
        
        // Set time
        holder.timeText.setText(booking.getTimeSlot());
        
        // Set price
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
        holder.priceText.setText(format.format(booking.getTotalPrice()));
        
        // Set user name
        holder.userNameText.setText("Booked by: " + booking.getUserName());
        
        // Set status chip
        holder.statusChip.setText(booking.getBookingStatus());
        updateStatusChipColor(holder.statusChip, booking.getBookingStatus());
        
        // Set click listeners
        holder.cardView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(booking);
            }
        });

        holder.contactButton.setOnClickListener(v -> {
            String contactInfo = booking.getTurf().getContactInfo();
            if (contactInfo != null && !contactInfo.isEmpty()) {
                String message = String.format(
                    "Booking Details\n\n" +
                    "Turf: %s\n" +
                    "Date: %s\n" +
                    "Time: %s\n" +
                    "Price: %s\n" +
                    "Status: %s\n\n" +
                    "I would like to discuss my booking.",
                    booking.getTurfName(),
                    booking.getBookingDate(),
                    booking.getTimeSlot(),
                    format.format(booking.getTotalPrice()),
                    booking.getBookingStatus()
                );
                
                // Extract phone number from contact info (assuming it's just a phone number)
                String phoneNumber = contactInfo.replaceAll("[^0-9]", "");
                if (!phoneNumber.isEmpty()) {
                    String url = "https://api.whatsapp.com/send?phone=" + phoneNumber + "&text=" + Uri.encode(message);
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    context.startActivity(intent);
                } else {
                    Toast.makeText(context, "Invalid contact number format", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(context, "Turf contact information not available", Toast.LENGTH_SHORT).show();
            }
        });

        holder.paymentButton.setOnClickListener(v -> {
            // Get the turf's UPI ID
            String upiId = booking.getTurf().getUpiId();
            if (upiId != null && !upiId.isEmpty()) {
                // Create UPI payment URL
                String upiUrl = "upi://pay?pa=" + upiId + 
                              "&pn=" + Uri.encode(booking.getTurfName()) +
                              "&am=" + booking.getTotalPrice() +
                              "&cu=INR" +
                              "&tn=" + Uri.encode("Booking for " + booking.getTurfName());
                
                // Create and start payment intent
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(upiUrl));
                
                // Check if any UPI app is installed
                PackageManager packageManager = context.getPackageManager();
                List<ResolveInfo> activities = packageManager.queryIntentActivities(intent, 0);
                
                if (activities.size() > 0) {
                    context.startActivity(intent);
                } else {
                    Toast.makeText(context, "No UPI payment apps found. Please install a UPI app like Google Pay, PhonePe, or Paytm.", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(context, "UPI payment not available for this turf", Toast.LENGTH_SHORT).show();
            }
        });
    }
    
    private void updateStatusChipColor(Chip chip, String status) {
        switch (status.toLowerCase()) {
            case "confirmed":
                chip.setChipBackgroundColorResource(R.color.green_500);
                break;
            case "pending":
                chip.setChipBackgroundColorResource(R.color.yellow_500);
                break;
            case "cancelled":
                chip.setChipBackgroundColorResource(R.color.red_500);
                break;
            default:
                chip.setChipBackgroundColorResource(R.color.grey_500);
        }
    }
    
    @Override
    public int getItemCount() {
        return bookings.size();
    }
    
    public void updateBookings(List<Booking> newBookings) {
        this.bookings = newBookings;
        notifyDataSetChanged();
    }
    
    static class BookingViewHolder extends RecyclerView.ViewHolder {
        MaterialCardView cardView;
        TextView turfNameText;
        TextView dateText;
        TextView timeText;
        TextView priceText;
        TextView userNameText;
        Chip statusChip;
        MaterialButton contactButton;
        MaterialButton paymentButton;
        
        public BookingViewHolder(@NonNull View itemView) {
            super(itemView);
            
            cardView = itemView.findViewById(R.id.bookingCardView);
            turfNameText = itemView.findViewById(R.id.turfNameText);
            dateText = itemView.findViewById(R.id.dateText);
            timeText = itemView.findViewById(R.id.timeText);
            priceText = itemView.findViewById(R.id.priceText);
            userNameText = itemView.findViewById(R.id.userNameText);
            statusChip = itemView.findViewById(R.id.statusChip);
            contactButton = itemView.findViewById(R.id.contactButton);
            paymentButton = itemView.findViewById(R.id.paymentButton);
        }
    }
} 