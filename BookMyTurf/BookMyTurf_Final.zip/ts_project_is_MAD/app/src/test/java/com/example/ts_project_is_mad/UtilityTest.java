package com.example.ts_project_is_mad;

import org.junit.Test;
import static org.junit.Assert.*;

public class UtilityTest {

    @Test
    public void testEmailValidation() {
        // Test valid email formats
        assertTrue(Utility.isValidEmail("user@example.com"));
        assertTrue(Utility.isValidEmail("user.name@example.co.in"));
        assertTrue(Utility.isValidEmail("user-name@example-domain.com"));
        
        // Test invalid email formats
        assertFalse(Utility.isValidEmail(""));
        assertFalse(Utility.isValidEmail("user@"));
        assertFalse(Utility.isValidEmail("user@.com"));
        assertFalse(Utility.isValidEmail("user@example"));
        assertFalse(Utility.isValidEmail("user.example.com"));
    }
    
    @Test
    public void testPasswordValidation() {
        // Test valid passwords (assuming minimum 6 characters)
        assertTrue(Utility.isValidPassword("password123"));
        assertTrue(Utility.isValidPassword("Pass@123"));
        assertTrue(Utility.isValidPassword("123456"));
        
        // Test invalid passwords
        assertFalse(Utility.isValidPassword(""));
        assertFalse(Utility.isValidPassword("pass"));
        assertFalse(Utility.isValidPassword("12345"));
    }
    
    @Test
    public void testPriceFormatting() {
        // We need to check if the output contains the right value rather than exact string comparison
        // because currency formatting can be system/locale-dependent
        String price500 = Utility.formatPrice(500);
        assertTrue("Price should contain '500'", price500.contains("500"));
        
        String price1000 = Utility.formatPrice(1000);
        // Remove all non-digit characters to verify the number 1000 is present
        String digitsOnly = price1000.replaceAll("[^0-9]", "");
        assertTrue("Price should contain '1000'", digitsOnly.contains("1000"));
        
        String priceDecimal = Utility.formatPrice(1500.50);
        // Just verify it doesn't throw an exception
        assertNotNull(priceDecimal);
        
        String priceZero = Utility.formatPrice(0);
        assertTrue("Price should contain '0'", priceZero.contains("0"));
    }
    
    @Test
    public void testTimeFormatting() {
        // Test time formatting (assuming 24hr to 12hr format conversion)
        assertEquals("07:00 AM", Utility.formatTime("07:00"));
        assertEquals("12:00 PM", Utility.formatTime("12:00"));
        assertEquals("01:00 PM", Utility.formatTime("13:00"));
        assertEquals("11:30 PM", Utility.formatTime("23:30"));
    }
    
    @Test
    public void testStringNullOrEmpty() {
        // Test null or empty string check
        assertTrue(Utility.isNullOrEmpty(null));
        assertTrue(Utility.isNullOrEmpty(""));
        assertTrue(Utility.isNullOrEmpty("  "));
        
        assertFalse(Utility.isNullOrEmpty("text"));
        assertFalse(Utility.isNullOrEmpty(" text "));
    }
} 