#!/bin/bash
echo "======================================"
echo "BookMyTurf Build Verification Script"
echo "======================================"

echo
echo "Cleaning project..."
./gradlew clean

echo
echo "Running unit tests..."
./gradlew test

echo
echo "Building debug APK..."
./gradlew assembleDebug

echo
echo "Build and test process complete!"
echo "If all steps passed, the app is ready for testing on a device."
echo "The debug APK can be found at app/build/outputs/apk/debug/app-debug.apk"
echo
echo "To run instrumented tests on a connected device, run:"
echo "./gradlew connectedAndroidTest"
echo "======================================" 