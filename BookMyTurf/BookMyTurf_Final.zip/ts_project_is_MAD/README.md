# BookMyTurf - Turf Booking Application

BookMyTurf is an Android application that allows users to book sports turfs. The application provides separate interfaces for turf owners and regular users, with features like turf listing, booking, location services, and more.

## Features

- **User Authentication**: Register and login as either a turf owner or regular user
- **Turf Management**: Owners can add, edit, and manage their turfs
- **Booking System**: Users can book available time slots at turfs
- **Location Services**: Find nearby turfs using Google Maps integration
- **Image Upload**: Upload images of turfs using camera or gallery
- **Reviews and Ratings**: Rate and review turfs after booking

## Project Structure

- `app/src/main/java/com/example/ts_project_is_mad/`: Main source code
- `app/src/main/res/`: Resources including layouts, values, and drawables
- `app/src/androidTest/`: Instrumented tests
- `app/src/test/`: Unit tests

## Prerequisites

- Android Studio (latest version recommended)
- JDK 8 or higher
- Android SDK 30 or higher
- A physical device or emulator with Google Play Services
- Firebase account for backend services

## Building and Running the App

### Development Environment

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/BookMyTurf.git
   ```

2. Open the project in Android Studio.

3. Create a Firebase project and add the `google-services.json` file to the app directory.

4. Update the Google Maps API key in the `AndroidManifest.xml` file.

5. Build and run the app:
   ```
   ./gradlew clean assembleDebug
   ```

6. Install the debug APK on your device:
   ```
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```

### Running Tests

1. Run unit tests:
   ```
   ./gradlew test
   ```

2. Run instrumented tests (requires a connected device or emulator):
   ```
   ./gradlew connectedAndroidTest
   ```

## Production Deployment

### Preparing for Release

1. Create a signing key:
   ```
   keytool -genkey -v -keystore release-keystore.jks -alias release -keyalg RSA -keysize 2048 -validity 10000
   ```

2. Place the keystore file in the app directory.

3. Set up environment variables for secure key management:
   ```
   export KEYSTORE_PASSWORD=your_keystore_password
   export KEY_ALIAS=release
   export KEY_PASSWORD=your_key_password
   ```

4. Update `app/build.gradle` with your applicationId for production.

### Building a Release APK

1. Build the release APK:
   ```
   ./gradlew clean assembleRelease
   ```

2. The signed APK will be available at:
   ```
   app/build/outputs/apk/release/app-release.apk
   ```

### Building an App Bundle (for Google Play)

1. Build the Android App Bundle:
   ```
   ./gradlew clean bundleRelease
   ```

2. The bundle will be available at:
   ```
   app/build/outputs/bundle/release/app-release.aab
   ```

### Publishing to Google Play Store

1. Create a Google Play Developer account.

2. Create a new application in the Google Play Console.

3. Upload the app bundle (AAB file).

4. Fill in app details including:
   - App description
   - Screenshots
   - Feature graphic
   - Privacy policy

5. Pass the pre-launch report tests.

6. Publish to a track (internal testing, closed testing, open testing, or production).

## Continuous Integration

The project is set up for CI using GitHub Actions. Each pull request and push to the main branch triggers:

1. Code style checks
2. Unit tests
3. Instrumented tests on Firebase Test Lab
4. APK building

## Troubleshooting

### Common Issues

- **"+ sign not appearing in TurfOwnerActivity"**: Check the intent parameters passed to the activity (must include either "owner_id" or "userId").
- **Database schema issues**: Make sure you're using the latest version of the app with proper schema upgrades.
- **Firebase connection failures**: Verify the `google-services.json` file is correctly configured.

### Support

For any issues or feature requests, please open an issue in the GitHub repository.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contributors

- [Your Name](https://github.com/yourusername)
- [Other Contributors](https://github.com/contributors) 